# M-03-T01 チャットメッセージ送信とLLM連携機能の実装

> 種別: 機能 / マイルストーン: M-03 チャットヒアリング機能の実装 / 要件: FR-002, FR-009, FR-010 / 依存: M-02-T02

## 目的

チャットメッセージの送信を受け付け、認証確認、データベースへの保存、LLMとの連携を経て応答メッセージを返却できるようにする。

## 対象の処理・参照する設計

- 段階5 F-05 チャットメッセージを送信する
- 段階6 ChatRouter.send_message(`app/api/routes/chat.py`)(設計に無い ── 未定義を参照)
- 段階6 ChatService.process_message(`app/services/chat.py`)(設計に無い ── 未定義を参照)
- 段階6 ChatRepository.save(`app/repositories/chat.py`)(設計に無い ── 未定義を参照)
- 段階6 LLMClient.invoke_chat(`app/llm/client.py`)(設計に無い ── 未定義を参照)
- 段階4 `app/api/routes/chat.py`
- 段階4 `app/services/chat.py`
- 段階4 `app/llm/client.py`
- 段階4 `app/repositories/chat.py`

### シーケンス図(段階5 F-05 チャットメッセージを送信する の手順から導出)

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/chat.py
  participant P3 as app/services/chat.py
  participant P4 as app/repositories/chat.py
  participant P5 as app/llm/client.py
  P1->>P2: 1: ChatRouter.send_message(プロジェクトID、チャットメッセージ、認証トークン)
  Note over P1,P2: 1a メッセージが空または文字数制限を超過している場合 → ValidationError → 400
  Note over P1,P2: 1b 認証トークンが無効な場合 → UnauthorizedError → 401
  P2->>P3: 2: ChatService.process_message(プロジェクトID、チャットメッセージ、認証トークン)
  P3->>P4: 3: ChatRepository.save(プロジェクトID、チャットメッセージ)
  P4-->>P3: (3 の戻り) 保存完了
  P3->>P5: 4: LLMClient.invoke_chat(プロジェクトID、チャットメッセージ)
  P5-->>P3: (4 の戻り) AIからのチャット応答メッセージ
  P3->>P4: 5: ChatRepository.save(プロジェクトID、AIからのチャット応答メッセージ)
  P4-->>P3: (5 の戻り) 保存完了
  P3-->>P2: (2 の戻り) AIからのチャット応答メッセージ
  P2-->>P1: 6: AIからのチャット応答メッセージ
```

## 作成・変更するファイル(依存順)

| ファイル | 種類 | 責務 | 根拠 |
|---|---|---|---|
| `app/repositories/chat.py` | モジュール | PostgreSQLへのチャットメッセージの永続化を行う。 | 段階4 |
| `app/llm/client.py` | モジュール | LangChain・LangGraphとGemini Flash-Liteの呼び出しを制御する。 | 段階4 |
| `app/services/chat.py` | モジュール | チャットヒアリングのビジネスロジックとLLM連携を制御する。 | 段階4 |
| `app/api/routes/chat.py` | モジュール | チャットメッセージ送信のAPIエンドポイントを提供する。 | 段階4 |

## 実装の要点(設計に書いていないことだけ)

- 手順3から手順5までのデータベース保存およびLLM呼び出しの一連の処理はトランザクション境界を厳守して実装する。
- セキュリティ要件に基づきチャットの入力内容はログに残さないように注意する。

## テスト観点

| # | 観点 | SUT | ドライバ | スタブ |
|---|---|---|---|---|
| TC-01 | 正常系: チャットメッセージを送信し、保存とLLM応答取得が成功してAIの応答メッセージが返却されること | ChatRouter.send_message | 結合テスト (pytest) | LLMClient.invoke_chat は固定の応答を返すようにスタブ化する |
| TC-02 | 異常系: メッセージが空または文字数制限を超過している場合にValidationError (400) が発生すること | ChatRouter.send_message | 単体テスト (pytest) | スタブ不要 ── バリデーション層の検証 |
| TC-03 | 異常系: 認証トークンが無効な場合にUnauthorizedError (401) が発生すること | ChatService.process_message | 単体テスト (pytest) | auth.py の verify_token を無効なトークンを検知するようにスタブ化する |

- Given 有効なプロジェクトIDと認証トークンとチャットメッセージがある When ChatRouter.send_message を呼び出す Then AIからのチャット応答メッセージが返却される
- Given 空のメッセージまたは制限を超えるメッセージがある When ChatRouter.send_message を呼び出す Then ValidationError が発生する
- Given 無効な認証トークンがある When ChatService.process_message を呼び出す Then UnauthorizedError が発生する

## 確認方法

- pytest を実行してチャット送信機能に関するすべての単体テストおよび結合テストが成功することを確認する。

## 未定義・要決定

| 重要度 | 出どころ | 対象 | 内容 | 直す段階 |
|---|---|---|---|---|
| 最重要 | AI | 段階6 ChatRouter.send_message | チャットメッセージの文字数制限の具体的な上限値が設計に定義されていない。 | 段階6 |
| 最重要 | AI | 段階6 ChatService.process_message | 認証トークンの有効期限の具体的な仕様や検証方法の詳細が設計に定義されていない。 | 段階6 |
| 中程度 | AI | 段階6 LLMClient.invoke_chat | Gemini Flash-Liteのプロンプト構成やLangGraphの具体的なステート管理の仕様が設計に定義されていない。 | 段階6 |
| 軽微 | 検証 | F-05 | M-03-T01 のテスト観点3のスタブ(app/api/routes/auth.py, app/cache/token.py, app/services/auth.py)は、F-05 の手順で SUT(app/services/chat.py)から呼ばれていません(手順に無い依存です。手順に足すか、観点のスタブを直します)。 | 段階5 |
