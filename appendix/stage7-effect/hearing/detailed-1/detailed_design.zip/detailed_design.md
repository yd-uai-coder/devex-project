# 詳細設計書: Devex(ステージ7 詳細1)

## 01 機能(処理)一覧

| 処理ID | 名称 | 種別 | トリガー | 関連画面 | 要件 | 機能グループ | 概要 |
|---|---|---|---|---|---|---|---|
| F-01 | ユーザー登録する | API | POST /api/v1/auth/register | SCR-001 | FR-001, NFR-009 | auth | 入力されたメールアドレスとパスワードをもとに新規ユーザーを登録する |
| F-02 | JWTログインする | API | POST /api/v1/auth/login | SCR-001 | FR-001, NFR-007, NFR-009 | auth | メールアドレスとパスワードを検証しアクセストークンを返却する |
| F-03 | プロジェクトを作成し参考資料をアップロードする | API | POST /api/v1/projects | SCR-002 | FR-002, FR-005, NFR-006 | projects | 新しいプロジェクトを作成し、関連する参考資料ファイルを保存する |
| F-04 | チャットメッセージを送信しAI応答を取得する | API | POST /api/v1/projects/{id}/chat | SCR-003 | FR-002, FR-006, FR-007, NFR-003, NFR-009 | chat | ユーザーのチャットメッセージを受け付け、Gemini Flash-Liteを使用してAIの応答メッセージを取得する |
| F-05 | 4種設計書を自動生成し不足点診断を行う | API | POST /api/v1/projects/{id}/generate | SCR-003, SCR-004 | FR-002, FR-003, FR-007, NFR-003 | generate | これまでのチャット履歴等をもとに4種の設計書を自動生成し、AIによる不足点の3段階診断を実行する |
| F-06 | 空送信チェックを行う | 画面 | SCR-003: チャットメッセージ送信 | SCR-003 | FR-006 | チャットヒアリング処理 | チャットメッセージの入力内容に対して空送信でないかをクライアント側で検証する |
| F-07 | 設計書コンテンツをクリップボードにコピーまたはダウンロードする | 画面 | SCR-004: コピー・ダウンロード操作 | SCR-004 | FR-004 | 設計書プレビュー処理 | 選択した設計書のMarkdown内容をクリップボードにコピーするか、ファイルとしてダウンロードする |

## 02 データフロー

### DFD: auth

![データフロー図: auth](diagrams/dfd_auth.svg)

### DFD: projects

![データフロー図: projects](diagrams/dfd_projects.svg)

### DFD: chat

![データフロー図: chat](diagrams/dfd_chat.svg)

### DFD: generate

![データフロー図: generate](diagrams/dfd_generate.svg)

### DFD: チャットヒアリング処理

![データフロー図: チャットヒアリング処理](diagrams/dfd_チャットヒアリング処理.svg)

### データ辞書

| データ項目 | フィールド | 使う処理 |
|---|---|---|
| 4種の設計書および不足点診断結果 | documents, diagnosis | F-05 |
| AIの応答メッセージ | response | F-04 |
| アクセストークン | access_token, token_type | F-02 |
| チャットメッセージ | message | F-04, F-06 |
| チャット履歴 | history | F-05 |
| プロジェクト作成完了結果 | project_id, message | F-03 |
| プロジェクト情報 | name, description | F-03 |
| ユーザー入力情報 | email, password | F-01, F-02 |
| 参考資料ファイル(txt/md/pdf) | filename, content | F-03 |
| 検証結果(送信可否) | is_valid | F-06 |
| 登録成功メッセージ | message | F-01 |
| 設計書データ | content | F-05 |

### 処理概要表(入力 / 処理 / 出力)

| 処理ID | 名称 | 入力 | 処理内容 | 出力 |
|---|---|---|---|---|
| F-01 | ユーザー登録する | メールアドレス、パスワード | メールアドレスとパスワードの入力を検証し、新規ユーザーをデータベースに保存する。 | 登録成功メッセージ |
| F-02 | JWTログインする | メールアドレス、パスワード | メールアドレスとパスワードを検証し、アクセストークンを返却する。 | アクセストークン |
| F-03 | プロジェクトを作成し参考資料をアップロードする | プロジェクト情報、参考資料ファイル(txt/md/pdf) | プロジェクト情報と参考資料ファイルを検証し、新しいプロジェクトを作成して関連ファイルを保存する。 | プロジェクト作成完了結果 |
| F-04 | チャットメッセージを送信しAI応答を取得する | チャットメッセージ | ユーザーのチャットメッセージを受け付け、Gemini Flash-Liteを使用してAIの応答メッセージを取得する。 | AIの応答メッセージ |
| F-05 | 4種設計書を自動生成し不足点診断を行う | チャット履歴 | これまでのチャット履歴等をもとに4種の設計書を自動生成し、AIによる不足点の3段階診断を実行する。 | 4種の設計書および不足点診断結果 |
| F-06 | 空送信チェックを行う | チャットメッセージの入力内容 | チャットメッセージの入力内容に対して空送信でないかをクライアント側で検証する。 | 検証結果(送信可否) |
| F-07 | 設計書コンテンツをクリップボードにコピーまたはダウンロードする | 選択した設計書のMarkdown内容 | 選択した設計書のMarkdown内容を検証し、クリップボードにコピーするかファイルとしてダウンロードする。 | クリップボードのデータまたはダウンロードファイル |

## 03 データモデル

![ER図(全体)](diagrams/er.svg)

### テーブル定義

#### users

ユーザー情報を管理するテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | ユーザーID |
| email | VARCHAR(255) | — | 不可 | UNIQUE | メールアドレス |
| password | VARCHAR(255) | — | 不可 | — | パスワード |

#### projects

プロジェクト情報を管理するテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | プロジェクトID |
| user_id | UUID | FK | 不可 | FK: users(id) ON DELETE CASCADE | 所有者ユーザーID |
| name | VARCHAR(255) | — | 不可 | — | プロジェクト名 |
| description | TEXT | — | 可 | — | プロジェクト説明 |

#### reference_files

参考資料ファイルを管理するテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | 参考資料ファイルID |
| project_id | UUID | FK | 不可 | FK: projects(id) ON DELETE CASCADE | プロジェクトID |
| filename | VARCHAR(255) | — | 不可 | — | ファイル名 |
| content | TEXT | — | 不可 | — | ファイル内容 |

#### chat_messages

チャットメッセージとAI応答を管理するテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | メッセージID |
| project_id | UUID | FK | 不可 | FK: projects(id) ON DELETE CASCADE | プロジェクトID |
| message | TEXT | — | 不可 | — | ユーザーからのチャットメッセージ |
| response | TEXT | — | 可 | — | AIからの応答メッセージ |

#### documents

自動生成された4種の設計書および診断結果を管理するテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | 設計書ID |
| project_id | UUID | FK | 不可 | FK: projects(id) ON DELETE CASCADE | プロジェクトID |
| content | TEXT | — | 不可 | — | 設計書データ |
| diagnosis | TEXT | — | 可 | — | 不足点診断結果 |

### CRUD 図(処理 × テーブル)

| 処理ID | 名称 | users | projects | reference_files | chat_messages | documents |
|---|---|---|---|---|---|---|
| F-01 | ユーザー登録する | C+ | — | — | — | — |
| F-02 | JWTログインする | R | — | — | — | — |
| F-03 | プロジェクトを作成し参考資料をアップロードする | — | C+ | C* | — | — |
| F-04 | チャットメッセージを送信しAI応答を取得する | — | — | — | C*R* | — |
| F-05 | 4種設計書を自動生成し不足点診断を行う | — | C+RU+ | — | R* | C*R* |

記号: 印なし = DFD の線から決まる R / `+` = 書き込みは DFD の線から決まり、C/U/D の区別は人が確定 / `*` = DFD に描いていない分で、人が確定

## 04 ソフトウェア構造

![コンポーネント図(全体)](diagrams/component.svg)

### モジュール一覧

| パス | 層 | 責務 | 主な依存先 | 関わる処理 |
|---|---|---|---|---|
| app/main.py | 入口 | アプリケーションの起動、ルーターの登録、およびグローバルな例外の変換を行う。 | app/api/routes/auth.py, app/api/routes/project.py, fastapi | 全処理 |
| app/core/security.py | 入口 | JWTトークンの生成・検証および認証の依存性注入(DI)を提供する。 | fastapi, pyjwt | 全処理 |
| app/api/routes/auth.py | 入口 | ユーザー登録およびJWTログインのエンドポイント定義とリクエストの受け付けを行う。 | app/services/auth.py | F-01, F-02 |
| app/api/routes/project.py | 入口 | プロジェクト作成、チャット送信、および設計書生成のエンドポイント定義とリクエストの受け付けを行う。 | app/services/project.py | F-03, F-04, F-05 |
| app/services/auth.py | ユースケース | ユーザー登録とログイン認証に関するビジネスロジックを処理する。 | app/repositories/user.py | F-01, F-02 |
| app/services/project.py | ユースケース | プロジェクト管理、チャットやり取り、および設計書生成・不足点診断のビジネスロジックを処理する。 | app/ai/agent.py, app/repositories/project.py, app/repositories/chat.py, app/repositories/document.py | F-03, F-04, F-05 |
| app/ai/agent.py | ドメイン | LangChainとLangGraphを用いたLLMとのやり取りや不足点診断を制御する。 | app/external/gemini.py, langchain, langgraph | F-04, F-05 |
| app/external/gemini.py | 外部連携 | Gemini Flash-Liteなどの外部APIやファイルストレージを呼び出す。 | google-generativeai | F-04, F-05 |
| app/repositories/user.py | 永続化 | usersテーブルに対するデータベースアクセスを行う。 | sqlalchemy | F-01, F-02 |
| app/repositories/project.py | 永続化 | projectsテーブルおよびreference_filesテーブルに対するデータベースアクセスを行う。 | sqlalchemy | F-03, F-05 |
| app/repositories/chat.py | 永続化 | chat_messagesテーブルに対するデータベースアクセスを行う。 | sqlalchemy | F-04, F-05 |
| app/repositories/document.py | 永続化 | documentsテーブルに対するデータベースアクセスを行う。 | sqlalchemy | F-05 |

## 05 主要処理の手順

### 5.0 索引

| 処理ID | 名称 | トリガー | 選定理由 | 手順数 | 詳細(06) |
|---|---|---|---|---|---|
| F-01 | ユーザー登録する | POST /api/v1/auth/register | ユーザー登録処理において、入力値の検証からリポジトリを介したDB保存までを正確に連係するため、呼び出し順序と例外のハンドリングが重要となる。 | 6 | L-01 |
| F-02 | JWTログインする | POST /api/v1/auth/login | メールアドレスとパスワードによる認証を行ってアクセストークンを発行するため | 7 | L-02 |
| F-03 | プロジェクトを作成し参考資料をアップロードする | POST /api/v1/projects | プロジェクト情報と参考資料ファイルをバリデーションし、トランザクション内でプロジェクトとファイル情報の永続化を行うため。 | 6 | L-03 |
| F-04 | チャットメッセージを送信しAI応答を取得する | POST /api/v1/projects/{id}/chat | チャットメッセージの保存とGemini Flash-Liteを用いたAI応答の生成を確実に行うため | 8 | L-04 |
| F-05 | 4種設計書を自動生成し不足点診断を行う | POST /api/v1/projects/{id}/generate | チャット履歴等を用いた4種の設計書自動生成とAI不足点診断を外部連携や複数リポジトリとの連携を含めて順序立てて実行するため | 9 | L-05 |
| F-06 | 空送信チェックを行う | SCR-003: チャットメッセージ送信 | クライアント側での空送信チェックの検証手順を正確に定義するため | 2 | — |
| F-07 | 設計書コンテンツをクリップボードにコピーまたはダウンロードする | SCR-004: コピー・ダウンロード操作 | 利用者による設計書コンテンツのクリップボードへのコピーまたはファイルダウンロード処理を確実に実行するため。 | 2 | — |

### 5.0.1 処理 × モジュール(セルは手順番号)

| 処理ID | app/core/security.py | app/api/routes/auth.py | app/api/routes/project.py | app/services/auth.py | app/services/project.py | app/ai/agent.py | app/external/gemini.py | app/repositories/user.py | app/repositories/project.py | app/repositories/chat.py | app/repositories/document.py |
|---|---|---|---|---|---|---|---|---|---|---|---|
| F-01 | — | 1 | — | 2 | — | — | — | 3, 4 | — | — | — |
| F-02 | 4, 5 | 1 | — | 2 | — | — | — | 3 | — | — | — |
| F-03 | — | — | 1 | — | 2 | — | — | — | 3, 4 | — | — |
| F-04 | — | — | 1 | — | 2 | 4 | 5 | — | — | 3, 6 | — |
| F-05 | — | — | 1 | — | 2 | 5 | 6 | — | 3, 8 | 4 | 7 |
| F-06 | — | — | — | — | — | — | — | — | — | — | — |
| F-07 | — | — | — | — | — | — | — | — | — | — | — |

### 5.1 F-01 ユーザー登録する

トリガー: POST /api/v1/auth/register

選定理由: ユーザー登録処理において、入力値の検証からリポジトリを介したDB保存までを正確に連係するため、呼び出し順序と例外のハンドリングが重要となる。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/auth.py | 同期 | register | メールアドレス、パスワード | ユーザー登録リクエストを受け付ける | 登録成功メッセージ | — | 1a へ |
| 1a | — | — | — | — | 入力値の形式が不正 | — | — | ValidationError → 422 |
| 2 | app/api/routes/auth.py → app/services/auth.py | 同期 | register_user → 詳細: L-01 | メールアドレス、パスワード | ユーザー登録のビジネスロジックを実行する | 登録済みユーザー情報 | — | — |
| 3 | app/services/auth.py → app/repositories/user.py | 同期 | get_by_email | メールアドレス | 既存のメールアドレスが存在するか確認する | ユーザー情報またはNone | users R | 3a へ |
| 3a | — | — | — | — | 既に登録済みのメールアドレスである | — | — | ConflictError → 409 |
| 4 | app/services/auth.py → app/repositories/user.py | 同期 | create | メールアドレス、ハッシュ化されたパスワード | 新規ユーザーをデータベースに保存する | 作成されたユーザー情報 | users C | — |
| 5 | app/services/auth.py → app/api/routes/auth.py | 戻り | — | 登録成功メッセージ | 登録処理結果を返す | 登録成功メッセージ | — | — |
| 6 | app/api/routes/auth.py → 利用者 | 戻り | — | 登録成功メッセージ | クライアントへレスポンスを返す | 登録成功メッセージ | — | — |

注記: 手順3から手順5が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/repositories/user.py
  P1->>P2: 1: register(メールアドレス、パスワード)
  Note over P1,P2: 1a 入力値の形式が不正 → ValidationError → 422
  P2->>P3: 2: register_user(メールアドレス、パスワード)
  P3->>P4: 3: get_by_email(メールアドレス)
  Note over P3,P4: 3a 既に登録済みのメールアドレスである → ConflictError → 409
  P4-->>P3: (3 の戻り) ユーザー情報またはNone
  P3->>P4: 4: create(メールアドレス、ハッシュ化されたパスワード)
  P4-->>P3: (4 の戻り) 作成されたユーザー情報
  P3-->>P2: 5: 登録成功メッセージ
  P2-->>P1: 6: 登録成功メッセージ
```

### 5.2 F-02 JWTログインする

トリガー: POST /api/v1/auth/login

選定理由: メールアドレスとパスワードによる認証を行ってアクセストークンを発行するため

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/auth.py | 同期 | login | メールアドレス、パスワード | JWTログインリクエストを受け付ける | 認証エンドポイントのレスポンス | — | 1a へ |
| 1a | — | — | — | — | リクエストボディの形式が不正 | — | — | ValidationError → 422 |
| 2 | app/api/routes/auth.py → app/services/auth.py | 同期 | authenticate_user → 詳細: L-02 | メールアドレス、パスワード | ユーザー認証のビジネスロジックを呼び出す | アクセストークン | — | — |
| 3 | app/services/auth.py → app/repositories/user.py | 同期 | get_by_email | メールアドレス | メールアドレスでユーザーを検索する | ユーザー情報 | users R | 3a へ |
| 3a | — | — | — | — | ユーザーが見つからない場合 | — | — | AuthenticationError → 401 |
| 4 | app/services/auth.py → app/core/security.py | 同期 | verify_password | 入力されたパスワード、保存されているハッシュ化パスワード | パスワードを検証する | 検証結果 | — | 4a へ |
| 4a | — | — | — | — | パスワードが一致しない場合 | — | — | AuthenticationError → 401 |
| 5 | app/services/auth.py → app/core/security.py | 同期 | create_access_token | ユーザーID | JWTアクセストークンを生成する | アクセストークン | — | — |
| 6 | app/services/auth.py → app/api/routes/auth.py | 戻り | — | アクセストークン | アクセストークンを返す | アクセストークン | — | — |
| 7 | app/api/routes/auth.py → 利用者 | 戻り | — | アクセストークン | レスポンスとしてアクセストークンを返す | 200 OK | — | — |

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/repositories/user.py
  participant P5 as app/core/security.py
  P1->>P2: 1: login(メールアドレス、パスワード)
  Note over P1,P2: 1a リクエストボディの形式が不正 → ValidationError → 422
  P2->>P3: 2: authenticate_user(メールアドレス、パスワード)
  P3->>P4: 3: get_by_email(メールアドレス)
  Note over P3,P4: 3a ユーザーが見つからない場合 → AuthenticationError → 401
  P4-->>P3: (3 の戻り) ユーザー情報
  P3->>P5: 4: verify_password(入力されたパスワード、保存されているハッシュ化パスワード)
  Note over P3,P5: 4a パスワードが一致しない場合 → AuthenticationError → 401
  P5-->>P3: (4 の戻り) 検証結果
  P3->>P5: 5: create_access_token(ユーザーID)
  P5-->>P3: (5 の戻り) アクセストークン
  P3-->>P2: 6: アクセストークン
  P2-->>P1: 7: アクセストークン
```

### 5.3 F-03 プロジェクトを作成し参考資料をアップロードする

トリガー: POST /api/v1/projects

選定理由: プロジェクト情報と参考資料ファイルをバリデーションし、トランザクション内でプロジェクトとファイル情報の永続化を行うため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/project.py | 同期 | create_project | プロジェクト情報, 参考資料ファイル(txt/md/pdf) | プロジェクト作成リクエストを受け付ける | プロジェクト作成完了結果 | — | 1a へ |
| 1a | — | — | — | — | 入力データまたはファイル形式が不正 | — | — | ValidationError → 400 |
| 2 | app/api/routes/project.py → app/services/project.py | 同期 | create_project → 詳細: L-03 | プロジェクト情報, 参考資料ファイル | プロジェクト作成および参考資料ファイル保存のビジネスロジックを実行する | 作成されたプロジェクト情報 | — | — |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | create_project | プロジェクト情報 | プロジェクト情報をデータベースに登録する | プロジェクトID | projects C | — |
| 4 | app/services/project.py → app/repositories/project.py | 同期 | save_reference_files | プロジェクトID, 参考資料ファイル | 参考資料ファイル情報をデータベースに登録する | 保存完了 | reference_files C | — |
| 5 | app/services/project.py → app/api/routes/project.py | 戻り | — | プロジェクト作成完了結果 | 処理結果をルーターへ返す | プロジェクト作成完了結果 | — | — |
| 6 | app/api/routes/project.py → 利用者 | 戻り | — | プロジェクト作成完了結果 | 利用者へレスポンスを返す | HTTP 201 Created | — | — |

注記: 手順 3〜4 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/project.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  P1->>P2: 1: create_project(プロジェクト情報, 参考資料ファイル(txt/md/pdf))
  Note over P1,P2: 1a 入力データまたはファイル形式が不正 → ValidationError → 400
  P2->>P3: 2: create_project(プロジェクト情報, 参考資料ファイル)
  P3->>P4: 3: create_project(プロジェクト情報)
  P4-->>P3: (3 の戻り) プロジェクトID
  P3->>P4: 4: save_reference_files(プロジェクトID, 参考資料ファイル)
  P4-->>P3: (4 の戻り) 保存完了
  P3-->>P2: 5: プロジェクト作成完了結果
  P2-->>P1: 6: プロジェクト作成完了結果
```

### 5.4 F-04 チャットメッセージを送信しAI応答を取得する

トリガー: POST /api/v1/projects/{id}/chat

選定理由: チャットメッセージの保存とGemini Flash-Liteを用いたAI応答の生成を確実に行うため

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/project.py | 同期 | — | チャットメッセージ | チャット送信のエンドポイントでリクエストを受け付ける | チャットメッセージデータ | — | 1a へ、1b へ |
| 1a | — | — | — | — | リクエストボディが不正である場合 | — | — | ValidationError → 422 |
| 1b | — | — | — | — | 認証エラーの場合 | — | — | UnauthorizedError → 401 |
| 2 | app/api/routes/project.py → app/services/project.py | 同期 | ProjectService.send_chat → 詳細: L-04 | チャットメッセージデータ | チャット送信のビジネスロジックを実行する | AIの応答メッセージ | — | — |
| 3 | app/services/project.py → app/repositories/chat.py | 同期 | ChatRepository.create | ユーザーのチャットメッセージ | ユーザーのチャットメッセージをデータベースに保存する | 保存完了 | chat_messages C | — |
| 4 | app/services/project.py → app/ai/agent.py | 同期 | Agent.get_ai_response | チャットメッセージ | LangChainとLangGraphを用いてLLMとのやり取りを制御する | AIの応答メッセージ | — | — |
| 5 | app/ai/agent.py → app/external/gemini.py | 同期 | GeminiClient.generate_response | プロンプトおよびメッセージ | Gemini Flash-Liteを使用してAI応答メッセージを取得する | AIの応答メッセージ | — | 5a へ |
| 5a | — | — | — | — | 外部API呼び出しに失敗した場合 | — | — | ExternalAPIError → 502 |
| 6 | app/services/project.py → app/repositories/chat.py | 同期 | ChatRepository.create | AIの応答メッセージ | AIの応答メッセージをデータベースに保存する | 保存完了 | chat_messages C | — |
| 7 | app/services/project.py → app/api/routes/project.py | 戻り | — | AIの応答メッセージ | AIの応答メッセージを返す | AIの応答メッセージ | — | — |
| 8 | app/api/routes/project.py → 利用者 | 戻り | — | AIの応答メッセージ | レスポンスとしてAIの応答メッセージを送信する | HTTP 200 OK | — | — |

注記: 手順 2〜6 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/project.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/chat.py
  participant P5 as app/ai/agent.py
  participant P6 as app/external/gemini.py
  P1->>P2: 1: チャットメッセージ
  Note over P1,P2: 1a リクエストボディが不正である場合 → ValidationError → 422
  Note over P1,P2: 1b 認証エラーの場合 → UnauthorizedError → 401
  P2->>P3: 2: ProjectService.send_chat(チャットメッセージデータ)
  P3->>P4: 3: ChatRepository.create(ユーザーのチャットメッセージ)
  P4-->>P3: (3 の戻り) 保存完了
  P3->>P5: 4: Agent.get_ai_response(チャットメッセージ)
  P5->>P6: 5: GeminiClient.generate_response(プロンプトおよびメッセージ)
  Note over P5,P6: 5a 外部API呼び出しに失敗した場合 → ExternalAPIError → 502
  P6-->>P5: (5 の戻り) AIの応答メッセージ
  P5-->>P3: (4 の戻り) AIの応答メッセージ
  P3->>P4: 6: ChatRepository.create(AIの応答メッセージ)
  P4-->>P3: (6 の戻り) 保存完了
  P3-->>P2: 7: AIの応答メッセージ
  P2-->>P1: 8: AIの応答メッセージ
```

### 5.5 F-05 4種設計書を自動生成し不足点診断を行う

トリガー: POST /api/v1/projects/{id}/generate

選定理由: チャット履歴等を用いた4種の設計書自動生成とAI不足点診断を外部連携や複数リポジトリとの連携を含めて順序立てて実行するため

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/project.py | 同期 | generate_documents | project_id | 設計書自動生成と不足点診断のエンドポイントリクエストを受け付ける | 4種の設計書および不足点診断結果 | — | 1a へ |
| 1a | — | — | — | — | プロジェクトが存在しない場合 | — | — | NotFoundError -> 404 |
| 2 | app/api/routes/project.py → app/services/project.py | 同期 | ProjectService.generate_documents → 詳細: L-05 | project_id | 設計書自動生成と不足点診断のビジネスロジックを実行する | 4種の設計書および不足点診断結果 | — | — |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.get_by_id | project_id | プロジェクト情報を取得する | プロジェクト情報 | projects R | — |
| 4 | app/services/project.py → app/repositories/chat.py | 同期 | ChatRepository.get_by_project_id | project_id | チャット履歴を取得する | チャット履歴 | chat_messages R | — |
| 5 | app/services/project.py → app/ai/agent.py | 同期 | Agent.generate_documents_and_diagnosis | プロジェクト情報, チャット履歴 | AIエージェントに設計書自動生成と不足点3段階診断を依頼する | 生成された4種の設計書および不足点診断結果 | — | — |
| 6 | app/ai/agent.py → app/external/gemini.py | 同期 | GeminiClient.generate | プロンプト, チャット履歴 | Gemini APIを呼び出して設計書と診断結果を生成する | 生成テキスト | — | — |
| 7 | app/services/project.py → app/repositories/document.py | 同期 | DocumentRepository.save_documents | project_id, 生成された4種の設計書 | 生成された設計書をデータベースに保存する | 保存完了 | documents CR | — |
| 8 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.update | project_id, ステータス更新情報 | プロジェクト情報を更新する | 更新完了 | projects U | — |
| 9 | app/api/routes/project.py → 利用者 | 戻り | — | 4種の設計書, 不足点診断結果 | 設計書と診断結果を応答として返す | HTTP 200 OK | — | — |

注記: 手順 3〜7 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/project.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  participant P5 as app/repositories/chat.py
  participant P6 as app/ai/agent.py
  participant P7 as app/external/gemini.py
  participant P8 as app/repositories/document.py
  P1->>P2: 1: generate_documents(project_id)
  Note over P1,P2: 1a プロジェクトが存在しない場合 → NotFoundError -> 404
  P2->>P3: 2: ProjectService.generate_documents(project_id)
  P3->>P4: 3: ProjectRepository.get_by_id(project_id)
  P4-->>P3: (3 の戻り) プロジェクト情報
  P3->>P5: 4: ChatRepository.get_by_project_id(project_id)
  P5-->>P3: (4 の戻り) チャット履歴
  P3->>P6: 5: Agent.generate_documents_and_diagnosis(プロジェクト情報, チャット履歴)
  P6->>P7: 6: GeminiClient.generate(プロンプト, チャット履歴)
  P7-->>P6: (6 の戻り) 生成テキスト
  P6-->>P3: (5 の戻り) 生成された4種の設計書および不足点診断結果
  P3->>P8: 7: DocumentRepository.save_documents(project_id, 生成された4種の設計書)
  P8-->>P3: (7 の戻り) 保存完了
  P3->>P4: 8: ProjectRepository.update(project_id, ステータス更新情報)
  P4-->>P3: (8 の戻り) 更新完了
  P3-->>P2: (2 の戻り) 4種の設計書および不足点診断結果
  P2-->>P1: 9: 4種の設計書, 不足点診断結果
```

### 5.6 F-06 空送信チェックを行う

トリガー: SCR-003: チャットメッセージ送信

選定理由: クライアント側での空送信チェックの検証手順を正確に定義するため

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → SCR-003: チャットメッセージ送信 | 同期 | — | チャットメッセージの入力内容 | チャットメッセージの入力内容を入力して送信操作を行う | 入力内容 | — | 1a へ |
| 1a | — | — | — | — | 入力内容が空または空白のみ | — | — | ValidationError → 送信ボタンを無効化またはエラーメッセージを表示する |
| 2 | SCR-003: チャットメッセージ送信 → 利用者 | 戻り | — | 検証結果(送信可否) | 検証結果を利用者に返す | 検証結果(送信可否) | — | — |

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as SCR-003: チャットメッセージ送信
  P1->>P2: 1: チャットメッセージの入力内容
  Note over P1,P2: 1a 入力内容が空または空白のみ → ValidationError → 送信ボタンを無効化またはエラーメッセージを表示する
  P2-->>P1: 2: 検証結果(送信可否)
```

### 5.7 F-07 設計書コンテンツをクリップボードにコピーまたはダウンロードする

トリガー: SCR-004: コピー・ダウンロード操作

選定理由: 利用者による設計書コンテンツのクリップボードへのコピーまたはファイルダウンロード処理を確実に実行するため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → SCR-004: コピー・ダウンロード操作 | 同期 | — | 選択した設計書のMarkdown内容 | クリップボードにコピーまたはダウンロードの操作を行う | 操作のリクエスト | — | 1a へ |
| 1a | — | — | — | — | Markdown内容が空の場合 | — | — | ValidationError → 400エラー |
| 2 | SCR-004: コピー・ダウンロード操作 → 利用者 | 戻り | — | クリップボードのデータまたはダウンロードファイル | クリップボードへのコピー結果またはファイルを返却する | 完了 | — | — |

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as SCR-004: コピー・ダウンロード操作
  P1->>P2: 1: 選択した設計書のMarkdown内容
  Note over P1,P2: 1a Markdown内容が空の場合 → ValidationError → 400エラー
  P2-->>P1: 2: クリップボードのデータまたはダウンロードファイル
```

## 06 処理ロジックの詳細

### 6.0 逆引き(関数 × 手順)

| L-ID | 関数 | モジュール | 呼ばれる手順 |
|---|---|---|---|
| L-01 | register_user | app/services/auth.py | F-01#2 |
| L-02 | authenticate_user | app/services/auth.py | F-02#2 |
| L-03 | create_project | app/services/project.py | F-03#2 |
| L-04 | ProjectService.send_chat | app/services/project.py | F-04#2 |
| L-05 | ProjectService.generate_documents | app/services/project.py | F-05#2 |

### 6.1 L-01 register_user

呼ばれる手順: F-01#2

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def register_user(email: str, password: str) -> dict |
| 引数 | email: 登録するユーザーのメールアドレス / password: 登録するユーザーのパスワード |
| 戻り値 | 登録済みユーザー情報 |
| 例外 | なし |
| 事前条件 | メールアドレスの形式が正しく、未登録であること |
| 事後条件 | users テーブルに新しいユーザーが登録され、その情報が返されること |

擬似フロー:

1. 入力されたメールアドレスの重複を確認する
    - app/repositories/user.py を介して users テーブルを検索する
2. パスワードのハッシュ化を行う
    - 平文のパスワードを安全なアルゴリズムでハッシュ化する
3. ユーザー情報を永続化する
    - users テーブルにメールアドレスとハッシュ化されたパスワードを保存する
4. 登録されたユーザー情報を返却する
    - 保存されたレコードからユーザー情報を取得し、呼び出し元に返す

### 6.2 L-02 authenticate_user

呼ばれる手順: F-02#2

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def authenticate_user(email: str, password: str) -> str: |
| 引数 | email: メールアドレス / password: パスワード |
| 戻り値 | アクセストークン |
| 例外 | ValueError: 認証失敗時(HTTP 401相当) |
| 事前条件 | 入力されたメールアドレスとパスワードが空でないこと |
| 事後条件 | 有効なアクセストークンが返却されること |

擬似フロー:

1. メールアドレスをもとにリポジトリからユーザー情報を取得する
    - app/repositories/user.py の処理を呼び出す
    - ユーザーが存在しない場合は例外を送出する
2. 取得したユーザー情報とパスワードを検証する
    - パスワードのハッシュ値が一致するか確認する
    - 一致しない場合は例外を送出する
3. 認証成功時にアクセストークンを生成して返却する
    - トークン生成処理を実行する
    - 生成されたトークン文字列を戻り値とする

### 6.3 L-03 create_project

呼ばれる手順: F-03#2

モジュール: app/services/project.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def create_project(project_data: ProjectCreate, reference_file: UploadFile) -> Project: |
| 引数 | project_data: プロジェクト情報 / reference_file: 参考資料ファイル |
| 戻り値 | 作成されたプロジェクト情報 |
| 例外 | なし |
| 事前条件 | 有効なユーザー認証が完了していること |
| 事後条件 | プロジェクトがprojectsテーブルに保存され、参考資料ファイルがreference_filesテーブルに紐付けて保存されること |

擬似フロー:

1. 受け取ったプロジェクト情報を検証し、プロジェクトの作成処理の準備を行う
    - プロジェクト情報(project_data)の必須項目を確認する
2. プロジェクト情報をprojectsテーブルに登録して永続化する
    - リポジトリを呼び出して新しいプロジェクトレコードを作成する
    - 作成されたプロジェクトのIDを取得する
3. 参考資料ファイルの保存処理を実行する
    - 参考資料ファイル(reference_file)が存在するか確認する
    - 存在する場合、ファイルをストレージに保存し、reference_filesテーブルにファイル情報を登録する
4. 作成されたプロジェクト情報を返却する
    - 登録したプロジェクト情報と関連する参考資料の情報を構築する
    - 構築したプロジェクト情報を呼び出し元に返す

### 6.4 L-04 ProjectService.send_chat

呼ばれる手順: F-04#2

モジュール: app/services/project.py

| 項目 | 内容 |
|---|---|
| シグネチャ | async def send_chat(self, project_id: int, message: str, user_id: int) -> dict |
| 引数 | project_id: プロジェクトID / message: 送信メッセージ / user_id: ユーザーID |
| 戻り値 | AIの応答メッセージを含む辞書データ |
| 例外 | なし |
| 事前条件 | ユーザーが認証されており、対象プロジェクトが存在すること |
| 事後条件 | 送信されたメッセージが保存され、AIエージェントからの応答メッセージが返されること |

擬似フロー:

1. チャットメッセージデータをリポジトリ経由で保存する
    - チャットメッセージリポジトリを使用してユーザーのメッセージを chat_messages テーブルに登録する
2. プロジェクトおよび関連情報を取得する
    - プロジェクトリポジトリからプロジェクト情報を取得する
    - 必要に応じて関連する reference_files や documents の情報を参照する
3. AIエージェントを呼び出して応答を取得する
    - エージェントモジュールを呼び出し、メッセージとプロジェクト文脈を渡してAI応答を生成する
4. AIの応答メッセージを保存して返却する
    - 生成されたAI応答を chat_messages テーブルに保存する
    - AIの応答メッセージを含むデータを呼び出し元に返す

### 6.5 L-05 ProjectService.generate_documents

呼ばれる手順: F-05#2

モジュール: app/services/project.py

| 項目 | 内容 |
|---|---|
| シグネチャ | async def generate_documents(self, project_id: int) -> dict |
| 引数 | project_id: プロジェクトID |
| 戻り値 | 4種の設計書および不足点診断結果を含む辞書 |
| 例外 | プロジェクトが存在しない場合は ValueError (404), AI生成失敗時は RuntimeError (500) |
| 事前条件 | 指定された project_id のプロジェクトが projects テーブルに存在すること |
| 事後条件 | 4種の設計書が生成され documents テーブルに保存され、不足点診断結果が返却されること |

擬似フロー:

1. プロジェクトの存在確認を行う
    - app/repositories/project.py を用いて project_id のプロジェクト情報を取得する
    - プロジェクトが存在しない場合は例外を送出する
2. 関連データを収集する
    - app/repositories/chat.py を用いて関連する chat_messages を取得する
    - app/repositories/project.py を用いて関連する reference_files を取得する
3. AIエージェントによる設計書自動生成と不足点診断を実行する
    - app/ai/agent.py を呼び出し、チャット履歴と参考ファイルを基に4種の設計書を生成する
    - 同時に不足点診断を実行して診断結果を取得する
4. 生成された設計書を保存する
    - app/repositories/document.py を用いて生成された4種の設計書を documents テーブルに保存する
5. 結果を返却する
    - 4種の設計書データと不足点診断結果をまとめて返却する

## 07 横断事項

| 項目 | 方針 | 関わるファイル(例) |
|---|---|---|
| 例外と HTTP | 発生した例外は app/main.py のグローバル例外ハンドラーで捕捉し、対応する HTTP ステータスコードに変換する。入力値不正は 422 や 400、認証エラーは 401、リソース不存在は 404、重複は 409、外部API連携エラーや生成失敗は 502 または 500 とする。 | app/main.py, app/api/routes/auth.py, app/api/routes/project.py |
| 認証 | すべての保護された API エンドポイントでは app/core/security.py の依存性注入を用いて JWT アクセストークンの検証を行う。アクセストークンの有効期限は 30 分、リフレッシュトークンの有効期限は 14 日とし、リフレッシュには HttpOnly Cookie を使用する。 | app/core/security.py, app/api/routes/auth.py, app/api/routes/project.py |
| トランザクション | データベースへの書き込みを伴う複数の操作(ユーザー登録、プロジェクト作成、チャット履歴保存、設計書保存など)は、サービス層において 1 つのトランザクションとしてコミットまたはロールバックを行う。 | app/services/auth.py, app/services/project.py, app/repositories/user.py, app/repositories/project.py, app/repositories/chat.py, app/repositories/document.py |
| ログ | 機密情報(パスワードや個人情報など)の出力を避け、システムのエラー内容や動作履歴のみを標準出力にログとして記録する。 | app/main.py, app/services/auth.py, app/services/project.py |
| 外部サービスの呼び出し | 外部サービスである Gemini Flash-Lite の呼び出しは app/external/gemini.py に集約する。タイムアウトやエラーが発生した場合は適切に捕捉し、上位のサービス層へ例外を送出して送受信処理を安全に中断または再送を促す。 | app/external/gemini.py, app/ai/agent.py, app/services/project.py |
| レート制限 | ログインの総当たり攻撃、ユーザー登録の大量作成、チャット送信および設計書生成の回数上限を Redis を用いて管理し、不正利用を防ぐ。(要決定: 各エンドポイントの上限回数とウィンドウ時間) | app/api/routes/auth.py, app/api/routes/project.py |
