# M-01-T03 JWTログイン機能の実装

> 種別: 機能 / マイルストーン: M-01 環境構築と認証基盤の実装 / 要件: FR-001, NFR-007, NFR-009 / 依存: M-01-T02

## 目的

メールアドレスとパスワードによるJWTログイン機能を実装し、検証成功時にアクセストークンを発行できるようにする。

## 対象の処理・参照する設計

- 段階5 F-02 JWTログインする
- 段階6 login(`app/api/routes/auth.py`)(設計に無い ── 未定義を参照)
- 段階6 L-02 authenticate_user(`app/services/auth.py`)
- 段階6 get_by_email(`app/repositories/user.py`)(設計に無い ── 未定義を参照)
- 段階6 verify_password(`app/core/security.py`)(設計に無い ── 未定義を参照)
- 段階6 create_access_token(`app/core/security.py`)(設計に無い ── 未定義を参照)
- 段階4 `app/api/routes/auth.py`
- 段階4 `app/services/auth.py`
- 段階4 `app/repositories/user.py`

### シーケンス図(段階5 F-02 JWTログインする の手順から導出)

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/repositories/user.py
  participant P5 as app/core/security.py
  P1->>P2: 1: login(メールアドレス、パスワード)
  Note over P1,P2: 1a リクエストボディの形式が不正 → ValidationError → 422
  P2->>P3: 2: authenticate_user(メールアドレス、パスワード)
  P3->>P4: 3: get_by_email(メールアドレス)
  Note over P3,P4: 3a ユーザーが見つからない場合 → AuthenticationError → 401
  P4-->>P3: (3 の戻り) ユーザー情報
  P3->>P5: 4: verify_password(入力されたパスワード、保存されているハッシュ化パスワード)
  Note over P3,P5: 4a パスワードが一致しない場合 → AuthenticationError → 401
  P5-->>P3: (4 の戻り) 検証結果
  P3->>P5: 5: create_access_token(ユーザーID)
  P5-->>P3: (5 の戻り) アクセストークン
  P3-->>P2: 6: アクセストークン
  P2-->>P1: 7: アクセストークン
```

## 作成・変更するファイル(依存順)

| ファイル | 種類 | 責務 | 根拠 |
|---|---|---|---|
| `app/repositories/user.py` | モジュール | usersテーブルに対するデータベースアクセスを行いメールアドレスでユーザーを検索する | 段階4 |
| `app/services/auth.py` | モジュール | ユーザー認証のビジネスロジックを処理する | 段階4 |
| `app/api/routes/auth.py` | モジュール | JWTログインのエンドポイント定義とリクエストの受け付けを行う | 段階4 |

## 実装の要点(設計に書いていないことだけ)

- 依存される順序としてリポジトリ層、サービス層、APIルーター層の順に実装する。

## テスト観点

| # | 観点 | SUT | ドライバ | スタブ |
|---|---|---|---|---|
| TC-01 | 正しいメールアドレスとパスワードでログインした場合にアクセストークンが返却されること | app/services/auth.py の authenticate_user または app/api/routes/auth.py の login | 単体テスト・結合テスト | app/repositories/user.py の get_by_email をスタブ化してテスト用のユーザー情報を返す |
| TC-02 | 存在しないメールアドレスまたは不正なパスワードの場合に認証エラーとなること | app/services/auth.py の authenticate_user または app/api/routes/auth.py の login | 単体テスト・結合テスト | app/repositories/user.py の get_by_email をスタブ化して挙動を模倣する |

- Given 登録済みのユーザーが存在する時, When 正しいメールアドレスとパスワードでログイン要求を送ると, Then アクセストークンが返却される

## 確認方法

- 自動テストを実行し、すべてのテストが成功することを確認する。

## 未定義・要決定

なし
