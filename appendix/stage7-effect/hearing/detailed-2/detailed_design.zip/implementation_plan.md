# 実装計画書: Devex

## 1 マイルストーン

| M-ID | 名前 | 優先度 | ゴール | 処理 |
|---|---|---|---|---|
| M-01 | 環境構築と認証・横断事項の実装 | Must | 開発環境が整備され、アカウント登録とログイン機能が安全に動作する | F-01, F-02 |
| M-02 | チャットとAI応答の実装 | Must | チャットメッセージ送信とGemini Flash-Lite APIを利用したAI応答・履歴保存ができる | F-03 |
| M-03 | 設計書一括生成とプレビューの実装 | Must | 4種の設計書の一括生成、自己診断の実行、およびプレビューの切り替え表示ができる | F-04, F-05 |

### M-01 環境構築と認証・横断事項の実装(Must)

ゴール: 開発環境が整備され、アカウント登録とログイン機能が安全に動作する

| ID | 種別 | タスク | 処理 | 依存 | モジュール | 環境・設定のファイル(例) |
|---|---|---|---|---|---|---|
| M-01-T01 | 基盤 | 開発環境およびデータベースの土台構築 | — | — | — | Dockerfile, docker-compose.yml, nginx.conf |
| M-01-T02 | 機能 | アカウント登録機能の実装 | F-01 | M-01-T01 | api/routes/auth.py, services/auth.py, models/user.py, repositories/user.py | — |
| M-01-T03 | 機能 | ログインとJWT認証機能の実装 | F-02 | M-01-T02 | api/routes/auth.py, services/auth.py, repositories/user.py | — |

### M-02 チャットとAI応答の実装(Must)

ゴール: チャットメッセージ送信とGemini Flash-Lite APIを利用したAI応答・履歴保存ができる

| ID | 種別 | タスク | 処理 | 依存 | モジュール | 環境・設定のファイル(例) |
|---|---|---|---|---|---|---|
| M-02-T01 | 機能 | チャットメッセージ送信とAI応答機能の実装 | F-03 | M-01-T03 | api/routes/chats.py, services/chat.py, models/chat.py, external/gemini.py, repositories/chat.py | — |

### M-03 設計書一括生成とプレビューの実装(Must)

ゴール: 4種の設計書の一括生成、自己診断の実行、およびプレビューの切り替え表示ができる

| ID | 種別 | タスク | 処理 | 依存 | モジュール | 環境・設定のファイル(例) |
|---|---|---|---|---|---|---|
| M-03-T01 | 機能 | 設計書一括生成と自己診断機能の実装 | F-04 | M-02-T01 | api/routes/documents.py, services/document.py, models/document.py, external/gemini.py, repositories/document.py | — |
| M-03-T02 | 機能 | プレビューの切り替えと設計書表示機能の実装 | F-05 | M-03-T01 | app/page.tsx, services/document.py, models/document.py, repositories/document.py | — |

## 2 処理の割り当て

| 処理ID | 名称 | 単位 |
|---|---|---|
| F-01 | アカウント登録 | M-01-T02 |
| F-02 | ログイン | M-01-T03 |
| F-03 | チャットメッセージ送信とAI応答 | M-02-T01 |
| F-04 | 設計書一括生成と自己診断の実行 | M-03-T01 |
| F-05 | プレビューの切り替えと設計書表示 | M-03-T02 |

## 3 開発環境・事前準備

開発環境としてPython 3.13、FastAPI、Next.js (App Router)、Tamagui、PostgreSQL、Redisを使用する。VPS上のDocker Composeとnginxで配置し、GitHub Actionsを用いて自動デプロイを行う。単体テストおよび結合テストを各レイヤーで実施する。

## 4 想定リスクと対策

| リスク | 対策 |
|---|---|
| Gemini Flash-Lite APIの応答遅延やレートリミットによるエラー発生 | タイムアウト設定とリトライポリシーを実装し、エラー時にはユーザーに再送を促すUIを表示する。納期が厳しい場合は高度な診断ロジックを縮小して基本生成を優先する。 |
| PDFや長文参考資料の読み込み処理におけるパフォーマンス低下 | 参考資料のファイルサイズおよび最大件数(3件)の制限を厳格に適用し、必要に応じてテキスト抽出処理を最適化する。 |
| 認証情報の管理不備によるセキュリティ脆弱性 | JWTの有効期限を厳守し、リフレッシュトークンをHttpOnly Cookieに安全に格納するアクセス制御を徹底する。 |
