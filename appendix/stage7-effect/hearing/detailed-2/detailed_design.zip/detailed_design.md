# 詳細設計書: Devex

## 01 機能(処理)一覧

| 処理ID | 名称 | 種別 | トリガー | 関連画面 | 要件 | 機能グループ | 概要 |
|---|---|---|---|---|---|---|---|
| F-01 | アカウント登録 | API | POST /api/v1/auth/register | SCR-001 | FR-001 | auth | 入力情報を基にアカウントを新規登録する |
| F-02 | ログイン | API | POST /api/v1/auth/login | SCR-002 | FR-002 | auth | 認証を行ってJWTを取得しシステムにアクセスする |
| F-03 | チャットメッセージ送信とAI応答 | API | POST /api/v1/chats | SCR-003 | FR-003, FR-006, FR-008, FR-010 | chats | チャットメッセージと参考資料を受け付けGemini Flash-Lite APIを利用してAI応答を返す |
| F-04 | 設計書一括生成と自己診断の実行 | API | POST /api/v1/documents/generate | SCR-004 | FR-003, FR-004, FR-009 | documents | 4種のMarkdown設計書の自動生成と不足点の自己診断を実行する |
| F-05 | プレビューの切り替えと設計書表示 | 画面 | SCR-004: プレビューの切り替え | SCR-004 | FR-005 | 設計書プレビュー機能 | 選択されたタブに応じて4種のMarkdown設計書と不足点自己診断結果をプレビュー表示する |

## 02 データフロー

### DFD: auth

![データフロー図: auth](diagrams/dfd_auth.svg)

### DFD: chats

![データフロー図: chats](diagrams/dfd_chats.svg)

### DFD: documents

![データフロー図: documents](diagrams/dfd_documents.svg)

### DFD: 設計書プレビュー機能

![データフロー図: 設計書プレビュー機能](diagrams/dfd_設計書プレビュー機能.svg)

### データ辞書

| データ項目 | フィールド | 使う処理 |
|---|---|---|
| AI応答の結果 | response | F-03 |
| JWTを含むアクセスの結果 | access_token | F-02 |
| Markdown設計書 | requirement_definition, external_design, internal_design, implementation_plan | F-04 |
| アカウント登録情報 | email, password | F-01 |
| チャットメッセージと参考資料 | message, reference_materials | F-03 |
| チャット履歴 | id, user_id, message, response | F-03, F-04 |
| ヒアリング結果 | id, content | F-04 |
| プレビュー画面 | view | F-05 |
| ユーザー情報 | id, email, password_hash | F-01, F-02 |
| ログイン情報 | email, password | F-02 |
| 不足点自己診断結果 | level, description | F-04 |
| 生成文書データ | id, content | F-05 |
| 登録完了のメッセージ | message | F-01 |
| 選択されたタブ | tab_name | F-05 |

### 処理概要表(入力 / 処理 / 出力)

| 処理ID | 名称 | 入力 | 処理内容 | 出力 |
|---|---|---|---|---|
| F-01 | アカウント登録 | アカウント登録情報 | 入力情報の検証を行い、アカウントを新規登録してPostgreSQLに保存する。 | 登録完了のメッセージ |
| F-02 | ログイン | ログイン情報 | 認証を行ってJWTを取得し、HttpOnly Cookieを設定する。 | JWTを含むアクセスの結果 |
| F-03 | チャットメッセージ送信とAI応答 | チャットメッセージと参考資料 | 入力されたメッセージと参考資料を受け取り、Gemini Flash-Lite APIを利用してAI応答を生成する。 | AI応答の結果 |
| F-04 | 設計書一括生成と自己診断の実行 | チャット履歴およびヒアリング結果 | 要件定義・外部設計・内部設計・実装計画の4種のMarkdown設計書を自動生成し、不足点の自己診断を実行する。 | 4種のMarkdown設計書と不足点自己診断結果 |
| F-05 | プレビューの切り替えと設計書表示 | 選択されたタブ | 選択されたタブの状態を判定し、対応する4種のMarkdown設計書と不足点自己診断結果を表示する。 | プレビュー画面 |

## 03 データモデル

![ER図(全体)](diagrams/er.svg)

### テーブル定義

#### users

ユーザー情報(users)を管理するテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | ユーザーID |
| email | VARCHAR(255) | — | 不可 | UNIQUE | メールアドレス |
| password_hash | VARCHAR(255) | — | 不可 | — | パスワードハッシュ |

#### chats

チャット履歴(chats)を管理するテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | チャット履歴ID |
| user_id | UUID | FK | 不可 | FK: users(id) ON DELETE CASCADE | ユーザーID |
| message | TEXT | — | 不可 | — | チャットメッセージ |
| response | TEXT | — | 不可 | — | AI応答の結果 |

#### documents

ヒアリング結果(documents)を管理するテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | ヒアリング結果ID |
| content | TEXT | — | 不可 | — | ヒアリング内容 |

#### generated_documents

生成文書データ(generated_documents)を管理するテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | 生成文書データID |
| content | TEXT | — | 不可 | — | 文書内容 |

### CRUD 図(処理 × テーブル)

| 処理ID | 名称 | users | chats | documents | generated_documents |
|---|---|---|---|---|---|
| F-01 | アカウント登録 | C+ | — | — | — |
| F-02 | ログイン | R | — | — | — |
| F-03 | チャットメッセージ送信とAI応答 | — | C+ | — | — |
| F-04 | 設計書一括生成と自己診断の実行 | — | — | C+ | — |
| F-05 | プレビューの切り替えと設計書表示 | — | — | — | R |

記号: 印なし = DFD の線から決まる R / `+` = 書き込みは DFD の線から決まり、C/U/D の区別は人が確定 / `*` = DFD に描いていない分で、人が確定

## 04 ソフトウェア構造

![コンポーネント図(全体)](diagrams/component.svg)

### モジュール一覧

| パス | 層 | 責務 | 主な依存先 | 関わる処理 |
|---|---|---|---|---|
| api/routes/auth.py | 入口 | アカウント登録およびログインのエンドポイントを定義しリクエストを受け付ける。 | services | F-01, F-02 |
| api/routes/chats.py | 入口 | チャットメッセージ送信とAI応答のエンドポイントを定義しリクエストを受け付ける。 | services | F-03 |
| api/routes/documents.py | 入口 | 設計書一括生成と自己診断のエンドポイントを定義しリクエストを受け付ける。 | services | F-04 |
| app/page.tsx | 入口 | 画面やプレビューを表示するUIコンポーネントを提供する。 | services | F-05 |
| services/auth.py | ユースケース | 認証のビジネスロジックを制御する。 | models, repositories | F-01, F-02 |
| services/chat.py | ユースケース | チャットのビジネスロジックを制御する。 | models, external, repositories | F-03 |
| services/document.py | ユースケース | 設計書生成のビジネスロジックを制御する。 | models, external, repositories | F-04 |
| models/user.py | ドメイン | ユーザーのデータ構造とルールを定義する。 | — | F-01, F-02 |
| models/chat.py | ドメイン | チャットのデータ構造とルールを定義する。 | — | F-03 |
| models/document.py | ドメイン | 設計書のデータ構造とルールを定義する。 | — | F-04, F-05 |
| external/gemini.py | 外部連携 | Gemini Flash-Lite APIやLangChain/LangGraphと通信する。 | LangChain/LangGraph | F-03, F-04 |
| repositories/user.py | 永続化 | usersテーブルへのデータ永続化と取得を行う。 | models, PostgreSQL | F-01, F-02 |
| repositories/chat.py | 永続化 | chatsテーブルへのデータ永続化と取得を行う。 | models, PostgreSQL | F-03 |
| repositories/document.py | 永続化 | documentsおよびgenerated_documentsテーブルへのデータ永続化と取得を行う。 | models, PostgreSQL | F-04, F-05 |

## 05 主要処理の手順

### 5.0 索引

| 処理ID | 名称 | トリガー | 選定理由 | 手順数 | 詳細(06) |
|---|---|---|---|---|---|
| F-01 | アカウント登録 | POST /api/v1/auth/register | アカウント登録処理におけるバリデーションチェックとトランザクション管理が重要であるため。 | 6 | L-01 |
| F-02 | ログイン | POST /api/v1/auth/login | ユーザーの認証情報検証とセッション確立のためのJWT発行を安全に行うため。 | 6 | L-02, L-03 |
| F-03 | チャットメッセージ送信とAI応答 | POST /api/v1/chats | チャットメッセージと参考資料を受け取り、Gemini Flash-Lite APIでAI応答を生成してチャット履歴を保存する複雑な一連の処理だから | 6 | L-04 |
| F-04 | 設計書一括生成と自己診断の実行 | POST /api/v1/documents/generate | 4種のMarkdown設計書を一括生成し自己診断を行う複雑なAI連携処理であるため、正確な手順とトランザクション範囲を定義することが重要です。 | 6 | L-05 |
| F-05 | プレビューの切り替えと設計書表示 | SCR-004: プレビューの切り替え | 利用者によるタブ選択に応じて、対応する設計書や診断結果のデータを取得してプレビューを切り替えるため | 6 | — |

### 5.0.1 処理 × モジュール(セルは手順番号)

| 処理ID | api/routes/auth.py | api/routes/chats.py | api/routes/documents.py | app/page.tsx | services/auth.py | services/chat.py | services/document.py | models/user.py | external/gemini.py | repositories/user.py | repositories/chat.py | repositories/document.py |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F-01 | 1 | — | — | — | 2 | — | — | 3 | — | 4 | — | — |
| F-02 | 1 | — | — | — | 2, 4 | — | — | — | — | 3 | — | — |
| F-03 | — | 1 | — | — | — | 2 | — | — | 3 | — | 4 | — |
| F-04 | — | — | 1 | — | — | — | 2 | — | 3 | — | — | 4 |
| F-05 | — | — | — | 1 | — | — | 2 | — | — | — | — | 3 |

### 5.1 F-01 アカウント登録

トリガー: POST /api/v1/auth/register

選定理由: アカウント登録処理におけるバリデーションチェックとトランザクション管理が重要であるため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → api/routes/auth.py | 同期 | register | アカウント登録情報 | アカウント登録のリクエストを受け付ける | 登録処理の実行結果 | — | 1a へ |
| 1a | — | — | — | — | 入力データが不正 | — | — | ValidationError → 400 |
| 2 | api/routes/auth.py → services/auth.py | 同期 | register_user → 詳細: L-01 | アカウント登録情報 | 認証のビジネスロジックを制御しアカウントを新規登録する | ユーザーオブジェクト | — | 2a へ |
| 2a | — | — | — | — | すでに登録済みのメールアドレス | — | — | ConflictError → 409 |
| 3 | services/auth.py → models/user.py | 同期 | validate | アカウント登録情報 | ユーザーのデータ構造とルールに従い検証する | 検証済みデータ | — | — |
| 4 | services/auth.py → repositories/user.py | 同期 | save | 検証済みデータ | usersテーブルにデータを永続化する | 保存完了 | users C | — |
| 5 | services/auth.py → api/routes/auth.py | 戻り | — | 登録完了のメッセージ | 登録完了のメッセージを返す | 登録完了のメッセージ | — | — |
| 6 | api/routes/auth.py → 利用者 | 戻り | — | 登録完了のメッセージ | レスポンスとして登録完了メッセージを返す | 200 OK | — | — |

注記: 手順2〜4が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as api/routes/auth.py
  participant P3 as services/auth.py
  participant P4 as models/user.py
  participant P5 as repositories/user.py
  P1->>P2: 1: register(アカウント登録情報)
  Note over P1,P2: 1a 入力データが不正 → ValidationError → 400
  P2->>P3: 2: register_user(アカウント登録情報)
  Note over P2,P3: 2a すでに登録済みのメールアドレス → ConflictError → 409
  P3->>P4: 3: validate(アカウント登録情報)
  P4-->>P3: (3 の戻り) 検証済みデータ
  P3->>P5: 4: save(検証済みデータ)
  P5-->>P3: (4 の戻り) 保存完了
  P3-->>P2: 5: 登録完了のメッセージ
  P2-->>P1: 6: 登録完了のメッセージ
```

### 5.2 F-02 ログイン

トリガー: POST /api/v1/auth/login

選定理由: ユーザーの認証情報検証とセッション確立のためのJWT発行を安全に行うため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → api/routes/auth.py | 同期 | login | ログイン情報 | ログインリクエストを受け付ける | ログイン情報 | — | — |
| 2 | api/routes/auth.py → services/auth.py | 同期 | authenticate → 詳細: L-02 | ログイン情報 | 認証ビジネスロジックを呼び出す | ユーザー情報 | — | — |
| 3 | services/auth.py → repositories/user.py | 同期 | find_by_email | メールアドレス | ユーザー情報を取得する | ユーザーデータ | users R | 3a へ、3b へ |
| 3a | — | — | — | — | ユーザーが存在しない場合 | — | — | AuthenticationError → 401 |
| 3b | — | — | — | — | パスワードが一致しない場合 | — | — | AuthenticationError → 401 |
| 4 | services/auth.py → services/auth.py | 同期 | create_access_token → 詳細: L-03 | ユーザーデータ | JWTを生成する | JWT | — | — |
| 5 | services/auth.py → api/routes/auth.py | 戻り | — | JWT | JWTを返却する | JWT | — | — |
| 6 | api/routes/auth.py → 利用者 | 戻り | — | JWTを含むアクセスの結果 | HttpOnly CookieにJWTを設定して応答を返す | JWTを含むアクセスの結果 | — | — |

注記: トランザクションは使用しない

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as api/routes/auth.py
  participant P3 as services/auth.py
  participant P4 as repositories/user.py
  P1->>P2: 1: login(ログイン情報)
  P2->>P3: 2: authenticate(ログイン情報)
  P3->>P4: 3: find_by_email(メールアドレス)
  Note over P3,P4: 3a ユーザーが存在しない場合 → AuthenticationError → 401
  Note over P3,P4: 3b パスワードが一致しない場合 → AuthenticationError → 401
  P4-->>P3: (3 の戻り) ユーザーデータ
  P3->>P3: 4: create_access_token(ユーザーデータ)
  P3-->>P2: 5: JWT
  P2-->>P1: 6: JWTを含むアクセスの結果
```

### 5.3 F-03 チャットメッセージ送信とAI応答

トリガー: POST /api/v1/chats

選定理由: チャットメッセージと参考資料を受け取り、Gemini Flash-Lite APIでAI応答を生成してチャット履歴を保存する複雑な一連の処理だから

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → api/routes/chats.py | 同期 | chats | チャットメッセージと参考資料 | チャットメッセージ送信とAI応答のリクエストを受け付ける | リクエストデータ | — | 1a へ |
| 1a | — | — | — | — | リクエストデータが不正な場合 | — | — | ValidationError → 400 |
| 2 | api/routes/chats.py → services/chat.py | 同期 | ChatService.process_chat → 詳細: L-04 | チャットメッセージと参考資料 | チャットのビジネスロジックを制御する | AI応答の結果 | — | — |
| 3 | services/chat.py → external/gemini.py | 同期 | GeminiClient.generate_response | チャットメッセージと参考資料 | Gemini Flash-Lite APIを利用してAI応答を生成する | AI生成テキスト | — | 3a へ |
| 3a | — | — | — | — | 外部API呼び出しに失敗した場合 | — | — | ExternalAPIError → 502 |
| 4 | services/chat.py → repositories/chat.py | 同期 | ChatRepository.create | チャットメッセージとAI応答結果 | チャットデータを永続化する | 保存されたチャットデータ | chats C | — |
| 5 | services/chat.py → api/routes/chats.py | 戻り | — | AI応答の結果 | AI応答の結果を返す | AI応答の結果 | — | — |
| 6 | api/routes/chats.py → 利用者 | 戻り | — | AI応答の結果 | AI応答の結果をレスポンスとして返す | HTTP 200 OK | — | — |

注記: 手順 3〜5 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as api/routes/chats.py
  participant P3 as services/chat.py
  participant P4 as external/gemini.py
  participant P5 as repositories/chat.py
  P1->>P2: 1: chats(チャットメッセージと参考資料)
  Note over P1,P2: 1a リクエストデータが不正な場合 → ValidationError → 400
  P2->>P3: 2: ChatService.process_chat(チャットメッセージと参考資料)
  P3->>P4: 3: GeminiClient.generate_response(チャットメッセージと参考資料)
  Note over P3,P4: 3a 外部API呼び出しに失敗した場合 → ExternalAPIError → 502
  P4-->>P3: (3 の戻り) AI生成テキスト
  P3->>P5: 4: ChatRepository.create(チャットメッセージとAI応答結果)
  P5-->>P3: (4 の戻り) 保存されたチャットデータ
  P3-->>P2: 5: AI応答の結果
  P2-->>P1: 6: AI応答の結果
```

### 5.4 F-04 設計書一括生成と自己診断の実行

トリガー: POST /api/v1/documents/generate

選定理由: 4種のMarkdown設計書を一括生成し自己診断を行う複雑なAI連携処理であるため、正確な手順とトランザクション範囲を定義することが重要です。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → api/routes/documents.py | 同期 | generate_documents | チャット履歴およびヒアリング結果 | 設計書一括生成と自己診断のリクエストを受け付ける | 4種のMarkdown設計書と不足点自己診断結果 | — | — |
| 2 | api/routes/documents.py → services/document.py | 同期 | DocumentService.generate → 詳細: L-05 | チャット履歴およびヒアリング結果 | 設計書一括生成と自己診断のビジネスロジックを制御する | 生成された設計書データ | — | — |
| 3 | services/document.py → external/gemini.py | 同期 | GeminiClient.generate_documents | チャット履歴およびヒアリング結果 | Gemini Flash-Lite APIを使用して4種のMarkdown設計書と自己診断結果を生成する | AI生成結果 | — | 3a へ |
| 3a | — | — | — | — | AI連携での生成に失敗した場合 | — | — | ExternalServiceError → 502 |
| 4 | services/document.py → repositories/document.py | 同期 | DocumentRepository.save | 生成された設計書データ | 生成された設計書と自己診断結果をデータベースに保存する | 保存完了 | documents C | — |
| 5 | services/document.py → api/routes/documents.py | 戻り | — | 4種のMarkdown設計書と不足点自己診断結果 | 生成結果を返す | 4種のMarkdown設計書と不足点自己診断結果 | — | — |
| 6 | api/routes/documents.py → 利用者 | 戻り | — | 4種のMarkdown設計書と不足点自己診断結果 | レスポンスを返す | 4種のMarkdown設計書と不足点自己診断結果 | — | — |

注記: 手順 3 から手順 5 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as api/routes/documents.py
  participant P3 as services/document.py
  participant P4 as external/gemini.py
  participant P5 as repositories/document.py
  P1->>P2: 1: generate_documents(チャット履歴およびヒアリング結果)
  P2->>P3: 2: DocumentService.generate(チャット履歴およびヒアリング結果)
  P3->>P4: 3: GeminiClient.generate_documents(チャット履歴およびヒアリング結果)
  Note over P3,P4: 3a AI連携での生成に失敗した場合 → ExternalServiceError → 502
  P4-->>P3: (3 の戻り) AI生成結果
  P3->>P5: 4: DocumentRepository.save(生成された設計書データ)
  P5-->>P3: (4 の戻り) 保存完了
  P3-->>P2: 5: 4種のMarkdown設計書と不足点自己診断結果
  P2-->>P1: 6: 4種のMarkdown設計書と不足点自己診断結果
```

### 5.5 F-05 プレビューの切り替えと設計書表示

トリガー: SCR-004: プレビューの切り替え

選定理由: 利用者によるタブ選択に応じて、対応する設計書や診断結果のデータを取得してプレビューを切り替えるため

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/page.tsx | 同期 | — | 選択されたタブ | プレビューの切り替え操作を検知する | タブ選択イベント | — | — |
| 2 | app/page.tsx → services/document.py | 同期 | DocumentService.getPreviewContent | 選択されたタブ種別 | タブに対応する設計書または自己診断結果の取得を要求する | プレビューデータ | — | 2a へ |
| 2a | — | — | — | — | 該当する設計書データが存在しない | — | — | NotFoundError → 404 |
| 3 | services/document.py → repositories/document.py | 同期 | DocumentRepository.findByTabType | タブ種別 | generated_documentsテーブルから該当するデータを取得する | 設計書・診断結果データ | generated_documents R | — |
| 4 | repositories/document.py → services/document.py | 戻り | — | 設計書・診断結果データ | データを返却する | 設計書・診断結果データ | — | — |
| 5 | services/document.py → app/page.tsx | 戻り | — | プレビューデータ | プレビューデータを返却する | プレビューデータ | — | — |
| 6 | app/page.tsx → 利用者 | 戻り | — | プレビュー画面 | 取得したデータに基づきプレビュー画面をレンダリングして表示する | プレビュー画面の表示完了 | — | — |

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/page.tsx
  participant P3 as services/document.py
  participant P4 as repositories/document.py
  P1->>P2: 1: 選択されたタブ
  P2->>P3: 2: DocumentService.getPreviewContent(選択されたタブ種別)
  Note over P2,P3: 2a 該当する設計書データが存在しない → NotFoundError → 404
  P3->>P4: 3: DocumentRepository.findByTabType(タブ種別)
  P4-->>P3: 4: 設計書・診断結果データ
  P3-->>P2: 5: プレビューデータ
  P2-->>P1: 6: プレビュー画面
```

## 06 処理ロジックの詳細

### 6.0 逆引き(関数 × 手順)

| L-ID | 関数 | モジュール | 呼ばれる手順 |
|---|---|---|---|
| L-01 | register_user | services/auth.py | F-01#2 |
| L-02 | authenticate | services/auth.py | F-02#2 |
| L-03 | create_access_token | services/auth.py | F-02#4 |
| L-04 | ChatService.process_chat | services/chat.py | F-03#2 |
| L-05 | DocumentService.generate | services/document.py | F-04#2 |

### 6.1 L-01 register_user

呼ばれる手順: F-01#2

モジュール: services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def register_user(user_data: UserCreate) -> User: |
| 引数 | user_data: アカウント登録情報 |
| 戻り値 | 登録されたユーザーオブジェクト |
| 例外 | ConflictError: すでに登録済みのメールアドレスの場合に送出する (HTTP 409) |
| 事前条件 | 有効なアカウント登録情報が提供されていること |
| 事後条件 | users テーブルに新しいユーザーが永続化されること |

擬似フロー:

1. リクエストされたメールアドレスがすでに users テーブルに存在するか確認する
    - リポジトリ経由でメールアドレスを検索する
    - すでに存在する場合は ConflictError を送出する
2. パスワードを安全な形式にハッシュ化する
    - 提供された平文のパスワードを取得する
    - ハッシュアルゴリズムを適用してハッシュ値を得る
3. 新しいユーザーエンティティを作成し users テーブルに保存する
    - ユーザー情報とハッシュ化されたパスワードを組み立てる
    - データベースに永続化する
4. 登録されたユーザーオブジェクトを返却する

### 6.2 L-02 authenticate

呼ばれる手順: F-02#2

モジュール: services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def authenticate(login_info: LoginInfo) -> UserInfo: |
| 引数 | login_info: ログイン情報 |
| 戻り値 | ユーザー情報 |
| 例外 | AuthenticationError: 認証に失敗した場合に送出する / 401 Unauthorized |
| 事前条件 | ログイン情報が正しく入力されていること |
| 事後条件 | 有効なユーザー情報が返却されること |

擬似フロー:

1. 入力されたログイン情報を受け取る
    - login_info からメールアドレスとパスワードを取得する
2. repositories を用いて users テーブルからユーザー情報を検索する
    - 一致するユーザーが存在しない場合は認証エラーとする
3. パスワードの検証を行う
    - 入力されたパスワードと保存されたハッシュ値を比較する
    - 一致しない場合は認証エラーとする
4. 検証されたユーザー情報を構築して返却する
    - UserInfo 形式にデータを詰めて返却する

### 6.3 L-03 create_access_token

呼ばれる手順: F-02#4

モジュール: services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def create_access_token(user_data: dict) -> str: |
| 引数 | user_data: ユーザーデータ |
| 戻り値 | 生成されたJWTの文字列 |
| 例外 | なし |
| 事前条件 | 有効なユーザーデータが渡されていること |
| 事後条件 | 指定されたユーザーデータに基づいてJWTが生成されていること |

擬似フロー:

1. ユーザーデータを受け取る
    - 引数のuser_dataを取得する
2. アクセストークンの有効期限とペイロードを設定する
    - ユーザー情報と有効期限を含むペイロードを作成する
3. 署名を行ってJWTを生成する
    - 秘密鍵とアルゴリズムを用いてJWT文字列を生成する
4. 生成したJWTを返却する
    - 作成したJWT文字列を戻り値として返す

### 6.4 L-04 ChatService.process_chat

呼ばれる手順: F-03#2

モジュール: services/chat.py

| 項目 | 内容 |
|---|---|
| シグネチャ | async def process_chat(message: str, documents: List[str]) -> Dict[str, Any] |
| 引数 | message: チャットメッセージ / documents: 参考資料 |
| 戻り値 | AI応答の結果 |
| 例外 | なし |
| 事前条件 | ユーザが認証済みであり、有効なチャットメッセージと参考資料が入力されていること |
| 事後条件 | チャットのビジネスロジックが正常に制御され、AI応答の結果が返却されること |

擬似フロー:

1. 入力されたチャットメッセージと参考資料を受け取る
    - message と documents の値を取得する
    - 入力データの形式を確認する
2. models および repositories を用いてビジネスロジックを実行する
    - chats や documents、generated_documents に関連するデータを処理する
    - users の状態を確認する
3. external を通じて外部サービス連携やAI応答の生成を行う
    - 参考資料を考慮したプロンプトを構築する
    - AIからの応答結果を取得する
4. 処理結果を整理して呼び出し元へ返却する
    - AI応答の結果を辞書形式にまとめる
    - 正常に結果を返す

### 6.5 L-05 DocumentService.generate

呼ばれる手順: F-04#2

モジュール: services/document.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def generate(self, chat_history: List[Dict[str, Any]], hearing_result: Dict[str, Any]) -> Dict[str, Any]: |
| 引数 | chat_history: チャット履歴 / hearing_result: ヒアリング結果 |
| 戻り値 | 生成された設計書データ |
| 例外 | なし |
| 事前条件 | 呼び出し元においてチャット履歴およびヒアリング結果が正しく取得されていること。 |
| 事後条件 | 設計書一括生成と自己診断のビジネスロジックが実行され、生成された設計書データが返却されること。 |

擬似フロー:

1. 入力されたチャット履歴とヒアリング結果を受け取る
    - チャット履歴データの内容を確認する
    - ヒアリング結果の内容を確認する
2. 設計書一括生成のビジネスロジックを実行する
    - 外部サービスやモデルを利用して設計書ドラフトを作成する
    - 関連するテーブル情報を参照または構築する
3. 自己診断の処理を実行する
    - 生成された設計書データの整合性を検証する
    - 必要に応じて修正や再生成を行う
4. 生成された設計書データをまとめて返却する
    - 結果のデータ構造を整える
    - 呼び出し元へ生成された設計書データを返す

## 07 横断事項

| 項目 | 方針 | 関わるファイル(例) |
|---|---|---|
| 例外と HTTP | APIでエラーが発生した際は、不正な入力には 400 Bad Request、認証失敗には 401 Unauthorized、すでに存在するデータの登録には 409 Conflict、外部APIやAI応答の失敗には 502 Bad Gateway または 500 Internal Server Error を返す。例外発生時はスタックトレースをログに記録し、クライアントにはエラーコードとエラーメッセージを JSON 形式で返却する。 | api/routes/auth.py, api/routes/chats.py, api/routes/documents.py |
| 認証 | メールとパスワードによる認証を行い、JWTのアクセストークンの有効期限は 30 分、リフレッシュトークンの有効期限は 14 日とする。リフレッシュトークンは HttpOnly Cookie に設定し、クロスサイトリクエストフォージェリを防止する。本人以外が他人のプロジェクトを見られないようにアクセス制御を行う。 | api/routes/auth.py, services/auth.py, repositories/user.py |
| トランザクション | データベースへの書き込みを伴う処理（アカウント登録、チャット履歴保存、設計書一括生成後の保存など）では、サービス層またはリポジトリ層でトランザクションを開始する。処理が正常に完了した場合はコミットし、例外が発生した場合はロールバックしてデータの整合性を保つ。 | services/auth.py, services/chat.py, services/document.py, repositories/user.py, repositories/chat.py, repositories/document.py |
| ログ | システムのエラー発生時や重要イベント時には、発生時刻、処理ID、エラー内容、ユーザーIDをログに出力する。ただし、セキュリティおよびプライバシー保護の観点から、AIの入力内容や対話の内容はログに残さない。 | api/routes/auth.py, api/routes/chats.py, api/routes/documents.py, services/chat.py, services/document.py |
| 外部サービスの呼び出し | Gemini Flash-Lite APIを呼び出す際はタイムアウトとリトライのポリシーを適用する。外部APIの呼び出しに失敗した場合は ExternalAPIError または ExternalServiceError を送出の上、適切にエラーハンドリングを行いユーザーに再送を促すUIを表示する。 | external/gemini.py, services/chat.py, services/document.py |
