# M-01-T03 ログインとJWT認証機能の実装

> 種別: 機能 / マイルストーン: M-01 環境構築と認証・横断事項の実装 / 要件: FR-002 / 依存: M-01-T02

## 目的

利用者のログイン要求を受け付け、認証ビジネスロジックを経てJWTアクセストークンを生成し、HttpOnly Cookieに設定して返却できるようにする。

## 対象の処理・参照する設計

- 段階5 F-02 ログイン
- 段階6 login(`api/routes/auth.py`)(設計に無い ── 未定義を参照)
- 段階6 L-02 authenticate(`services/auth.py`)
- 段階6 find_by_email(`repositories/user.py`)(設計に無い ── 未定義を参照)
- 段階6 L-03 create_access_token(`services/auth.py`)
- 段階4 `api/routes/auth.py`
- 段階4 `services/auth.py`
- 段階4 `repositories/user.py`

### シーケンス図(段階5 F-02 ログイン の手順から導出)

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as api/routes/auth.py
  participant P3 as services/auth.py
  participant P4 as repositories/user.py
  P1->>P2: 1: login(ログイン情報)
  P2->>P3: 2: authenticate(ログイン情報)
  P3->>P4: 3: find_by_email(メールアドレス)
  Note over P3,P4: 3a ユーザーが存在しない場合 → AuthenticationError → 401
  Note over P3,P4: 3b パスワードが一致しない場合 → AuthenticationError → 401
  P4-->>P3: (3 の戻り) ユーザーデータ
  P3->>P3: 4: create_access_token(ユーザーデータ)
  P3-->>P2: 5: JWT
  P2-->>P1: 6: JWTを含むアクセスの結果
```

## 作成・変更するファイル(依存順)

| ファイル | 種類 | 責務 | 根拠 |
|---|---|---|---|
| `repositories/user.py` | モジュール | usersテーブルからメールアドレスをもとにユーザー情報を取得する | 段階4 |
| `services/auth.py` | モジュール | 認証ビジネスロジックを実行し、JWTアクセストークンを生成する | 段階4 |
| `api/routes/auth.py` | モジュール | ログインリクエストを受け付け、サービス層を呼び出し、HttpOnly CookieにJWTを設定して応答を返す | 段階4 |

## 実装の要点(設計に書いていないことだけ)

- 依存される順序に従い、 repositories/user.py 、 services/auth.py 、 api/routes/auth.py の順に実装する。

## テスト観点

| # | 観点 | SUT | ドライバ | スタブ |
|---|---|---|---|---|
| TC-01 | 正常なメールアドレスとパスワードでログインした場合にJWTが生成されHttpOnly Cookieに設定されること | api/routes/auth.py の login | 結合テスト(APIテスト) | スタブ不要 ── 実際のデータベースおよびサービス層を使用する |
| TC-02 | 存在しないメールアドレスまたは一致しないパスワードの場合に401 Unauthorizedが返却されること | services/auth.py の authenticate | 単体テスト | repositories/user.py をモック化してユーザー不在やパスワード不一致を再現する |

- Given 登録済みのユーザーが存在する When 正しいメールアドレスとパスワードでログインを要求する Then JWTが生成されHttpOnly Cookieに設定されて返却される
- Given 登録されていないメールアドレスである When ログインを要求する Then AuthenticationErrorが送出され401が返却される

## 確認方法

- POST /api/v1/auth/login に対して正しい認証情報を送信し、ステータスコード200とHttpOnly CookieにJWTが設定されることを確認する。
- 誤った認証情報を送信し、401 Unauthorizedが返却されることを確認する。

## 未定義・要決定

なし
