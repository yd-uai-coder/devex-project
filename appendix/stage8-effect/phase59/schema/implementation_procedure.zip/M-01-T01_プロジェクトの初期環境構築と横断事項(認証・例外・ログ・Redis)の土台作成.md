# M-01-T01 プロジェクトの初期環境構築と横断事項(認証・例外・ログ・Redis)の土台作成

> 種別: 基盤 / マイルストーン: M-01 環境構築と認証基盤の実装 / 要件: — / 依存: なし

## 目的

プロジェクトの初期環境構築を行い、各ORMモデル、Redisキャッシュ連携、および例外・ログの基盤となる app/main.py を作成する。

## 対象の処理・参照する設計

- 段階4 `app/models/user.py`
- 段階4 `app/models/token.py`
- 段階4 `app/models/project.py`
- 段階4 `app/models/chat.py`
- 段階4 `app/models/message.py`
- 段階4 `app/models/generation_job.py`
- 段階4 `app/cache/redis.py`
- 段階4 `app/main.py`

## 作成・変更するファイル(依存順)

| ファイル | 種類 | 責務 | 根拠 |
|---|---|---|---|
| `Dockerfile` | 環境・設定 | Python 3.13と依存パッケージを含むバックエンドのコンテナイメージを定義する | 段階7 開発環境 |
| `docker-compose.yml` | 環境・設定 | PostgreSQL、Redis、バックエンドを統合して起動するための設定を行う | 段階7 開発環境 |
| `app/models/user.py` | モジュール | usersテーブルのORMモデルを定義する | 段階4 app/models/user.py |
| `app/models/token.py` | モジュール | tokensテーブルのORMモデルを定義する | 段階4 app/models/token.py |
| `app/models/project.py` | モジュール | projectsテーブルのORMモデルを定義する | 段階4 app/models/project.py |
| `app/models/chat.py` | モジュール | chatsテーブルのORMモデルを定義する | 段階4 app/models/chat.py |
| `app/models/message.py` | モジュール | messagesテーブルのORMモデルを定義する | 段階4 app/models/message.py |
| `app/models/generation_job.py` | モジュール | generation_jobsテーブルのORMモデルを定義する | 段階4 app/models/generation_job.py |
| `app/cache/redis.py` | モジュール | Redisを用いたトークン失効管理やレート制限を行う | 段階4 app/cache/redis.py |
| `app/main.py` | モジュール | アプリの組み立て、認証のDI、および例外の変換を行う | 段階4 app/main.py |
| `tests/test_main.py` | テスト | 基盤の例外変換や初期起動のテストを行う | 手順書で決める |

## 実装の要点(設計に書いていないことだけ)

- Docker Compose環境でPostgreSQLとRedisが正しく起動することを確認してからORMおよびRedisの接続確認を行う。
- 依存される順序に従い、Docker設定、モデル定義、Redis接続モジュールの順に作成し、最後に app/main.py とテストを実装する。

## テスト観点

| # | 観点 | SUT | ドライバ | スタブ |
|---|---|---|---|---|
| TC-01 | 例外発生時に指定されたステータスコードに変換されること | app/main.py の例外変換機構 | pytest および TestClient | スタブ不要 ── FastAPIの例外ハンドラーの挙動を直接検証するため |
| TC-02 | Redisへの接続と基本的な操作が成功すること | app/cache/redis.py | pytest | スタブ不要 ── 実物のRedisコンテナを使用する |

- Given: アプリケーションが起動している状態でValidationErrorが発生するWhen: APIリクエストを送信するThen: 400 Bad Requestが返却される

## 確認方法

- docker compose up --build によりすべてのコンテナが正常に起動することを確認する。
- pytest を実行してテストがすべて成功することを確認する。

## 未定義・要決定

| 重要度 | 出どころ | 対象 | 内容 | 直す段階 |
|---|---|---|---|---|
| 軽微 | AI | 07章 レート制限 | レート制限の具体的な制限回数やウィンドウ期間の値が定義されていない。 | 段階7 |
