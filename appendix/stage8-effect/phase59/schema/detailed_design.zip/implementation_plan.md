# 実装計画書: Devex(ステージ8効果測定 詳細)(Phase 59 スキーマ確認用)

## 1 マイルストーン

| M-ID | 名前 | 優先度 | ゴール | 処理 |
|---|---|---|---|---|
| M-01 | 環境構築と認証基盤の実装 | Must | 開発環境が立ち上がり、データベースマイグレーションが完了し、JWT認証を使ったユーザー登録・ログインができるようになる。 | F-01, F-02, F-03, F-04 |
| M-02 | プロジェクト管理とチャットヒアリング機能の実装 | Must | プロジェクトを作成・一覧取得でき、Gemini Flash-Liteを用いたSSEストリーミングによるチャットヒアリングと履歴取得ができるようになる。 | F-05, F-06, F-07, F-08 |
| M-03 | 設計書一括生成とAI自己診断機能の実装 | Must | チャット内容を基に4種のMarkdown設計書とAI自己診断結果を非同期で一括生成し、進捗確認・閲覧ができるようになる。 | F-09, F-10, F-11 |

### M-01 環境構築と認証基盤の実装(Must)

ゴール: 開発環境が立ち上がり、データベースマイグレーションが完了し、JWT認証を使ったユーザー登録・ログインができるようになる。

| ID | 種別 | タスク | 処理 | 依存 | モジュール | 環境・設定のファイル(例) |
|---|---|---|---|---|---|---|
| M-01-T01 | 基盤 | プロジェクトの初期環境構築と横断事項(認証・例外・ログ・Redis)の土台作成 | — | — | app/models/user.py, app/models/token.py, app/models/project.py, app/models/chat.py, app/models/message.py, app/models/generation_job.py, app/cache/redis.py, app/main.py | Dockerfile, docker-compose.yml |
| M-01-T02 | 機能 | ユーザー登録する処理の実装 | F-01 | M-01-T01 | app/models/user.py, app/repositories/auth.py, app/services/auth.py, app/api/routes/auth.py, app/main.py | — |
| M-01-T03 | 機能 | ログインする処理の実装 | F-02 | M-01-T02 | app/models/token.py, app/repositories/auth.py, app/cache/redis.py, app/services/auth.py, app/api/routes/auth.py, app/main.py | — |
| M-01-T04 | 機能 | トークンをリフレッシュする処理の実装 | F-03 | M-01-T03 | app/repositories/auth.py, app/cache/redis.py, app/services/auth.py, app/api/routes/auth.py, app/main.py | — |
| M-01-T05 | 機能 | ログアウトする処理の実装 | F-04 | M-01-T04 | app/repositories/auth.py, app/cache/redis.py, app/services/auth.py, app/api/routes/auth.py, app/main.py | — |

### M-02 プロジェクト管理とチャットヒアリング機能の実装(Must)

ゴール: プロジェクトを作成・一覧取得でき、Gemini Flash-Liteを用いたSSEストリーミングによるチャットヒアリングと履歴取得ができるようになる。

| ID | 種別 | タスク | 処理 | 依存 | モジュール | 環境・設定のファイル(例) |
|---|---|---|---|---|---|---|
| M-02-T01 | 機能 | プロジェクト一覧を取得する処理の実装 | F-05 | M-01-T05 | app/repositories/project.py, app/services/project.py, app/api/routes/project.py, app/main.py | — |
| M-02-T02 | 機能 | プロジェクトを作成する処理の実装 | F-06 | M-02-T01 | app/repositories/project.py, app/services/project.py, app/api/routes/project.py, app/main.py | — |
| M-02-T03 | 機能 | チャット履歴を取得する処理の実装 | F-07 | M-02-T02 | app/repositories/project.py, app/repositories/chat.py, app/services/chat.py, app/api/routes/chat.py, app/main.py | — |
| M-02-T04 | 機能 | チャットメッセージを送信する処理の実装 | F-08 | M-02-T03 | app/repositories/project.py, app/repositories/chat.py, app/ai/agent.py, app/services/chat.py, app/api/routes/chat.py, app/main.py | — |

### M-03 設計書一括生成とAI自己診断機能の実装(Must)

ゴール: チャット内容を基に4種のMarkdown設計書とAI自己診断結果を非同期で一括生成し、進捗確認・閲覧ができるようになる。

| ID | 種別 | タスク | 処理 | 依存 | モジュール | 環境・設定のファイル(例) |
|---|---|---|---|---|---|---|
| M-03-T01 | 機能 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する処理の実装 | F-09 | M-02-T04 | app/repositories/project.py, app/repositories/job.py, app/ai/agent.py, app/services/generation.py, app/api/routes/generation.py, app/main.py | — |
| M-03-T02 | 機能 | 設計書生成ジョブの進捗を確認する処理の実装 | F-10 | M-03-T01 | app/repositories/job.py, app/services/generation.py, app/api/routes/generation.py, app/main.py | — |
| M-03-T03 | 機能 | 生成文書および自己診断結果を取得する処理の実装 | F-11 | M-03-T02 | app/repositories/chat.py, app/services/generation.py, app/api/routes/generation.py, app/main.py | — |

## 2 処理の割り当て

| 処理ID | 名称 | 単位 |
|---|---|---|
| F-01 | ユーザー登録する | M-01-T02 |
| F-02 | ログインする | M-01-T03 |
| F-03 | トークンをリフレッシュする | M-01-T04 |
| F-04 | ログアウトする | M-01-T05 |
| F-05 | プロジェクト一覧を取得する | M-02-T01 |
| F-06 | プロジェクトを作成する | M-02-T02 |
| F-07 | チャット履歴を取得する | M-02-T03 |
| F-08 | チャットメッセージを送信する | M-02-T04 |
| F-09 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する | M-03-T01 |
| F-10 | 設計書生成ジョブの進捗を確認する | M-03-T02 |
| F-11 | 生成文書および自己診断結果を取得する | M-03-T03 |

## 3 開発環境・事前準備

開発環境はPython 3.13とFastAPIによるバックエンド、Next.js(App Router)とTamaguiによるフロントエンドをDocker Composeで統合する。データベースにはPostgreSQLを使用し、キャッシュとレート制限にはRedisを利用する。CI/CDパイプラインとしてGitHub Actionsを用い、mainブランチへのpush時にVPS上のDocker Compose環境へ自動デプロイする構成とする。

## 4 想定リスクと対策

| リスク | 対策 |
|---|---|
| Gemini Flash-LiteのAPI制限や応答遅延により、4種の設計書一括生成およびチャットのSSEストリーミングが想定以上に時間がかかる可能性がある。 | 非同期ジョブ機構によるポーリングでの進捗確認を徹底し、タイムアウト対策やプロンプトの最適化を行う。納期が厳しい場合は自己診断の段階数を簡略化する。 |
| 多数の同時リクエストや不正利用によるサーバー負荷、あるいは総当たり攻撃のリスクがある。 | Redisを用いたレート制限を実装し、異常なリクエストに対しては429 Too Many Requestsを返却する。 |
| AIが生成するMarkdown設計書や自己診断結果のフォーマットが不安定になる可能性がある。 | LangChainの出力構造化機能や厳密なプロンプト設計を行い、パースエラー発生時は再生成を行えるように例外処理とリトライ機構を整備する。 |
