# 詳細設計書: Devex(ステージ8効果測定 詳細)(Phase 59 スキーマ確認用)

## 01 機能(処理)一覧

| 処理ID | 名称 | 種別 | トリガー | 関連画面 | 要件 | 機能グループ | 概要 |
|---|---|---|---|---|---|---|---|
| F-01 | ユーザー登録する | API | POST /api/v1/auth/register | SCR-001 | FR-001, FR-011, FR-012 | auth | メールアドレスとパスワードを受け取り新規ユーザーを作成する |
| F-02 | ログインする | API | POST /api/v1/auth/login | SCR-001 | FR-001, FR-002, FR-011 | auth | 認証情報を検証しアクセストークンおよびリフレッシュトークンを発行する |
| F-03 | トークンをリフレッシュする | API | POST /api/v1/auth/refresh | — | FR-002 | auth | 有効なリフレッシュトークンを使用して新規アクセストークンを再発給する |
| F-04 | ログアウトする | API | POST /api/v1/auth/logout | SCR-001, SCR-002, SCR-003 | FR-002, FR-012 | auth | リフレッシュトークンを無効化してログアウト処理を行う |
| F-05 | プロジェクト一覧を取得する | API | GET /api/v1/projects | SCR-002 | FR-003, FR-009 | projects | ユーザーがアクセス可能なプロジェクトの一覧を返す |
| F-06 | プロジェクトを作成する | API | POST /api/v1/projects | SCR-002 | FR-003, FR-009 | projects | 新しいプロジェクト名称と参考資料を受け取りプロジェクトを作成する |
| F-07 | チャット履歴を取得する | API | GET /api/v1/projects/{id}/messages | SCR-002 | FR-003, FR-004, FR-009 | messages | 指定プロジェクトの過去のチャットメッセージ一覧を返す |
| F-08 | チャットメッセージを送信する | API | POST /api/v1/projects/{id}/chat | SCR-002 | FR-003, FR-004, FR-010, FR-011 | chat | メッセージを受け取りSSEストリーミングによるAIの対話応答を返す |
| F-09 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する | API+バッチ | POST /api/v1/projects/{id}/generate | SCR-003 | FR-003, FR-005, FR-006, FR-010, FR-011 | generate | 4種の設計書一括生成と自己診断の非同期ジョブを開始しジョブIDを返す |
| F-10 | 設計書生成ジョブの進捗を確認する | API | GET /api/v1/projects/{id}/generate/status | SCR-003 | FR-003, FR-005, FR-006 | generate | 生成ジョブの進捗ステータスや完了時の生成文書・診断結果を返す |
| F-11 | 生成文書および自己診断結果を取得する | API | GET /api/v1/projects/{id}/documents | SCR-003 | FR-003, FR-005, FR-006, FR-009 | documents | 確定した4種のMarkdown設計書とAIの自己診断結果を返す |

## 02 データフロー

### DFD: auth

![データフロー図: auth](diagrams/dfd_auth.svg)

### DFD: projects

![データフロー図: projects](diagrams/dfd_projects.svg)

### DFD: messages

![データフロー図: messages](diagrams/dfd_messages.svg)

### DFD: chat

![データフロー図: chat](diagrams/dfd_chat.svg)

### DFD: generate

![データフロー図: generate](diagrams/dfd_generate.svg)

### データ辞書

| データ項目 | フィールド | 使う処理 |
|---|---|---|
| auth_tokens | access_token, refresh_token | F-02, F-03 |
| chat_ai_response | response_stream | F-08 |
| chat_history_request | access_token, project_id | F-07, F-08 |
| chat_message_input | message, project_id, access_token | F-08 |
| chat_messages_list | messages | F-07 |
| credentials | email, password | F-02 |
| generation_job_data | id, project_id, status | F-09, F-10 |
| job_id | job_id | F-09 |
| job_status_request | access_token, project_id, job_id | F-10 |
| job_status_result | status, generated_documents, diagnostic_results | F-10 |
| logout_result | success | F-04 |
| new_access_token | access_token | F-03 |
| project_create_request | access_token, project_name, reference_materials | F-06 |
| project_id_and_token | access_token, project_id | F-07, F-08, F-09 |
| project_info | id, project_name | F-06 |
| project_list_request | access_token | F-05 |
| projects_list | projects | F-05 |
| refresh_token_input | refresh_token | F-03, F-04 |
| registration_request | email, password | F-01 |
| user_info | id, email | F-01, F-02 |

### 処理概要表(入力 / 処理 / 出力)

| 処理ID | 名称 | 入力 | 処理内容 | 出力 |
|---|---|---|---|---|
| F-01 | ユーザー登録する | メールアドレスとパスワード | 標準的な条件に基づき入力を検証し、新規ユーザー情報をPostgreSQLに保存する。 | 作成されたユーザーの情報 |
| F-02 | ログインする | 認証情報 | 認証情報を検証し、アクセストークンおよびリフレッシュトークンを発行してHttpOnly Cookieに設定する。 | アクセストークンおよびリフレッシュトークン |
| F-03 | トークンをリフレッシュする | リフレッシュトークン | 有効なリフレッシュトークンを使用してトークン失効状態を検証し、新規アクセストークンを再発給する。 | 新規アクセストークン |
| F-04 | ログアウトする | リフレッシュトークン | Redisを用いてリフレッシュトークンを無効化しログアウト処理を行う。 | ログアウト完了の結果 |
| F-05 | プロジェクト一覧を取得する | アクセストークン | 認証情報を検証し、ユーザーがアクセス可能なプロジェクトのみをPostgreSQLから取得する。 | プロジェクト一覧 |
| F-06 | プロジェクトを作成する | 新しいプロジェクト名称と参考資料 | 参考資料の形式を検証し、新しいプロジェクトと参考資料をPostgreSQLに保存する。 | 作成されたプロジェクトの情報 |
| F-07 | チャット履歴を取得する | 指定プロジェクトIDとアクセストークン | プロジェクトへのアクセス権限を検証し、指定プロジェクトのチャット履歴をPostgreSQLから取得する。 | 過去のチャットメッセージ一覧 |
| F-08 | チャットメッセージを送信する | メッセージと指定プロジェクトID | プロジェクトへのアクセス権限を検証し、Gemini Flash-Liteを用いたAIの対話応答を生成してSSEストリーミングで返すとともにチャットメッセージをPostgreSQLに保存する。 | SSEストリーミングによるAIの対話応答 |
| F-09 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する | 指定プロジェクトID | プロジェクトへのアクセス権限を検証し、4種の設計書一括生成と自己診断の非同期ジョブを開始してジョブIDを発行する。 | ジョブID |
| F-10 | 設計書生成ジョブの進捗を確認する | 指定プロジェクトIDとジョブID | プロジェクトへのアクセス権限を検証し、生成ジョブの進捗ステータスや完了時の生成文書・診断結果を取得する。 | 生成ジョブの進捗ステータスや完了時の生成文書・診断結果 |
| F-11 | 生成文書および自己診断結果を取得する | 指定プロジェクトID | プロジェクトへのアクセス権限を検証し、確定した4種のMarkdown設計書とAIの自己診断結果をPostgreSQLから取得する。 | 4種のMarkdown設計書とAIの自己診断結果 |

## 03 データモデル

![ER図(全体)](diagrams/er.svg)

### テーブル定義

#### users

ユーザー情報テーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | ユーザーID |
| email | VARCHAR(255) | — | 不可 | UNIQUE | メールアドレス |
| password | VARCHAR(255) | — | 不可 | — | パスワードハッシュ |

#### tokens

トークン管理テーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | トークンID |
| user_id | UUID | FK | 不可 | FK to users(id) ON DELETE CASCADE | ユーザーID |
| refresh_token | VARCHAR(512) | — | 不可 | UNIQUE | リフレッシュトークン |

#### projects

プロジェクト情報テーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | プロジェクトID |
| user_id | UUID | FK | 不可 | FK to users(id) ON DELETE CASCADE | 所有者ユーザーID |
| project_name | VARCHAR(255) | — | 不可 | — | プロジェクト名称 |
| reference_materials | TEXT | — | 可 | — | 参考資料 |

#### chats

チャットセッションまたは関連テーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | チャットID |
| project_id | UUID | FK | 不可 | FK to projects(id) ON DELETE CASCADE | プロジェクトID |

#### messages

チャットメッセージテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | メッセージID |
| project_id | UUID | FK | 不可 | FK to projects(id) ON DELETE CASCADE | プロジェクトID |
| message | TEXT | — | 不可 | — | メッセージ内容 |

#### generation_jobs

生成ジョブ管理テーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | ジョブID |
| project_id | UUID | FK | 不可 | FK to projects(id) ON DELETE CASCADE | プロジェクトID |
| status | VARCHAR(50) | — | 不可 | — | ジョブの進捗ステータス |
| generated_documents | TEXT | — | 可 | — | 生成文書 |
| diagnostic_results | TEXT | — | 可 | — | 診断結果 |

### CRUD 図(処理 × テーブル)

| 処理ID | 名称 | users | tokens | projects | chats | messages | generation_jobs |
|---|---|---|---|---|---|---|---|
| F-01 | ユーザー登録する | C+ | — | — | — | — | — |
| F-02 | ログインする | R | C+ | — | — | — | — |
| F-03 | トークンをリフレッシュする | — | RU* | — | — | — | — |
| F-04 | ログアウトする | — | U+ | — | — | — | — |
| F-05 | プロジェクト一覧を取得する | — | — | R | — | — | — |
| F-06 | プロジェクトを作成する | — | — | C+ | — | — | — |
| F-07 | チャット履歴を取得する | — | — | — | — | R | — |
| F-08 | チャットメッセージを送信する | — | — | R | C+ | C* | — |
| F-09 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する | — | — | — | — | — | C+ |
| F-10 | 設計書生成ジョブの進捗を確認する | — | — | — | — | — | R |
| F-11 | 生成文書および自己診断結果を取得する | — | — | — | R* | — | — |

記号: 印なし = DFD の線から決まる R / `+` = 書き込みは DFD の線から決まり、C/U/D の区別は人が確定 / `*` = DFD に描いていない分で、人が確定

## 04 ソフトウェア構造

![コンポーネント図(全体)](diagrams/component.svg)

### モジュール一覧

| パス | 層 | 責務 | 主な依存先 | 関わる処理 |
|---|---|---|---|---|
| app/models/user.py | 永続化 | usersテーブルのORMモデルを定義する | sqlalchemy | — |
| app/models/token.py | 永続化 | tokensテーブルのORMモデルを定義する | sqlalchemy | — |
| app/models/project.py | 永続化 | projectsテーブルのORMモデルを定義する | sqlalchemy | — |
| app/models/chat.py | 永続化 | chatsテーブルのORMモデルを定義する | sqlalchemy | — |
| app/models/message.py | 永続化 | messagesテーブルのORMモデルを定義する | sqlalchemy | — |
| app/models/generation_job.py | 永続化 | generation_jobsテーブルのORMモデルを定義する | sqlalchemy | — |
| app/repositories/auth.py | 永続化 | usersおよびtokensテーブルへのデータ永続化と取得を行う | app/models/user.py, app/models/token.py | F-01, F-02, F-03, F-04 |
| app/repositories/project.py | 永続化 | projectsテーブルへのデータ永続化と取得を行う | app/models/project.py | F-05, F-06, F-08 |
| app/repositories/chat.py | 永続化 | chatsおよびmessagesテーブルへのデータ永続化と取得を行う | app/models/chat.py, app/models/message.py | F-07, F-08, F-11 |
| app/repositories/job.py | 永続化 | generation_jobsテーブルへのデータ永続化と取得を行う | app/models/generation_job.py | F-09, F-10 |
| app/ai/agent.py | 外部連携 | LangChainとLangGraphを用いたチャット応答と設計書生成・診断を行う | langchain, langgraph | F-08, F-09, F-10 |
| app/cache/redis.py | 外部連携 | Redisを用いたトークン失効管理やレート制限を行う | redis | F-02, F-03, F-04, F-11 |
| app/services/auth.py | ユースケース | 認証機能のビジネスロジックを制御する | app/repositories/auth.py, app/cache/redis.py | F-01, F-02, F-03, F-04 |
| app/services/project.py | ユースケース | プロジェクト管理と参考資料検証のビジネスロジックを制御する | app/repositories/project.py | F-05, F-06 |
| app/services/chat.py | ユースケース | チャット履歴取得とAI対話応答のビジネスロジックを制御する | app/repositories/chat.py, app/repositories/project.py, app/ai/agent.py | F-07, F-08 |
| app/services/generation.py | ユースケース | 設計書一括生成およびAI自己診断ジョブのビジネスロジックを制御する | app/repositories/job.py, app/repositories/chat.py, app/ai/agent.py | F-09, F-10, F-11 |
| app/api/routes/auth.py | 入口 | 認証に関するAPIエンドポイントの定義とリクエストの受け付けを行う | app/services/auth.py | F-01, F-02, F-03, F-04 |
| app/api/routes/project.py | 入口 | プロジェクト管理に関するAPIエンドポイントの定義とリクエストの受け付けを行う | app/services/project.py | F-05, F-06 |
| app/api/routes/chat.py | 入口 | チャットに関するAPIエンドポイントの定義とリクエストの受け付けを行う | app/services/chat.py | F-07, F-08 |
| app/api/routes/generation.py | 入口 | 設計書生成と文書取得に関するAPIエンドポイントの定義とリクエストの受け付けを行う | app/services/generation.py | F-09, F-10, F-11 |
| app/main.py | 入口 | アプリの組み立て、認証のDI、および例外の変換を行う | app/api/routes/auth.py, app/api/routes/project.py, app/api/routes/chat.py, app/api/routes/generation.py, fastapi | 全処理 |

## 05 主要処理の手順

### 5.0 索引

| 処理ID | 名称 | トリガー | 選定理由 | 手順数 | 詳細(06) |
|---|---|---|---|---|---|
| F-01 | ユーザー登録する | POST /api/v1/auth/register | メールアドレスとパスワードによる新規ユーザー登録処理において、重複チェックと安全なパスワードハッシュ化を行って永続化するため。 | 6 | L-01 |
| F-02 | ログインする | POST /api/v1/auth/login | 利用者からの認証情報を受け取り、ユーザー検証とトークン発行、HttpOnly Cookieへの設定を安全に行うため。 | 6 | L-02 |
| F-03 | トークンをリフレッシュする | POST /api/v1/auth/refresh | 有効なリフレッシュトークンを使用してトークン失効状態を検証し、新規アクセストークンを安全に再発給するため | 7 | L-03 |
| F-04 | ログアウトする | POST /api/v1/auth/logout | ログアウト処理においてリフレッシュトークンをキャッシュおよび永続層で確実に無効化するため | 6 | L-04 |
| F-05 | プロジェクト一覧を取得する | GET /api/v1/projects | アクセストークンを検証した上で、該当ユーザーがアクセス可能なプロジェクトの一覧を安全に取得するため。 | 5 | L-05 |
| F-06 | プロジェクトを作成する | POST /api/v1/projects | プロジェクト名称と参考資料を受け取り、参考資料の検証を行った上でプロジェクトを作成してデータベースに永続化する | 6 | — |
| F-07 | チャット履歴を取得する | GET /api/v1/projects/{id}/messages | 指定されたプロジェクトのアクセス権限を検証し、messagesテーブルからチャット履歴を取得して返すため | 6 | — |
| F-08 | チャットメッセージを送信する | POST /api/v1/projects/{id}/chat | チャットメッセージを受信し、アクセス権限の検証とAI応答のSSEストリーミング生成、DB保存を同時に行うため。 | 7 | — |
| F-09 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する | POST /api/v1/projects/{id}/generate | プロジェクトの権限確認を行い、設計書生成と自己診断の非同期ジョブを作成してIDを返すため。 | 7 | — |
| F-10 | 設計書生成ジョブの進捗を確認する | GET /api/v1/projects/{id}/generate/status | プロジェクトへのアクセス権限を検証した上で、generation_jobsテーブルから設計書生成ジョブの進捗ステータスや結果を確実取得するため | 6 | — |
| F-11 | 生成文書および自己診断結果を取得する | GET /api/v1/projects/{id}/documents | 指定されたプロジェクトIDに対するアクセス権限を検証し、確定した4種のMarkdown設計書とAIの自己診断結果を安全に取得するため。 | 5 | — |

### 5.0.1 処理 × モジュール(セルは手順番号)

| 処理ID | app/repositories/auth.py | app/repositories/project.py | app/repositories/chat.py | app/repositories/job.py | app/ai/agent.py | app/cache/redis.py | app/services/auth.py | app/services/project.py | app/services/chat.py | app/services/generation.py | app/api/routes/auth.py | app/api/routes/project.py | app/api/routes/chat.py | app/api/routes/generation.py |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F-01 | 3 | — | — | — | — | — | 2 | — | — | — | 1 | — | — | — |
| F-02 | 3 | — | — | — | — | 4 | 2 | — | — | — | 1 | — | — | — |
| F-03 | 4, 5 | — | — | — | — | 3 | 2 | — | — | — | 1 | — | — | — |
| F-04 | 4 | — | — | — | — | 3 | 2 | — | — | — | 1 | — | — | — |
| F-05 | — | 3 | — | — | — | — | — | 2 | — | — | — | 1 | — | — |
| F-06 | — | 3 | — | — | — | — | — | 2 | — | — | — | 1 | — | — |
| F-07 | — | 3 | 4 | — | — | — | — | — | 2 | — | — | — | 1 | — |
| F-08 | — | 3 | 4 | — | 5 | — | — | — | 2 | — | — | — | 1 | — |
| F-09 | — | 3 | — | 4 | 5 | — | — | — | — | 2 | — | — | — | 1 |
| F-10 | — | — | — | 3 | — | — | — | — | — | 2, 4 | — | — | — | 1 |
| F-11 | — | — | 3 | — | — | — | — | — | — | 2 | — | — | — | 1 |

### 5.1 F-01 ユーザー登録する

トリガー: POST /api/v1/auth/register

選定理由: メールアドレスとパスワードによる新規ユーザー登録処理において、重複チェックと安全なパスワードハッシュ化を行って永続化するため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/auth.py | 同期 | register | メールアドレス, パスワード | ユーザー登録リクエストを受け付ける | 登録されたユーザー情報 | — | 1a へ |
| 1a | — | — | — | — | 入力形式が不正 | — | — | ValidationError → 400 |
| 2 | app/api/routes/auth.py → app/services/auth.py | 同期 | register → 詳細: L-01 | メールアドレス, パスワード | ユーザー登録ビジネスロジックを実行する | ユーザー情報 | — | 2a へ |
| 2a | — | — | — | — | メールアドレスが既に存在する | — | — | ConflictError → 409 |
| 3 | app/services/auth.py → app/repositories/auth.py | 同期 | create_user | メールアドレス, ハッシュ化されたパスワード | usersテーブルに新規ユーザー情報を保存する | ユーザー情報 | users C | — |
| 4 | app/repositories/auth.py → app/services/auth.py | 戻り | — | ユーザー情報 | 作成されたユーザー情報を返す | ユーザー情報 | — | — |
| 5 | app/services/auth.py → app/api/routes/auth.py | 戻り | — | ユーザー情報 | ユーザー情報を返す | ユーザー情報 | — | — |
| 6 | app/api/routes/auth.py → 利用者 | 戻り | — | ユーザー情報 | 作成されたユーザー情報を応答する | 201 Created | — | — |

注記: 手順2〜4が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/repositories/auth.py
  P1->>P2: 1: register(メールアドレス, パスワード)
  Note over P1,P2: 1a 入力形式が不正 → ValidationError → 400
  P2->>P3: 2: register(メールアドレス, パスワード)
  Note over P2,P3: 2a メールアドレスが既に存在する → ConflictError → 409
  P3->>P4: 3: create_user(メールアドレス, ハッシュ化されたパスワード)
  P4-->>P3: 4: ユーザー情報
  P3-->>P2: 5: ユーザー情報
  P2-->>P1: 6: ユーザー情報
```

### 5.2 F-02 ログインする

トリガー: POST /api/v1/auth/login

選定理由: 利用者からの認証情報を受け取り、ユーザー検証とトークン発行、HttpOnly Cookieへの設定を安全に行うため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/auth.py | 同期 | login | 認証情報 | ログインリクエストを受け付ける | ログインレスポンス | — | 1a へ |
| 1a | — | — | — | — | リクエストパラメータが不正 | — | — | ValidationError → 422 |
| 2 | app/api/routes/auth.py → app/services/auth.py | 同期 | AuthService.authenticate_user → 詳細: L-02 | 認証情報 | 認証情報を検証しユーザーを取得する | ユーザー情報 | users R | 2a へ |
| 2a | — | — | — | — | ユーザーが存在しないまたはパスワードが不一致 | — | — | AuthenticationError → 401 |
| 3 | app/services/auth.py → app/repositories/auth.py | 同期 | AuthRepository.create_token | ユーザーID | アクセストークンおよびリフレッシュトークンを発行して保存する | トークン情報 | tokens C | — |
| 4 | app/services/auth.py → app/cache/redis.py | 同期 | RedisCache.set_token | トークン情報 | Redisにトークン情報を登録してセッション管理を行う | 登録完了 | — | — |
| 5 | app/services/auth.py → app/api/routes/auth.py | 戻り | — | アクセストークンおよびリフレッシュトークン | トークンを返す | トークン情報 | — | — |
| 6 | app/api/routes/auth.py → 利用者 | 戻り | — | アクセストークンおよびリフレッシュトークン | HttpOnly Cookieにトークンを設定してレスポンスを返す | ログイン成功 | — | — |

注記: 手順 3〜5 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/repositories/auth.py
  participant P5 as app/cache/redis.py
  P1->>P2: 1: login(認証情報)
  Note over P1,P2: 1a リクエストパラメータが不正 → ValidationError → 422
  P2->>P3: 2: AuthService.authenticate_user(認証情報)
  Note over P2,P3: 2a ユーザーが存在しないまたはパスワードが不一致 → AuthenticationError → 401
  P3->>P4: 3: AuthRepository.create_token(ユーザーID)
  P4-->>P3: (3 の戻り) トークン情報
  P3->>P5: 4: RedisCache.set_token(トークン情報)
  P5-->>P3: (4 の戻り) 登録完了
  P3-->>P2: 5: アクセストークンおよびリフレッシュトークン
  P2-->>P1: 6: アクセストークンおよびリフレッシュトークン
```

### 5.3 F-03 トークンをリフレッシュする

トリガー: POST /api/v1/auth/refresh

選定理由: 有効なリフレッシュトークンを使用してトークン失効状態を検証し、新規アクセストークンを安全に再発給するため

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/auth.py | 同期 | — | リフレッシュトークン | POST /api/v1/auth/refresh を受け付ける | リクエストデータ | — | — |
| 2 | app/api/routes/auth.py → app/services/auth.py | 同期 | AuthService.refresh_token → 詳細: L-03 | リフレッシュトークン | トークンのリフレッシュ処理を呼び出す | 新規アクセストークン | — | 2a へ |
| 2a | — | — | — | — | リフレッシュトークンが無効または有効期限切れの場合 | — | — | UnauthorizedError → 401 |
| 3 | app/services/auth.py → app/cache/redis.py | 同期 | RedisCache.is_revoked | リフレッシュトークン | Redisを使用してトークンの失効状態を検証する | 失効状態 | — | 3a へ |
| 3a | — | — | — | — | トークンが失効済みの絵場合 | — | — | UnauthorizedError → 401 |
| 4 | app/services/auth.py → app/repositories/auth.py | 同期 | AuthRepository.get_token_info | リフレッシュトークン | DBからリフレッシュトークン情報を取得・検証する | トークン情報 | tokens R | 4a へ |
| 4a | — | — | — | — | トークンが存在しない場合 | — | — | UnauthorizedError → 401 |
| 5 | app/services/auth.py → app/repositories/auth.py | 同期 | AuthRepository.update_token_status | トークンID, 更新情報 | 必要に応じてトークン情報を更新する | 更新完了 | tokens U | — |
| 6 | app/services/auth.py → app/api/routes/auth.py | 戻り | — | 新規アクセストークン | 新規アクセストークンを返す | 新規アクセストークン | — | — |
| 7 | app/api/routes/auth.py → 利用者 | 戻り | — | 新規アクセストークン | APIレスポンスとして新規アクセストークンを返す | HTTP 200 OK とアクセストークン | — | — |

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/cache/redis.py
  participant P5 as app/repositories/auth.py
  P1->>P2: 1: リフレッシュトークン
  P2->>P3: 2: AuthService.refresh_token(リフレッシュトークン)
  Note over P2,P3: 2a リフレッシュトークンが無効または有効期限切れの場合 → UnauthorizedError → 401
  P3->>P4: 3: RedisCache.is_revoked(リフレッシュトークン)
  Note over P3,P4: 3a トークンが失効済みの絵場合 → UnauthorizedError → 401
  P4-->>P3: (3 の戻り) 失効状態
  P3->>P5: 4: AuthRepository.get_token_info(リフレッシュトークン)
  Note over P3,P5: 4a トークンが存在しない場合 → UnauthorizedError → 401
  P5-->>P3: (4 の戻り) トークン情報
  P3->>P5: 5: AuthRepository.update_token_status(トークンID, 更新情報)
  P5-->>P3: (5 の戻り) 更新完了
  P3-->>P2: 6: 新規アクセストークン
  P2-->>P1: 7: 新規アクセストークン
```

### 5.4 F-04 ログアウトする

トリガー: POST /api/v1/auth/logout

選定理由: ログアウト処理においてリフレッシュトークンをキャッシュおよび永続層で確実に無効化するため

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/auth.py | 同期 | logout | リフレッシュトークン | ログアウトAPIリクエストを受け付ける | レスポンス | — | 1a へ |
| 1a | — | — | — | — | リクエストボディ不正 | — | — | ValidationError → 422 |
| 2 | app/api/routes/auth.py → app/services/auth.py | 同期 | logout → 詳細: L-04 | リフレッシュトークン | ログアウト処理のビジネスロジックを実行する | ログアウト完了の結果 | — | — |
| 3 | app/services/auth.py → app/cache/redis.py | 同期 | revoke_token | リフレッシュトークン | Redisを用いてリフレッシュトークンを無効化する | 無効化完了 | — | — |
| 4 | app/services/auth.py → app/repositories/auth.py | 同期 | revoke_token | リフレッシュトークン | データベース内のトークン情報を無効化する | 更新完了 | tokens U | — |
| 5 | app/services/auth.py → app/api/routes/auth.py | 戻り | — | ログアウト完了の結果 | 結果を返す | ログアウト完了の結果 | — | — |
| 6 | app/api/routes/auth.py → 利用者 | 戻り | — | ログアウト完了の結果 | レスポンスを返却する | HTTP 200 OK | — | — |

注記: 手順 2〜4 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/cache/redis.py
  participant P5 as app/repositories/auth.py
  P1->>P2: 1: logout(リフレッシュトークン)
  Note over P1,P2: 1a リクエストボディ不正 → ValidationError → 422
  P2->>P3: 2: logout(リフレッシュトークン)
  P3->>P4: 3: revoke_token(リフレッシュトークン)
  P4-->>P3: (3 の戻り) 無効化完了
  P3->>P5: 4: revoke_token(リフレッシュトークン)
  P5-->>P3: (4 の戻り) 更新完了
  P3-->>P2: 5: ログアウト完了の結果
  P2-->>P1: 6: ログアウト完了の結果
```

### 5.5 F-05 プロジェクト一覧を取得する

トリガー: GET /api/v1/projects

選定理由: アクセストークンを検証した上で、該当ユーザーがアクセス可能なプロジェクトの一覧を安全に取得するため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/project.py | 同期 | get_projects | アクセストークン | プロジェクト一覧取得APIへのリクエストを受け付ける | プロジェクト一覧レスポンス | — | 1a へ |
| 1a | — | — | — | — | アクセストークンが無効または期限切れである | — | — | UnauthorizedError → 401 |
| 2 | app/api/routes/project.py → app/services/project.py | 同期 | ProjectService.get_projects → 詳細: L-05 | アクセストークン | プロジェクト一覧取得のビジネスロジックを呼び出す | プロジェクト一覧データ | — | — |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.get_by_user_id | ユーザーID | ユーザーに紐づくプロジェクト一覧をデータベースから取得する | プロジェクトモデルのリスト | projects R | — |
| 4 | app/services/project.py → app/api/routes/project.py | 戻り | — | プロジェクト一覧データ | 取得したプロジェクト一覧を返す | プロジェクト一覧 | — | — |
| 5 | app/api/routes/project.py → 利用者 | 戻り | — | プロジェクト一覧 | APIレスポンスとしてプロジェクト一覧を返す | HTTP 200 OK と プロジェクト一覧 | — | — |

注記: トランザクションは読み取り専用の単一クエリとして処理されるため明示的な範囲指定は不要

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/project.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  P1->>P2: 1: get_projects(アクセストークン)
  Note over P1,P2: 1a アクセストークンが無効または期限切れである → UnauthorizedError → 401
  P2->>P3: 2: ProjectService.get_projects(アクセストークン)
  P3->>P4: 3: ProjectRepository.get_by_user_id(ユーザーID)
  P4-->>P3: (3 の戻り) プロジェクトモデルのリスト
  P3-->>P2: 4: プロジェクト一覧データ
  P2-->>P1: 5: プロジェクト一覧
```

### 5.6 F-06 プロジェクトを作成する

トリガー: POST /api/v1/projects

選定理由: プロジェクト名称と参考資料を受け取り、参考資料の検証を行った上でプロジェクトを作成してデータベースに永続化する

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/project.py | 同期 | create_project | 新しいプロジェクト名称と参考資料 | プロジェクト作成リクエストを受け付ける | プロジェクト作成処理の起動 | — | 1a へ |
| 1a | — | — | — | — | リクエストの形式が不正 | — | — | ValidationError → 400 |
| 2 | app/api/routes/project.py → app/services/project.py | 同期 | ProjectService.create_project | 新しいプロジェクト名称と参考資料 | 参考資料の形式を検証しプロジェクト作成ビジネスロジックを実行する | 作成されたプロジェクトの情報 | — | 2a へ |
| 2a | — | — | — | — | 参考資料の形式が無効 | — | — | ValueError → 400 |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.create | 検証済みプロジェクトデータ | プロジェクトをデータベースに保存する | 保存されたプロジェクトのエンティティ | projects C | — |
| 4 | app/repositories/project.py → app/services/project.py | 戻り | — | 保存されたプロジェクトのエンティティ | リポジトリ層からサービス層へ結果を返す | 作成されたプロジェクトの情報 | — | — |
| 5 | app/services/project.py → app/api/routes/project.py | 戻り | — | 作成されたプロジェクトの情報 | サービス層からAPI層へ結果を返す | 作成されたプロジェクトの情報 | — | — |
| 6 | app/api/routes/project.py → 利用者 | 戻り | — | 作成されたプロジェクトの情報 | 作成されたプロジェクトの情報を返却する | 201 Created とプロジェクト情報 | — | — |

注記: 手順 2〜4 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/project.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  P1->>P2: 1: create_project(新しいプロジェクト名称と参考資料)
  Note over P1,P2: 1a リクエストの形式が不正 → ValidationError → 400
  P2->>P3: 2: ProjectService.create_project(新しいプロジェクト名称と参考資料)
  Note over P2,P3: 2a 参考資料の形式が無効 → ValueError → 400
  P3->>P4: 3: ProjectRepository.create(検証済みプロジェクトデータ)
  P4-->>P3: 4: 保存されたプロジェクトのエンティティ
  P3-->>P2: 5: 作成されたプロジェクトの情報
  P2-->>P1: 6: 作成されたプロジェクトの情報
```

### 5.7 F-07 チャット履歴を取得する

トリガー: GET /api/v1/projects/{id}/messages

選定理由: 指定されたプロジェクトのアクセス権限を検証し、messagesテーブルからチャット履歴を取得して返すため

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/chat.py | 同期 | get_messages | プロジェクトID, アクセストークン | チャット履歴取得APIへのリクエストを受け付ける | チャット履歴一覧 | — | 1a へ |
| 1a | — | — | — | — | 認証トークンが無効または期限切れ | — | — | HTTP 401 Unauthorized |
| 2 | app/api/routes/chat.py → app/services/chat.py | 同期 | ChatService.get_messages | プロジェクトID, ユーザーID | チャット履歴取得のビジネスロジックを実行する | チャットメッセージ一覧 | — | 2a へ |
| 2a | — | — | — | — | プロジェクトが存在しない、またはアクセス権限がない | — | — | HTTP 403 Forbidden または 404 Not Found |
| 3 | app/services/chat.py → app/repositories/project.py | 同期 | ProjectRepository.get_project | プロジェクトID, ユーザーID | プロジェクトの存在およびアクセス権限を検証する | プロジェクト情報 | projects R | — |
| 4 | app/services/chat.py → app/repositories/chat.py | 同期 | ChatRepository.get_messages | プロジェクトID | 指定プロジェクトに関連するチャットメッセージ一覧を取得する | メッセージ一覧データ | messages R | — |
| 5 | app/services/chat.py → app/api/routes/chat.py | 戻り | — | チャットメッセージ一覧 | 取得したメッセージ一覧を返す | チャット履歴一覧 | — | — |
| 6 | app/api/routes/chat.py → 利用者 | 戻り | — | チャット履歴一覧 | APIレスポンスとしてチャット履歴を返却する | HTTP 200 OK | — | — |

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/chat.py
  participant P3 as app/services/chat.py
  participant P4 as app/repositories/project.py
  participant P5 as app/repositories/chat.py
  P1->>P2: 1: get_messages(プロジェクトID, アクセストークン)
  Note over P1,P2: 1a 認証トークンが無効または期限切れ → HTTP 401 Unauthorized
  P2->>P3: 2: ChatService.get_messages(プロジェクトID, ユーザーID)
  Note over P2,P3: 2a プロジェクトが存在しない、またはアクセス権限がない → HTTP 403 Forbidden または 404 Not Found
  P3->>P4: 3: ProjectRepository.get_project(プロジェクトID, ユーザーID)
  P4-->>P3: (3 の戻り) プロジェクト情報
  P3->>P5: 4: ChatRepository.get_messages(プロジェクトID)
  P5-->>P3: (4 の戻り) メッセージ一覧データ
  P3-->>P2: 5: チャットメッセージ一覧
  P2-->>P1: 6: チャット履歴一覧
```

### 5.8 F-08 チャットメッセージを送信する

トリガー: POST /api/v1/projects/{id}/chat

選定理由: チャットメッセージを受信し、アクセス権限の検証とAI応答のSSEストリーミング生成、DB保存を同時に行うため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/chat.py | 同期 | send_chat_message | プロジェクトID、メッセージ | チャットメッセージ送信のリクエストを受け付ける | SSEレスポンス | — | — |
| 2 | app/api/routes/chat.py → app/services/chat.py | 同期 | ChatService.process_message | プロジェクトID、メッセージ | チャットメッセージ処理のビジネスロジックを呼び出す | SSEストリームジェネレータ | — | — |
| 3 | app/services/chat.py → app/repositories/project.py | 同期 | ProjectRepository.get_project | プロジェクトID | プロジェクトの存在とアクセス権限を検証するためデータを取得する | プロジェクト情報 | projects R | 3a へ |
| 3a | — | — | — | — | プロジェクトが見つからない場合 | — | — | NotFoundError → 404 |
| 4 | app/services/chat.py → app/repositories/chat.py | 同期 | ChatRepository.create_chat_and_message | プロジェクトID、メッセージ | 送信されたチャットメッセージをデータベースに保存する | 保存されたメッセージ情報 | chats C, messages C | — |
| 5 | app/services/chat.py → app/ai/agent.py | 同期 | Agent.stream_chat_response | メッセージ、プロジェクト履歴 | Gemini Flash-Liteを用いてAIの対話応答を生成する | AI応答のテキストストリーム | — | — |
| 6 | app/services/chat.py → app/api/routes/chat.py | 戻り | — | SSEストリームジェネレータ | SSEストリーミング応答を返す | SSEストリーム | — | — |
| 7 | app/api/routes/chat.py → 利用者 | 戻り | — | SSEストリーム | AIの対話応答をSSEストリーミングで返却する | 完了 | — | — |

注記: 手順 3〜5 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/chat.py
  participant P3 as app/services/chat.py
  participant P4 as app/repositories/project.py
  participant P5 as app/repositories/chat.py
  participant P6 as app/ai/agent.py
  P1->>P2: 1: send_chat_message(プロジェクトID、メッセージ)
  P2->>P3: 2: ChatService.process_message(プロジェクトID、メッセージ)
  P3->>P4: 3: ProjectRepository.get_project(プロジェクトID)
  Note over P3,P4: 3a プロジェクトが見つからない場合 → NotFoundError → 404
  P4-->>P3: (3 の戻り) プロジェクト情報
  P3->>P5: 4: ChatRepository.create_chat_and_message(プロジェクトID、メッセージ)
  P5-->>P3: (4 の戻り) 保存されたメッセージ情報
  P3->>P6: 5: Agent.stream_chat_response(メッセージ、プロジェクト履歴)
  P6-->>P3: (5 の戻り) AI応答のテキストストリーム
  P3-->>P2: 6: SSEストリームジェネレータ
  P2-->>P1: 7: SSEストリーム
```

### 5.9 F-09 設計書一括生成およびAI自己診断の非同期ジョブを開始する

トリガー: POST /api/v1/projects/{id}/generate

選定理由: プロジェクトの権限確認を行い、設計書生成と自己診断の非同期ジョブを作成してIDを返すため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/generation.py | 同期 | generate_documents | プロジェクトID | 設計書一括生成およびAI自己診断の非同期ジョブ開始のリクエストを受け付ける | HTTPレスポンス(ジョブID) | — | 1a へ |
| 1a | — | — | — | — | 認証エラーまたは権限なし | — | — | HTTP 401 または 403 エラーを返す |
| 2 | app/api/routes/generation.py → app/services/generation.py | 同期 | GenerationService.start_generation_job | プロジェクトID, ユーザー情報 | 設計書生成ジョブ開始のビジネスロジックを呼び出す | ジョブID | — | — |
| 3 | app/services/generation.py → app/repositories/project.py | 同期 | ProjectRepository.get_project | プロジェクトID | 指定されたプロジェクトへのアクセス権限を検証するためにプロジェクト情報を取得する | プロジェクト情報 | projects R | 3a へ |
| 3a | — | — | — | — | プロジェクトが存在しない | — | — | NotFoundError → 404 |
| 4 | app/services/generation.py → app/repositories/job.py | 同期 | JobRepository.create_job | プロジェクトID, ジョブステータス | generation_jobsテーブルに新規の生成ジョブレコードを作成する | 作成されたジョブ情報 | generation_jobs C | — |
| 5 | app/services/generation.py → app/ai/agent.py | 非同期 | Agent.run_generation_job_async | ジョブID, プロジェクトID | 4種の設計書一括生成とAI自己診断の非同期ジョブをバックグラウンドで起動する | — | — | — |
| 6 | app/services/generation.py → app/api/routes/generation.py | 戻り | — | ジョブID | 発行されたジョブIDを呼び出し元に返す | ジョブID | — | — |
| 7 | app/api/routes/generation.py → 利用者 | 戻り | — | ジョブID | 非同期ジョブの開始を受け付け、ジョブIDをレスポンスとして返す | HTTP 202 応答 | — | — |

注記: 手順 3〜5 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/generation.py
  participant P3 as app/services/generation.py
  participant P4 as app/repositories/project.py
  participant P5 as app/repositories/job.py
  participant P6 as app/ai/agent.py
  P1->>P2: 1: generate_documents(プロジェクトID)
  Note over P1,P2: 1a 認証エラーまたは権限なし → HTTP 401 または 403 エラーを返す
  P2->>P3: 2: GenerationService.start_generation_job(プロジェクトID, ユーザー情報)
  P3->>P4: 3: ProjectRepository.get_project(プロジェクトID)
  Note over P3,P4: 3a プロジェクトが存在しない → NotFoundError → 404
  P4-->>P3: (3 の戻り) プロジェクト情報
  P3->>P5: 4: JobRepository.create_job(プロジェクトID, ジョブステータス)
  P5-->>P3: (4 の戻り) 作成されたジョブ情報
  P3-)P6: 5: Agent.run_generation_job_async(ジョブID, プロジェクトID)
  P3-->>P2: 6: ジョブID
  P2-->>P1: 7: ジョブID
```

### 5.10 F-10 設計書生成ジョブの進捗を確認する

トリガー: GET /api/v1/projects/{id}/generate/status

選定理由: プロジェクトへのアクセス権限を検証した上で、generation_jobsテーブルから設計書生成ジョブの進捗ステータスや結果を確実取得するため

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/generation.py | 同期 | get_generation_status | プロジェクトID, ジョブID | 設計書生成ジョブの進捗確認リクエストを受け付ける | 進捗ステータスと結果データ | — | — |
| 2 | app/api/routes/generation.py → app/services/generation.py | 同期 | GenerationService.get_status | プロジェクトID, ジョブID | 生成ジョブの進捗ステータス取得処理を呼び出す | 進捗ステータスと結果データ | — | — |
| 3 | app/services/generation.py → app/repositories/job.py | 同期 | JobRepository.find_by_id | ジョブID | generation_jobsテーブルからジョブ情報を取得する | ジョブ情報 | generation_jobs R | 3a へ |
| 3a | — | — | — | — | ジョブが存在しない | — | — | NotFoundError → 404 |
| 4 | app/services/generation.py → app/services/generation.py | 同期 | — | ジョブ情報, プロジェクトID | プロジェクトIDの一致およびアクセス権限を検証する | 検証済みジョブ情報 | — | 4a へ |
| 4a | — | — | — | — | プロジェクトIDが一致しない | — | — | ForbiddenError → 403 |
| 5 | app/services/generation.py → app/api/routes/generation.py | 戻り | — | 進捗ステータス, 生成文書, 診断結果 | 取得したジョブの進捗ステータスと結果を返す | 進捗データ | — | — |
| 6 | app/api/routes/generation.py → 利用者 | 戻り | — | 進捗ステータス, 生成文書, 診断結果 | APIレスポンスとして進捗データを返却する | HTTP 200 OK | — | — |

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/generation.py
  participant P3 as app/services/generation.py
  participant P4 as app/repositories/job.py
  P1->>P2: 1: get_generation_status(プロジェクトID, ジョブID)
  P2->>P3: 2: GenerationService.get_status(プロジェクトID, ジョブID)
  P3->>P4: 3: JobRepository.find_by_id(ジョブID)
  Note over P3,P4: 3a ジョブが存在しない → NotFoundError → 404
  P4-->>P3: (3 の戻り) ジョブ情報
  P3->>P3: 4: ジョブ情報, プロジェクトID
  Note over P3,P3: 4a プロジェクトIDが一致しない → ForbiddenError → 403
  P3-->>P2: 5: 進捗ステータス, 生成文書, 診断結果
  P2-->>P1: 6: 進捗ステータス, 生成文書, 診断結果
```

### 5.11 F-11 生成文書および自己診断結果を取得する

トリガー: GET /api/v1/projects/{id}/documents

選定理由: 指定されたプロジェクトIDに対するアクセス権限を検証し、確定した4種のMarkdown設計書とAIの自己診断結果を安全に取得するため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/generation.py | 同期 | get_documents | project_id, authorization token | 生成文書および自己診断結果取得APIへリクエストを送信する | HTTPレスポンス | — | 1a へ、1b へ |
| 1a | — | — | — | — | トークンが無効または期限切れ | — | — | HTTP 401 Unauthorized |
| 1b | — | — | — | — | プロジェクトが存在しないかアクセス権がない | — | — | HTTP 403 Forbidden または 404 Not Found |
| 2 | app/api/routes/generation.py → app/services/generation.py | 同期 | GenerationService.get_documents | project_id, user_id | 生成文書と自己診断結果の取得処理を呼び出す | 生成文書および自己診断結果データ | — | — |
| 3 | app/services/generation.py → app/repositories/chat.py | 同期 | ChatRepository.get_documents | project_id | chatsテーブルから確定した4種のMarkdown設計書とAIの自己診断結果を取得する | 生成文書および自己診断結果 | chats R | 3a へ |
| 3a | — | — | — | — | 該当プロジェクトの生成文書が存在しない | — | — | NotFoundError → 404 |
| 4 | app/services/generation.py → app/api/routes/generation.py | 戻り | — | 生成文書および自己診断結果データ | 取得した設計書と自己診断結果をAPI層へ返す | 生成文書および自己診断結果データ | — | — |
| 5 | app/api/routes/generation.py → 利用者 | 戻り | — | 生成文書および自己診断結果データ | 利用者へHTTPレスポンスとして返す | HTTP 200 OK | — | — |

注記: トランザクションは使用しない読み取り専用処理である。

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/generation.py
  participant P3 as app/services/generation.py
  participant P4 as app/repositories/chat.py
  P1->>P2: 1: get_documents(project_id, authorization token)
  Note over P1,P2: 1a トークンが無効または期限切れ → HTTP 401 Unauthorized
  Note over P1,P2: 1b プロジェクトが存在しないかアクセス権がない → HTTP 403 Forbidden または 404 Not Found
  P2->>P3: 2: GenerationService.get_documents(project_id, user_id)
  P3->>P4: 3: ChatRepository.get_documents(project_id)
  Note over P3,P4: 3a 該当プロジェクトの生成文書が存在しない → NotFoundError → 404
  P4-->>P3: (3 の戻り) 生成文書および自己診断結果
  P3-->>P2: 4: 生成文書および自己診断結果データ
  P2-->>P1: 5: 生成文書および自己診断結果データ
```

## 06 処理ロジックの詳細

### 6.0 逆引き(関数 × 手順)

| L-ID | 関数 | モジュール | 呼ばれる手順 |
|---|---|---|---|
| L-01 | register | app/services/auth.py | F-01#2 |
| L-02 | AuthService.authenticate_user | app/services/auth.py | F-02#2 |
| L-03 | AuthService.refresh_token | app/services/auth.py | F-03#2 |
| L-04 | logout | app/services/auth.py | F-04#2 |
| L-05 | ProjectService.get_projects | app/services/project.py | F-05#2 |

### 6.1 L-01 register

呼ばれる手順: F-01#2

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def register(email: str, password: str) -> dict |
| 引数 | email: メールアドレス / password: パスワード |
| 戻り値 | 登録されたユーザー情報 |
| 例外 | ConflictError: メールアドレスが既に存在する場合、HTTP 409 Conflict を送出する |
| 事前条件 | メールアドレスとパスワードが有効な形式であること |
| 事後条件 | ユーザーが正常に登録され、ユーザー情報が返却されること |

擬似フロー:

1. 入力されたメールアドレスの既存存在確認を行う
    - app/repositories/auth.pyを使用してユーザーを検索する
    - 既に存在する場合はConflictErrorを送出する
2. パスワードのハッシュ化などの登録前処理を行う
    - 平文のパスワードを安全な方式でハッシュ化する
3. ユーザー情報を永続化する
    - app/repositories/auth.pyを使用してusersテーブルに新しいユーザーを保存する
4. 登録されたユーザー情報を構築して返却する
    - 保存されたデータの必要な項目を辞書型にまとめて戻り値とする

### 6.2 L-02 AuthService.authenticate_user

呼ばれる手順: F-02#2

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def authenticate_user(credentials: AuthCredentials) -> UserEntity: |
| 引数 | credentials: 認証情報 |
| 戻り値 | ユーザー情報 |
| 例外 | AuthenticationError: ユーザーが存在しないまたはパスワードが不一致の場合に送出され、HTTPの401ステータスとして扱われる |
| 事前条件 | 認証情報の入力値が形式的に妥当であること |
| 事後条件 | 検証済みのユーザー情報が返却されること |

擬似フロー:

1. リポジトリを介してusersテーブルから対象のユーザー情報を取得する
    - app/repositories/auth.pyの関数を呼び出す
2. 取得したユーザー情報の存在とパスワードの一致を検証する
    - ユーザーが存在しない場合はAuthenticationErrorを送出する
    - パスワードが不一致の場合はAuthenticationErrorを送出する
3. 検証に成功したユーザー情報を返却する

### 6.3 L-03 AuthService.refresh_token

呼ばれる手順: F-03#2

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def refresh_token(self, refreshToken: str) -> str |
| 引数 | refreshToken: リフレッシュトークン |
| 戻り値 | 新規アクセストークン |
| 例外 | UnauthorizedError (リフレッシュトークンが無効または有効期限切れの場合、HTTP 401) |
| 事前条件 | 有効なリフレッシュトークンが存在すること |
| 事後条件 | 新規アクセストークンが発行されること |

擬似フロー:

1. リフレッシュトークンの検証を行う
    - app/repositories/auth.py または app/cache/redis.py を利用してトークンの存在と有効性を確認する
    - トークンが無効または有効期限切れの場合は UnauthorizedError を送出する
2. 新規アクセストークンを発行する
    - 検証されたトークンに紐づくユーザー情報を取得する
    - 新しいアクセストークンを生成する
3. 生成した新規アクセストークンを返却する
    - アクセストークンを呼び出し元へ返す

### 6.4 L-04 logout

呼ばれる手順: F-04#2

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def logout(refresh_token: str) -> None: |
| 引数 | refresh_token: リフレッシュトークン |
| 戻り値 | なし |
| 例外 | トークンが無効または存在しない場合は ValueError を送出する |
| 事前条件 | 有効なリフレッシュトークンが渡されていること |
| 事後条件 | リフレッシュトークンが無効化され、キャッシュから削除されること |

擬似フロー:

1. リフレッシュトークンの検証を行う
    - app/repositories/auth.py を呼び出し、リフレッシュトークンの有効性を確認する
    - 無効な場合は ValueError を送出する
2. トークンの無効化処理を実行する
    - app/repositories/auth.py を呼び出し、該当するトークンを無効状態にする
3. キャッシュからセッション情報を削除する
    - app/cache/redis.py を呼び出し、リフレッシュトークンに関連するキャッシュを削除する

### 6.5 L-05 ProjectService.get_projects

呼ばれる手順: F-05#2

モジュール: app/services/project.py

| 項目 | 内容 |
|---|---|
| シグネチャ | async def get_projects(self, token: str) -> List[Project] |
| 引数 | token: アクセストークン |
| 戻り値 | プロジェクト一覧データ |
| 例外 | トークンが無効または有効期限切れの場合、認証エラーを送出する |
| 事前条件 | 有効なアクセストークンが渡されていること |
| 事後条件 | 指定されたユーザーに紐づくプロジェクト一覧が正常に取得されること |

擬似フロー:

1. アクセストークンを検証してユーザーを特定する
    - リポジトリ層または認証処理を呼び出してトークンを検証する
    - 無効なトークンの場合は例外を送出する
2. プロジェクトリポジトリからプロジェクト一覧を取得する
    - 特定されたユーザーIDに紐づくデータを projects テーブルから検索する
3. 取得したプロジェクト一覧のデータを整形して戻り値として返却する
    - 結果を呼び出し元へ渡す形式に変換する

## 07 横断事項

| 項目 | 方針 | 関わるファイル(例) |
|---|---|---|
| 例外と HTTP | 発生した例外は app/main.py の例外変換機構ですべて捕捉し、ValidationError は 400 Bad Request、AuthenticationError や UnauthorizedError は 401 Unauthorized、NotFoundError は 404 Not Found、ConflictError は 409 Conflict、その他の予期せぬ例外は 500 Internal Server Error にマッピングしてクライアントへ返却する。AIの応答に失敗した場合は 500 としメッセージを保存しない。 | app/main.py, app/services/auth.py, app/services/chat.py, app/services/generation.py |
| 認証 | JWTを用いた認証を実装し、アクセストークンの有効期限は30分、リフレッシュトークンの有効期限は14日とする。リフレッシュトークンはHttpOnly Cookieに設定し、ログアウト時やリフレッシュ時にRedisを用いてトークンの失効管理およびトークンローテーションを行う。 | app/api/routes/auth.py, app/services/auth.py, app/repositories/auth.py, app/cache/redis.py |
| トランザクション | 複数のテーブル更新や外部連携を伴う一連のデータ操作(ユーザー登録、ログイン、プロジェクト作成、チャットメッセージ送信など)は、サービス層から呼び出される永続化処理の範囲で単一のトランザクションとして扱い、エラー発生時はロールバックする。読み取り専用の処理や非同期のバッチジョブ開始については個別に処理する。 | app/services/auth.py, app/services/project.py, app/services/chat.py, app/services/generation.py, app/repositories/auth.py, app/repositories/project.py, app/repositories/chat.py, app/repositories/job.py |
| ログ | セキュリティ上の理由から、ユーザーが入力した対話内容や機密情報はアプリケーションログに残さないものとする。ログにはエラーの有無、処理時刻、およびトラブルシューティングに必要なシステム状態のみを出力する。 | app/main.py, app/api/routes/chat.py, app/ai/agent.py |
| レート制限 | ログインの総当たり攻撃や登録の大量作成、およびチャットや設計書生成の不正利用を防ぐため、Redisを用いたレート制限を適用し、制限超過時は Retry-After ヘルパーを含む 429 Too Many Requests を返却する。(要決定: 制限回数やウィンドウ期間) | app/cache/redis.py, app/api/routes/auth.py, app/api/routes/chat.py, app/api/routes/generation.py |
| 非同期処理 | 4種の設計書一括生成およびAI自己診断の処理は時間がかかるため、FastAPIのバックグラウンドタスクまたは非同期ジョブ機構を用いてバックグラウンドで実行し、クライアントへは即座にジョブIDを返却してポーリング等による進捗確認を行う。 | app/services/generation.py, app/repositories/job.py, app/ai/agent.py, app/api/routes/generation.py |
