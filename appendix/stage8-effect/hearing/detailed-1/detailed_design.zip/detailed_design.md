# 詳細設計書: Devex(ステージ8効果測定 詳細)

## 01 機能(処理)一覧

| 処理ID | 名称 | 種別 | トリガー | 関連画面 | 要件 | 機能グループ | 概要 |
|---|---|---|---|---|---|---|---|
| F-01 | ユーザー登録する | API | POST /api/v1/auth/register | SCR-001 | FR-001, FR-011, FR-012 | auth | メールアドレスとパスワードを受け取り新規ユーザーを作成する |
| F-02 | ログインする | API | POST /api/v1/auth/login | SCR-001 | FR-001, FR-002, FR-011 | auth | 認証情報を検証しアクセストークンおよびリフレッシュトークンを発行する |
| F-03 | トークンをリフレッシュする | API | POST /api/v1/auth/refresh | — | FR-002 | auth | 有効なリフレッシュトークンを使用して新規アクセストークンを再発給する |
| F-04 | ログアウトする | API | POST /api/v1/auth/logout | SCR-001, SCR-002, SCR-003 | FR-002, FR-012 | auth | リフレッシュトークンを無効化してログアウト処理を行う |
| F-05 | プロジェクト一覧を取得する | API | GET /api/v1/projects | SCR-002 | FR-003, FR-009 | projects | ユーザーがアクセス可能なプロジェクトの一覧を返す |
| F-06 | プロジェクトを作成する | API | POST /api/v1/projects | SCR-002 | FR-003, FR-009 | projects | 新しいプロジェクト名称と参考資料を受け取りプロジェクトを作成する |
| F-07 | チャット履歴を取得する | API | GET /api/v1/projects/{id}/messages | SCR-002 | FR-003, FR-004, FR-009 | messages | 指定プロジェクトの過去のチャットメッセージ一覧を返す |
| F-08 | チャットメッセージを送信する | API | POST /api/v1/projects/{id}/chat | SCR-002 | FR-003, FR-004, FR-010, FR-011 | chat | メッセージを受け取りSSEストリーミングによるAIの対話応答を返す |
| F-09 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する | API+バッチ | POST /api/v1/projects/{id}/generate | SCR-003 | FR-003, FR-005, FR-006, FR-010, FR-011 | generate | 4種の設計書一括生成と自己診断の非同期ジョブを開始しジョブIDを返す |
| F-10 | 設計書生成ジョブの進捗を確認する | API | GET /api/v1/projects/{id}/generate/status | SCR-003 | FR-003, FR-005, FR-006 | generate | 生成ジョブの進捗ステータスや完了時の生成文書・診断結果を返す |
| F-11 | 生成文書および自己診断結果を取得する | API | GET /api/v1/projects/{id}/documents | SCR-003 | FR-003, FR-005, FR-006, FR-009 | documents | 確定した4種のMarkdown設計書とAIの自己診断結果を返す |

## 02 データフロー

### DFD: auth

![データフロー図: auth](diagrams/dfd_auth.svg)

### DFD: projects

![データフロー図: projects](diagrams/dfd_projects.svg)

### DFD: messages

![データフロー図: messages](diagrams/dfd_messages.svg)

### DFD: chat

![データフロー図: chat](diagrams/dfd_chat.svg)

### DFD: generate

![データフロー図: generate](diagrams/dfd_generate.svg)

### データ辞書

| データ項目 | フィールド | 使う処理 |
|---|---|---|
| auth_tokens | access_token, refresh_token | F-02, F-03 |
| chat_ai_response | response_stream | F-08 |
| chat_history_request | access_token, project_id | F-07, F-08 |
| chat_message_input | message, project_id, access_token | F-08 |
| chat_messages_list | messages | F-07 |
| credentials | email, password | F-02 |
| generation_job_data | id, project_id, status | F-09, F-10 |
| job_id | job_id | F-09 |
| job_status_request | access_token, project_id, job_id | F-10 |
| job_status_result | status, generated_documents, diagnostic_results | F-10 |
| logout_result | success | F-04 |
| new_access_token | access_token | F-03 |
| project_create_request | access_token, project_name, reference_materials | F-06 |
| project_id_and_token | access_token, project_id | F-07, F-08, F-09 |
| project_info | id, project_name | F-06 |
| project_list_request | access_token | F-05 |
| projects_list | projects | F-05 |
| refresh_token_input | refresh_token | F-03, F-04 |
| registration_request | email, password | F-01 |
| user_info | id, email | F-01, F-02 |

### 処理概要表(入力 / 処理 / 出力)

| 処理ID | 名称 | 入力 | 処理内容 | 出力 |
|---|---|---|---|---|
| F-01 | ユーザー登録する | メールアドレスとパスワード | 標準的な条件に基づき入力を検証し、新規ユーザー情報をPostgreSQLに保存する。 | 作成されたユーザーの情報 |
| F-02 | ログインする | 認証情報 | 認証情報を検証し、アクセストークンおよびリフレッシュトークンを発行してHttpOnly Cookieに設定する。 | アクセストークンおよびリフレッシュトークン |
| F-03 | トークンをリフレッシュする | リフレッシュトークン | 有効なリフレッシュトークンを使用してトークン失効状態を検証し、新規アクセストークンを再発給する。 | 新規アクセストークン |
| F-04 | ログアウトする | リフレッシュトークン | Redisを用いてリフレッシュトークンを無効化しログアウト処理を行う。 | ログアウト完了の結果 |
| F-05 | プロジェクト一覧を取得する | アクセストークン | 認証情報を検証し、ユーザーがアクセス可能なプロジェクトのみをPostgreSQLから取得する。 | プロジェクト一覧 |
| F-06 | プロジェクトを作成する | 新しいプロジェクト名称と参考資料 | 参考資料の形式を検証し、新しいプロジェクトと参考資料をPostgreSQLに保存する。 | 作成されたプロジェクトの情報 |
| F-07 | チャット履歴を取得する | 指定プロジェクトIDとアクセストークン | プロジェクトへのアクセス権限を検証し、指定プロジェクトのチャット履歴をPostgreSQLから取得する。 | 過去のチャットメッセージ一覧 |
| F-08 | チャットメッセージを送信する | メッセージと指定プロジェクトID | プロジェクトへのアクセス権限を検証し、Gemini Flash-Liteを用いたAIの対話応答を生成してSSEストリーミングで返すとともにチャットメッセージをPostgreSQLに保存する。 | SSEストリーミングによるAIの対話応答 |
| F-09 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する | 指定プロジェクトID | プロジェクトへのアクセス権限を検証し、4種の設計書一括生成と自己診断の非同期ジョブを開始してジョブIDを発行する。 | ジョブID |
| F-10 | 設計書生成ジョブの進捗を確認する | 指定プロジェクトIDとジョブID | プロジェクトへのアクセス権限を検証し、生成ジョブの進捗ステータスや完了時の生成文書・診断結果を取得する。 | 生成ジョブの進捗ステータスや完了時の生成文書・診断結果 |
| F-11 | 生成文書および自己診断結果を取得する | 指定プロジェクトID | プロジェクトへのアクセス権限を検証し、確定した4種のMarkdown設計書とAIの自己診断結果をPostgreSQLから取得する。 | 4種のMarkdown設計書とAIの自己診断結果 |

## 03 データモデル

![ER図(全体)](diagrams/er.svg)

### テーブル定義

#### users

ユーザー情報テーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | ユーザーID |
| email | VARCHAR(255) | — | 不可 | UNIQUE | メールアドレス |
| password | VARCHAR(255) | — | 不可 | — | パスワードハッシュ |

#### tokens

トークン管理テーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | トークンID |
| user_id | UUID | FK | 不可 | FK to users(id) ON DELETE CASCADE | ユーザーID |
| refresh_token | VARCHAR(512) | — | 不可 | UNIQUE | リフレッシュトークン |

#### projects

プロジェクト情報テーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | プロジェクトID |
| user_id | UUID | FK | 不可 | FK to users(id) ON DELETE CASCADE | 所有者ユーザーID |
| project_name | VARCHAR(255) | — | 不可 | — | プロジェクト名称 |
| reference_materials | TEXT | — | 可 | — | 参考資料 |

#### chats

チャットセッションまたは関連テーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | チャットID |
| project_id | UUID | FK | 不可 | FK to projects(id) ON DELETE CASCADE | プロジェクトID |

#### messages

チャットメッセージテーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | メッセージID |
| project_id | UUID | FK | 不可 | FK to projects(id) ON DELETE CASCADE | プロジェクトID |
| message | TEXT | — | 不可 | — | メッセージ内容 |

#### generation_jobs

生成ジョブ管理テーブル

| 列 | 型 | キー | NULL | 制約 | 説明 |
|---|---|---|---|---|---|
| id | UUID | PK | 不可 | — | ジョブID |
| project_id | UUID | FK | 不可 | FK to projects(id) ON DELETE CASCADE | プロジェクトID |
| status | VARCHAR(50) | — | 不可 | — | ジョブの進捗ステータス |
| generated_documents | TEXT | — | 可 | — | 生成文書 |
| diagnostic_results | TEXT | — | 可 | — | 診断結果 |

### CRUD 図(処理 × テーブル)

| 処理ID | 名称 | users | tokens | projects | chats | messages | generation_jobs |
|---|---|---|---|---|---|---|---|
| F-01 | ユーザー登録する | C+ | — | — | — | — | — |
| F-02 | ログインする | R | C+ | — | — | — | — |
| F-03 | トークンをリフレッシュする | — | RU* | — | — | — | — |
| F-04 | ログアウトする | — | U+ | — | — | — | — |
| F-05 | プロジェクト一覧を取得する | — | — | R | — | — | — |
| F-06 | プロジェクトを作成する | — | — | C+ | — | — | — |
| F-07 | チャット履歴を取得する | — | — | — | — | R | — |
| F-08 | チャットメッセージを送信する | — | — | R | C+ | C* | — |
| F-09 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する | — | — | — | — | — | C+ |
| F-10 | 設計書生成ジョブの進捗を確認する | — | — | — | — | — | R |
| F-11 | 生成文書および自己診断結果を取得する | — | — | — | R* | — | — |

記号: 印なし = DFD の線から決まる R / `+` = 書き込みは DFD の線から決まり、C/U/D の区別は人が確定 / `*` = DFD に描いていない分で、人が確定

## 04 ソフトウェア構造

![コンポーネント図(全体)](diagrams/component.svg)

### モジュール一覧

| パス | 層 | 責務 | 主な依存先 | 関わる処理 |
|---|---|---|---|---|
| app/api/routes/auth.py | 入口 | 認証に関するAPIエンドポイントの定義とリクエストの受け付けを行う | app/services/auth.py | F-01, F-02, F-03, F-04 |
| app/api/routes/projects.py | 入口 | プロジェクトおよびチャット・設計書に関するAPIエンドポイントの定義とリクエストの受け付けを行う | app/services/project.py | F-05, F-06, F-07, F-08, F-09, F-10, F-11 |
| app/services/auth.py | ユースケース | ユーザー登録やログイン・ログアウト等の認証ビジネスロジックの実行と制御を行う | app/repositories/user.py, app/clients/redis.py | F-01, F-02, F-03, F-04 |
| app/services/project.py | ユースケース | プロジェクト管理やチャット応答・設計書生成のビジネスロジックの実行と制御を行う | app/repositories/project.py, app/agents/chat.py, app/agents/generator.py | F-05, F-06, F-07, F-08, F-09, F-10, F-11 |
| app/agents/chat.py | ユースケース | LangChainとLangGraphを用いたチャット応答生成を行う | app/clients/gemini.py | F-08 |
| app/agents/generator.py | ユースケース | LangChainとLangGraphを用いた文書生成および自己診断を行う | app/clients/gemini.py | F-09, F-10 |
| app/repositories/user.py | 永続化 | usersおよびtokensテーブルに対するPostgreSQLとのデータ入出力およびクエリの実行を行う | PostgreSQL | F-01, F-02, F-03, F-04 |
| app/repositories/project.py | 永続化 | projects、chats、messages、generation_jobsテーブルに対するPostgreSQLとのデータ入出力およびクエリの実行を行う | PostgreSQL | F-05, F-06, F-07, F-08, F-09, F-10, F-11 |
| app/clients/gemini.py | 外部連携 | Gemini Flash-Lite等の外部AIモデルとの通信を行う | Gemini Flash-Lite | F-08, F-09, F-10 |
| app/clients/redis.py | 外部連携 | Redisとの通信を行いトークン失効管理等を行う | Redis | F-03, F-04 |
| app/core/config.py | 入口 | アプリケーションの設定や環境変数の読み込みを行う | — | 全処理 |

## 05 主要処理の手順

### 5.0 索引

| 処理ID | 名称 | トリガー | 選定理由 | 手順数 | 詳細(06) |
|---|---|---|---|---|---|
| F-01 | ユーザー登録する | POST /api/v1/auth/register | ユーザー登録処理において、入力値の検証とデータベースへの安全な永続化を正確な順序で実行することが重要であるため。 | 6 | L-01 |
| F-02 | ログインする | POST /api/v1/auth/login | ログイン処理はユーザー認証とトークン発行の安全な制御が必要であるため、手順を明確に定義することが重要です。 | 6 | L-02 |
| F-03 | トークンをリフレッシュする | POST /api/v1/auth/refresh | リフレッシュトークンを用いた有効性・失効状態の検証と新規アクセストークン再発給の流れを正しく制御するため。 | 7 | L-03, L-04 |
| F-04 | ログアウトする | POST /api/v1/auth/logout | リフレッシュトークンを用いたログアウト処理において、Redisによるトークン無効化とリポジトリへの反映を確実に行うため | 6 | L-05 |
| F-05 | プロジェクト一覧を取得する | GET /api/v1/projects | アクセストークンを検証し、該当ユーザーがアクセス可能なプロジェクト一覧をデータベースから安全に取得する。 | 6 | — |
| F-06 | プロジェクトを作成する | POST /api/v1/projects | 新しいプロジェクトの作成と参考資料の検証を行い、データベースに登録する処理手順を明確にするため。 | 6 | — |
| F-07 | チャット履歴を取得する | GET /api/v1/projects/{id}/messages | 指定プロジェクトのチャット履歴を取得する処理であり、アクセスの検証からリポジトリ経由のメッセージ取得までを確実に行う必要があるため。 | 5 | — |
| F-08 | チャットメッセージを送信する | POST /api/v1/projects/{id}/chat | チャットメッセージを受信し、アクセス権限確認を経てGeminiによるSSEストリーミング応答とDB保存を連携させるため。 | 8 | — |
| F-09 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する | POST /api/v1/projects/{id}/generate | プロジェクトの権限確認と非同期ジョブの登録を正しく連動させるため手順の順序とトランザクション範囲が重要である | 6 | — |
| F-10 | 設計書生成ジョブの進捗を確認する | GET /api/v1/projects/{id}/generate/status | プロジェクトIDとジョブIDを基に生成ジョブの進捗と結果を安全に取得するため。 | 5 | — |
| F-11 | 生成文書および自己診断結果を取得する | GET /api/v1/projects/{id}/documents | プロジェクトへのアクセス権限を検証し、確定した4種のMarkdown設計書とAIの自己診断結果を安全に取得するため。 | 6 | — |

### 5.0.1 処理 × モジュール(セルは手順番号)

| 処理ID | app/api/routes/auth.py | app/api/routes/projects.py | app/services/auth.py | app/services/project.py | app/agents/chat.py | app/agents/generator.py | app/repositories/user.py | app/repositories/project.py | app/clients/gemini.py | app/clients/redis.py |
|---|---|---|---|---|---|---|---|---|---|---|
| F-01 | 1 | — | 2 | — | — | — | 3 | — | — | — |
| F-02 | 1 | — | 2 | — | — | — | 3, 4 | — | — | — |
| F-03 | 1 | — | 2, 5 | — | — | — | 4 | — | — | 3 |
| F-04 | 1 | — | 2 | — | — | — | 4 | — | — | 3 |
| F-05 | — | 1 | — | 2 | — | — | — | 3 | — | — |
| F-06 | — | 1 | — | 2 | — | — | — | 3 | — | — |
| F-07 | — | 1 | — | 2 | — | — | — | 3 | — | — |
| F-08 | — | 1 | — | 2 | 5 | — | — | 3, 4, 7 | 6 | — |
| F-09 | — | 1 | — | 2 | — | 4 | — | 3 | — | — |
| F-10 | — | 1 | — | 2 | — | — | — | 3 | — | — |
| F-11 | — | 1 | — | 2 | — | — | — | 3, 4 | — | — |

### 5.1 F-01 ユーザー登録する

トリガー: POST /api/v1/auth/register

選定理由: ユーザー登録処理において、入力値の検証とデータベースへの安全な永続化を正確な順序で実行することが重要であるため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/auth.py | 同期 | register | メールアドレスとパスワード | 新規ユーザー登録リクエストを受け付ける | リクエストデータ | — | 1a へ |
| 1a | — | — | — | — | リクエストの形式が不正 | — | — | ValidationError → 400 Bad Request |
| 2 | app/api/routes/auth.py → app/services/auth.py | 同期 | register_user → 詳細: L-01 | メールアドレスとパスワード | ユーザー登録のビジネスロジックを実行する | 作成されたユーザーの情報 | — | 2a へ |
| 2a | — | — | — | — | すでに登録済みのメールアドレス | — | — | ConflictError → 409 Conflict |
| 3 | app/services/auth.py → app/repositories/user.py | 同期 | create_user | メールアドレスとハッシュ化されたパスワード | usersテーブルに新規ユーザー情報を保存する | 保存されたユーザーのレコード | users C | — |
| 4 | app/repositories/user.py → app/services/auth.py | 戻り | — | 保存されたユーザーのレコード | 作成されたユーザー情報を返却する | 作成されたユーザーの情報 | — | — |
| 5 | app/services/auth.py → app/api/routes/auth.py | 戻り | — | 作成されたユーザーの情報 | ユーザー登録結果を返却する | 作成されたユーザーの情報 | — | — |
| 6 | app/api/routes/auth.py → 利用者 | 戻り | — | 作成されたユーザーの情報 | レスポンスを返す | 201 Created とユーザー情報 | — | — |

注記: 手順 2〜4 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/repositories/user.py
  P1->>P2: 1: register(メールアドレスとパスワード)
  Note over P1,P2: 1a リクエストの形式が不正 → ValidationError → 400 Bad Request
  P2->>P3: 2: register_user(メールアドレスとパスワード)
  Note over P2,P3: 2a すでに登録済みのメールアドレス → ConflictError → 409 Conflict
  P3->>P4: 3: create_user(メールアドレスとハッシュ化されたパスワード)
  P4-->>P3: 4: 保存されたユーザーのレコード
  P3-->>P2: 5: 作成されたユーザーの情報
  P2-->>P1: 6: 作成されたユーザーの情報
```

### 5.2 F-02 ログインする

トリガー: POST /api/v1/auth/login

選定理由: ログイン処理はユーザー認証とトークン発行の安全な制御が必要であるため、手順を明確に定義することが重要です。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/auth.py | 同期 | login | 認証情報 | ログインリクエストを受け付ける | ログインレスポンス | — | 1a へ |
| 1a | — | — | — | — | リクエストの形式が不正な場合 | — | — | ValidationError → 400 |
| 2 | app/api/routes/auth.py → app/services/auth.py | 同期 | AuthService.login → 詳細: L-02 | 認証情報 | ログインビジネスロジックを実行する | アクセストークンおよびリフレッシュトークン | — | — |
| 3 | app/services/auth.py → app/repositories/user.py | 同期 | UserRepository.findByEmail | メールアドレス | ユーザー情報を取得する | ユーザー情報 | users R | 3a へ |
| 3a | — | — | — | — | ユーザーが存在しない、またはパスワードが一致しない場合 | — | — | UnauthorizedError → 401 |
| 4 | app/services/auth.py → app/repositories/user.py | 同期 | UserRepository.createToken | ユーザーID、リフレッシュトークン | リフレッシュトークンを保存する | 保存結果 | tokens C | — |
| 5 | app/services/auth.py → app/api/routes/auth.py | 戻り | — | アクセストークンおよびリフレッシュトークン | トークンを返す | アクセストークンおよびリフレッシュトークン | — | — |
| 6 | app/api/routes/auth.py → 利用者 | 戻り | — | アクセストークンおよびリフレッシュトークン | HttpOnly Cookieにトークンを設定してレスポンスを返す | ログイン成功レスポンス | — | — |

注記: 手順 3〜5 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/repositories/user.py
  P1->>P2: 1: login(認証情報)
  Note over P1,P2: 1a リクエストの形式が不正な場合 → ValidationError → 400
  P2->>P3: 2: AuthService.login(認証情報)
  P3->>P4: 3: UserRepository.findByEmail(メールアドレス)
  Note over P3,P4: 3a ユーザーが存在しない、またはパスワードが一致しない場合 → UnauthorizedError → 401
  P4-->>P3: (3 の戻り) ユーザー情報
  P3->>P4: 4: UserRepository.createToken(ユーザーID、リフレッシュトークン)
  P4-->>P3: (4 の戻り) 保存結果
  P3-->>P2: 5: アクセストークンおよびリフレッシュトークン
  P2-->>P1: 6: アクセストークンおよびリフレッシュトークン
```

### 5.3 F-03 トークンをリフレッシュする

トリガー: POST /api/v1/auth/refresh

選定理由: リフレッシュトークンを用いた有効性・失効状態の検証と新規アクセストークン再発給の流れを正しく制御するため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/auth.py | 同期 | — | リフレッシュトークン | POST /api/v1/auth/refresh を受け付ける | リクエストデータ | — | — |
| 2 | app/api/routes/auth.py → app/services/auth.py | 同期 | AuthService.refresh_token → 詳細: L-03 | リフレッシュトークン | トークンのリフレッシュ処理を呼び出す | 新規アクセストークン | — | — |
| 3 | app/services/auth.py → app/clients/redis.py | 同期 | RedisClient.is_revoked | リフレッシュトークン | トークンがRedis上で失効していないか検証する | 失効状態 | tokens R | 3a へ |
| 3a | — | — | — | — | トークンが失効している場合 | — | — | UnauthorizedError → 401 |
| 4 | app/services/auth.py → app/repositories/user.py | 同期 | UserRepository.verify_refresh_token | リフレッシュトークン | tokensテーブルを参照してリフレッシュトークンの有効性を検証する | ユーザー情報 | tokens R | 4a へ |
| 4a | — | — | — | — | リフレッシュトークンが無効または期限切れの場合 | — | — | UnauthorizedError → 401 |
| 5 | app/services/auth.py → app/services/auth.py | 同期 | AuthService._generate_access_token → 詳細: L-04 | ユーザー情報 | 新規アクセストークンを再発給する | 新規アクセストークン | — | — |
| 6 | app/services/auth.py → app/api/routes/auth.py | 戻り | — | 新規アクセストークン | 新規アクセストークンを返す | 新規アクセストークン | — | — |
| 7 | app/api/routes/auth.py → 利用者 | 戻り | — | 新規アクセストークン | レスポンスとして新規アクセストークンを返す | HTTP 200 OK | — | — |

注記: 手順 2〜4 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/clients/redis.py
  participant P5 as app/repositories/user.py
  P1->>P2: 1: リフレッシュトークン
  P2->>P3: 2: AuthService.refresh_token(リフレッシュトークン)
  P3->>P4: 3: RedisClient.is_revoked(リフレッシュトークン)
  Note over P3,P4: 3a トークンが失効している場合 → UnauthorizedError → 401
  P4-->>P3: (3 の戻り) 失効状態
  P3->>P5: 4: UserRepository.verify_refresh_token(リフレッシュトークン)
  Note over P3,P5: 4a リフレッシュトークンが無効または期限切れの場合 → UnauthorizedError → 401
  P5-->>P3: (4 の戻り) ユーザー情報
  P3->>P3: 5: AuthService._generate_access_token(ユーザー情報)
  P3-->>P2: 6: 新規アクセストークン
  P2-->>P1: 7: 新規アクセストークン
```

### 5.4 F-04 ログアウトする

トリガー: POST /api/v1/auth/logout

選定理由: リフレッシュトークンを用いたログアウト処理において、Redisによるトークン無効化とリポジトリへの反映を確実に行うため

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/auth.py | 同期 | logout | リフレッシュトークン | ログアウトAPIリクエストを受け付ける | 処理の実行 | — | 1a へ |
| 1a | — | — | — | — | リクエストパラメータが不正な場合 | — | — | ValidationError → 400 |
| 2 | app/api/routes/auth.py → app/services/auth.py | 同期 | AuthService.logout → 詳細: L-05 | リフレッシュトークン | ログアウトビジネスロジックを実行する | ログアウト完了の結果 | — | — |
| 3 | app/services/auth.py → app/clients/redis.py | 同期 | RedisClient.invalidate_token | リフレッシュトークン | Redisを用いてリフレッシュトークンを無効化する | 無効化完了 | — | — |
| 4 | app/services/auth.py → app/repositories/user.py | 同期 | UserRepository.update_token_status | リフレッシュトークン | tokensテーブルのトークン状態を更新する | 更新完了 | tokens U | — |
| 5 | app/services/auth.py → app/api/routes/auth.py | 戻り | — | ログアウト完了の結果 | 結果を返す | ログアウト完了 | — | — |
| 6 | app/api/routes/auth.py → 利用者 | 戻り | — | ログアウト完了の結果 | レスポンスを返す | HTTP 200 OK | — | — |

注記: 手順2〜4が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/auth.py
  participant P3 as app/services/auth.py
  participant P4 as app/clients/redis.py
  participant P5 as app/repositories/user.py
  P1->>P2: 1: logout(リフレッシュトークン)
  Note over P1,P2: 1a リクエストパラメータが不正な場合 → ValidationError → 400
  P2->>P3: 2: AuthService.logout(リフレッシュトークン)
  P3->>P4: 3: RedisClient.invalidate_token(リフレッシュトークン)
  P4-->>P3: (3 の戻り) 無効化完了
  P3->>P5: 4: UserRepository.update_token_status(リフレッシュトークン)
  P5-->>P3: (4 の戻り) 更新完了
  P3-->>P2: 5: ログアウト完了の結果
  P2-->>P1: 6: ログアウト完了の結果
```

### 5.5 F-05 プロジェクト一覧を取得する

トリガー: GET /api/v1/projects

選定理由: アクセストークンを検証し、該当ユーザーがアクセス可能なプロジェクト一覧をデータベースから安全に取得する。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/projects.py | 同期 | get_projects | アクセストークン | プロジェクト一覧取得APIへのリクエストを受け付ける | プロジェクト一覧レスポンス | — | 1a へ |
| 1a | — | — | — | — | アクセストークンが無効または有効期限切れ | — | — | UnauthorizedError → 401 |
| 2 | app/api/routes/projects.py → app/services/project.py | 同期 | ProjectService.get_projects | アクセストークン | プロジェクト一覧取得のビジネスロジックを実行する | プロジェクト一覧データ | — | — |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.find_by_user | ユーザーID | ユーザーがアクセス可能なプロジェクトを検索する | プロジェクトレコード一覧 | projects R | — |
| 4 | app/repositories/project.py → app/services/project.py | 戻り | — | プロジェクトレコード一覧 | プロジェクトレコードをサービス層へ返す | プロジェクト一覧データ | — | — |
| 5 | app/services/project.py → app/api/routes/projects.py | 戻り | — | プロジェクト一覧データ | プロジェクト一覧データをAPI層へ返す | プロジェクト一覧レスポンス | — | — |
| 6 | app/api/routes/projects.py → 利用者 | 戻り | — | プロジェクト一覧レスポンス | プロジェクト一覧をレスポンスとして返却する | 200 OK | — | — |

注記: 読み取り専用の処理であるためトランザクションは明示的に設定しない。

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/projects.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  P1->>P2: 1: get_projects(アクセストークン)
  Note over P1,P2: 1a アクセストークンが無効または有効期限切れ → UnauthorizedError → 401
  P2->>P3: 2: ProjectService.get_projects(アクセストークン)
  P3->>P4: 3: ProjectRepository.find_by_user(ユーザーID)
  P4-->>P3: 4: プロジェクトレコード一覧
  P3-->>P2: 5: プロジェクト一覧データ
  P2-->>P1: 6: プロジェクト一覧レスポンス
```

### 5.6 F-06 プロジェクトを作成する

トリガー: POST /api/v1/projects

選定理由: 新しいプロジェクトの作成と参考資料の検証を行い、データベースに登録する処理手順を明確にするため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/projects.py | 同期 | create_project | 新しいプロジェクト名称と参考資料 | プロジェクト作成APIリクエストを受け付ける | プロジェクト作成リクエスト | — | 1a へ |
| 1a | — | — | — | — | リクエストデータが不正 | — | — | ValidationError → 400 |
| 2 | app/api/routes/projects.py → app/services/project.py | 同期 | ProjectService.create_project | 新しいプロジェクト名称と参考資料 | 参考資料の形式を検証し、プロジェクト作成のビジネスロジックを実行する | 作成されたプロジェクトの情報 | — | 2a へ |
| 2a | — | — | — | — | 参考資料の形式が不正 | — | — | ValueError → 400 |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.create | プロジェクトデータ | 新しいプロジェクトをPostgreSQLに保存する | 保存されたプロジェクトのレコード | projects C | — |
| 4 | app/repositories/project.py → app/services/project.py | 戻り | — | 保存されたプロジェクトのレコード | リポジトリからサービス層へ結果を返す | 作成されたプロジェクトの情報 | — | — |
| 5 | app/services/project.py → app/api/routes/projects.py | 戻り | — | 作成されたプロジェクトの情報 | サービス層からAPIルーター層へ結果を返す | 作成されたプロジェクトの情報 | — | — |
| 6 | app/api/routes/projects.py → 利用者 | 戻り | — | 作成されたプロジェクトの情報 | プロジェクト作成のレスポンスを返す | HTTP 201 Created とプロジェクト情報 | — | — |

注記: 手順 3〜4 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/projects.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  P1->>P2: 1: create_project(新しいプロジェクト名称と参考資料)
  Note over P1,P2: 1a リクエストデータが不正 → ValidationError → 400
  P2->>P3: 2: ProjectService.create_project(新しいプロジェクト名称と参考資料)
  Note over P2,P3: 2a 参考資料の形式が不正 → ValueError → 400
  P3->>P4: 3: ProjectRepository.create(プロジェクトデータ)
  P4-->>P3: 4: 保存されたプロジェクトのレコード
  P3-->>P2: 5: 作成されたプロジェクトの情報
  P2-->>P1: 6: 作成されたプロジェクトの情報
```

### 5.7 F-07 チャット履歴を取得する

トリガー: GET /api/v1/projects/{id}/messages

選定理由: 指定プロジェクトのチャット履歴を取得する処理であり、アクセスの検証からリポジトリ経由のメッセージ取得までを確実に行う必要があるため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/projects.py | 同期 | get_messages | プロジェクトID, アクセストークン | チャット履歴取得のリクエストを受け付ける | メッセージ一覧 | — | 1a へ |
| 1a | — | — | — | — | アクセストークンが無効または期限切れ | — | — | UnauthorizedError → 401 |
| 2 | app/api/routes/projects.py → app/services/project.py | 同期 | ProjectService.get_messages | プロジェクトID, ユーザーID | プロジェクトへのアクセス権限を検証し、チャット履歴の取得を指示する | メッセージ一覧 | projects R | 2a へ |
| 2a | — | — | — | — | プロジェクトが存在しない、またはアクセス権限がない | — | — | ForbiddenError → 403 |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.get_messages | プロジェクトID | PostgreSQLから指定プロジェクトのメッセージ一覧を取得する | メッセージ一覧データ | messages R | — |
| 4 | app/services/project.py → app/api/routes/projects.py | 戻り | — | メッセージ一覧データ | 取得したメッセージ一覧をAPI層へ返す | メッセージ一覧 | — | — |
| 5 | app/api/routes/projects.py → 利用者 | 戻り | — | メッセージ一覧 | チャット履歴をレスポンスとして返す | HTTP 200 OK | — | — |

注記: トランザクションは読み取り専用の参照クエリのみのため、明示的なトランザクションブロックは不要

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/projects.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  P1->>P2: 1: get_messages(プロジェクトID, アクセストークン)
  Note over P1,P2: 1a アクセストークンが無効または期限切れ → UnauthorizedError → 401
  P2->>P3: 2: ProjectService.get_messages(プロジェクトID, ユーザーID)
  Note over P2,P3: 2a プロジェクトが存在しない、またはアクセス権限がない → ForbiddenError → 403
  P3->>P4: 3: ProjectRepository.get_messages(プロジェクトID)
  P4-->>P3: (3 の戻り) メッセージ一覧データ
  P3-->>P2: 4: メッセージ一覧データ
  P2-->>P1: 5: メッセージ一覧
```

### 5.8 F-08 チャットメッセージを送信する

トリガー: POST /api/v1/projects/{id}/chat

選定理由: チャットメッセージを受信し、アクセス権限確認を経てGeminiによるSSEストリーミング応答とDB保存を連携させるため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/projects.py | 同期 | projects.send_chat_message | メッセージと指定プロジェクトID | チャットメッセージ送信APIへのリクエストを受け付ける | SSEストリーミングによるレスポンス | — | 1a へ |
| 1a | — | — | — | — | リクエストのバリデーションエラー | — | — | ValidationError → 400 |
| 2 | app/api/routes/projects.py → app/services/project.py | 同期 | ProjectService.send_chat | メッセージと指定プロジェクトID、ユーザーID | チャット応答生成のビジネスロジックを実行する | SSEストリーム | — | — |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.get_project | 指定プロジェクトID、ユーザーID | プロジェクトへのアクセス権限を検証するためプロジェクト情報を取得する | プロジェクト情報 | projects R | 3a へ |
| 3a | — | — | — | — | プロジェクトが存在しないまたは権限がない | — | — | NotFoundError → 404 |
| 4 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.create_chat | 指定プロジェクトID、メッセージ | チャットメッセージをPostgreSQLに保存する | チャットID | chats C | — |
| 5 | app/services/project.py → app/agents/chat.py | 同期 | ChatAgent.generate_stream | メッセージとコンテキスト | Gemini Flash-Liteを用いたAIの対話応答のストリーム生成を依頼する | AI応答のSSEストリーム | — | — |
| 6 | app/agents/chat.py → app/clients/gemini.py | 同期 | GeminiClient.stream | プロンプトとメッセージ | Gemini Flash-Liteと通信し対話応答のストリーミングデータを取得する | ストリーミングデータ | — | — |
| 7 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.create_message | チャットID、AIの生成メッセージ | 生成されたAIの対話メッセージをPostgreSQLに保存する | メッセージID | messages C | — |
| 8 | app/api/routes/projects.py → 利用者 | 戻り | — | AIの対話応答のSSEストリーム | SSEストリーミングによるAIの対話応答を返す | SSEストリーミング | — | — |

注記: 手順 3〜6 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/projects.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  participant P5 as app/agents/chat.py
  participant P6 as app/clients/gemini.py
  P1->>P2: 1: projects.send_chat_message(メッセージと指定プロジェクトID)
  Note over P1,P2: 1a リクエストのバリデーションエラー → ValidationError → 400
  P2->>P3: 2: ProjectService.send_chat(メッセージと指定プロジェクトID、ユーザーID)
  P3->>P4: 3: ProjectRepository.get_project(指定プロジェクトID、ユーザーID)
  Note over P3,P4: 3a プロジェクトが存在しないまたは権限がない → NotFoundError → 404
  P4-->>P3: (3 の戻り) プロジェクト情報
  P3->>P4: 4: ProjectRepository.create_chat(指定プロジェクトID、メッセージ)
  P4-->>P3: (4 の戻り) チャットID
  P3->>P5: 5: ChatAgent.generate_stream(メッセージとコンテキスト)
  P5->>P6: 6: GeminiClient.stream(プロンプトとメッセージ)
  P6-->>P5: (6 の戻り) ストリーミングデータ
  P5-->>P3: (5 の戻り) AI応答のSSEストリーム
  P3->>P4: 7: ProjectRepository.create_message(チャットID、AIの生成メッセージ)
  P4-->>P3: (7 の戻り) メッセージID
  P3-->>P2: (2 の戻り) SSEストリーム
  P2-->>P1: 8: AIの対話応答のSSEストリーム
```

### 5.9 F-09 設計書一括生成およびAI自己診断の非同期ジョブを開始する

トリガー: POST /api/v1/projects/{id}/generate

選定理由: プロジェクトの権限確認と非同期ジョブの登録を正しく連動させるため手順の順序とトランザクション範囲が重要である

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/projects.py | 同期 | generate_jobs | 指定プロジェクトID | 設計書一括生成およびAI自己診断の非同期ジョブ開始リクエストを受け付ける | ジョブID | — | 1a へ |
| 1a | — | — | — | — | リクエストのパラメータが不正である | — | — | ValidationError -> 400 |
| 2 | app/api/routes/projects.py → app/services/project.py | 同期 | ProjectService.start_generation_job | 指定プロジェクトID | プロジェクトへのアクセス権限を検証し非同期ジョブの開始を依頼する | ジョブID | projects R | 2a へ、2b へ |
| 2a | — | — | — | — | プロジェクトが存在しない | — | — | NotFoundError -> 404 |
| 2b | — | — | — | — | プロジェクトへのアクセス権限がない | — | — | ForbiddenError -> 403 |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.create_generation_job | 指定プロジェクトID | generation_jobsテーブルに新規ジョブレコードを作成する | ジョブID | generation_jobs C | — |
| 4 | app/services/project.py → app/agents/generator.py | 非同期 | GeneratorAgent.run_async | ジョブID, 指定プロジェクトID | 4種の設計書一括生成と自己診断の非同期ジョブを起動する | — | — | — |
| 5 | app/services/project.py → app/api/routes/projects.py | 戻り | — | ジョブID | ジョブIDを呼び出し元へ返す | ジョブID | — | — |
| 6 | app/api/routes/projects.py → 利用者 | 戻り | — | ジョブID | ジョブIDを含むレスポンスを返却する | 202 Accepted | — | — |

注記: 手順 2 から 4 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/projects.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  participant P5 as app/agents/generator.py
  P1->>P2: 1: generate_jobs(指定プロジェクトID)
  Note over P1,P2: 1a リクエストのパラメータが不正である → ValidationError -> 400
  P2->>P3: 2: ProjectService.start_generation_job(指定プロジェクトID)
  Note over P2,P3: 2a プロジェクトが存在しない → NotFoundError -> 404
  Note over P2,P3: 2b プロジェクトへのアクセス権限がない → ForbiddenError -> 403
  P3->>P4: 3: ProjectRepository.create_generation_job(指定プロジェクトID)
  P4-->>P3: (3 の戻り) ジョブID
  P3-)P5: 4: GeneratorAgent.run_async(ジョブID, 指定プロジェクトID)
  P3-->>P2: 5: ジョブID
  P2-->>P1: 6: ジョブID
```

### 5.10 F-10 設計書生成ジョブの進捗を確認する

トリガー: GET /api/v1/projects/{id}/generate/status

選定理由: プロジェクトIDとジョブIDを基に生成ジョブの進捗と結果を安全に取得するため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/projects.py | 同期 | get_generation_status | プロジェクトID、ジョブID | 設計書生成ジョブの進捗状況取得リクエストを受け付ける | 進捗ステータス、生成文書、診断結果 | — | 1a へ |
| 1a | — | — | — | — | プロジェクトへのアクセス権限がない場合 | — | — | ForbiddenError -> 403 |
| 2 | app/api/routes/projects.py → app/services/project.py | 同期 | ProjectService.get_generation_status | プロジェクトID、ジョブID | 生成ジョブの進捗状況取得のビジネスロジックを実行する | 進捗ステータス、生成文書、診断結果 | — | — |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | ProjectRepository.get_generation_job | プロジェクトID、ジョブID | generation_jobsテーブルからジョブの進捗情報を取得する | ジョブ情報 | generation_jobs R | 3a へ |
| 3a | — | — | — | — | 指定されたジョブが存在しない場合 | — | — | NotFoundError -> 404 |
| 4 | app/services/project.py → app/api/routes/projects.py | 戻り | — | 進捗ステータス、生成文書、診断結果 | 進捗情報を返却する | 進捗ステータス、生成文書、診断結果 | — | — |
| 5 | app/api/routes/projects.py → 利用者 | 戻り | — | 進捗ステータス、生成文書、診断結果 | レスポンスを返す | 進捗ステータス、生成文書、診断結果 | — | — |

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/projects.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  P1->>P2: 1: get_generation_status(プロジェクトID、ジョブID)
  Note over P1,P2: 1a プロジェクトへのアクセス権限がない場合 → ForbiddenError -> 403
  P2->>P3: 2: ProjectService.get_generation_status(プロジェクトID、ジョブID)
  P3->>P4: 3: ProjectRepository.get_generation_job(プロジェクトID、ジョブID)
  Note over P3,P4: 3a 指定されたジョブが存在しない場合 → NotFoundError -> 404
  P4-->>P3: (3 の戻り) ジョブ情報
  P3-->>P2: 4: 進捗ステータス、生成文書、診断結果
  P2-->>P1: 5: 進捗ステータス、生成文書、診断結果
```

### 5.11 F-11 生成文書および自己診断結果を取得する

トリガー: GET /api/v1/projects/{id}/documents

選定理由: プロジェクトへのアクセス権限を検証し、確定した4種のMarkdown設計書とAIの自己診断結果を安全に取得するため。

| No | 呼び出し元 → 呼び出し先 | 種別 | 関数 | 渡すデータ | 処理内容 | 結果 | DB 操作 | 分岐・例外 |
|---|---|---|---|---|---|---|---|---|
| 1 | 利用者 → app/api/routes/projects.py | 同期 | get_documents | 指定プロジェクトID | 生成文書および自己診断結果の取得リクエストを受け付ける | 設計書および自己診断結果 | — | 1a へ |
| 1a | — | — | — | — | 認証トークンが無効または期限切れ | — | — | UnauthorizedError → 401 |
| 2 | app/api/routes/projects.py → app/services/project.py | 同期 | get_project_documents | 指定プロジェクトID、ユーザーID | プロジェクトへのアクセス権限検証と文書取得のビジネスロジックを実行する | 設計書および自己診断結果 | — | 2a へ、2b へ |
| 2a | — | — | — | — | プロジェクトに対する権限がない | — | — | ForbiddenError → 403 |
| 2b | — | — | — | — | プロジェクトが存在しない | — | — | NotFoundError → 404 |
| 3 | app/services/project.py → app/repositories/project.py | 同期 | find_by_id | 指定プロジェクトID | プロジェクトの存在およびアクセス権限を確認するため情報を取得する | プロジェクト情報 | projects R | — |
| 4 | app/services/project.py → app/repositories/project.py | 同期 | get_documents_and_diagnosis | 指定プロジェクトID | 確定した4種のMarkdown設計書とAIの自己診断結果を取得する | 4種のMarkdown設計書、自己診断結果 | chats R | — |
| 5 | app/services/project.py → app/api/routes/projects.py | 戻り | — | 4種のMarkdown設計書、自己診断結果 | 取得した文書と自己診断結果を返す | 設計書および自己診断結果のレスポンス | — | — |
| 6 | app/api/routes/projects.py → 利用者 | 戻り | — | 設計書および自己診断結果のレスポンス | 利用者に生成文書および自己診断結果を返却する | HTTP 200 OK | — | — |

注記: 手順 3〜4 が1つのトランザクション

シーケンス図(手順の表から導いた図。直すのは表):

```mermaid
sequenceDiagram
  participant P1 as 利用者
  participant P2 as app/api/routes/projects.py
  participant P3 as app/services/project.py
  participant P4 as app/repositories/project.py
  P1->>P2: 1: get_documents(指定プロジェクトID)
  Note over P1,P2: 1a 認証トークンが無効または期限切れ → UnauthorizedError → 401
  P2->>P3: 2: get_project_documents(指定プロジェクトID、ユーザーID)
  Note over P2,P3: 2a プロジェクトに対する権限がない → ForbiddenError → 403
  Note over P2,P3: 2b プロジェクトが存在しない → NotFoundError → 404
  P3->>P4: 3: find_by_id(指定プロジェクトID)
  P4-->>P3: (3 の戻り) プロジェクト情報
  P3->>P4: 4: get_documents_and_diagnosis(指定プロジェクトID)
  P4-->>P3: (4 の戻り) 4種のMarkdown設計書、自己診断結果
  P3-->>P2: 5: 4種のMarkdown設計書、自己診断結果
  P2-->>P1: 6: 設計書および自己診断結果のレスポンス
```

## 06 処理ロジックの詳細

### 6.0 逆引き(関数 × 手順)

| L-ID | 関数 | モジュール | 呼ばれる手順 |
|---|---|---|---|
| L-01 | register_user | app/services/auth.py | F-01#2 |
| L-02 | AuthService.login | app/services/auth.py | F-02#2 |
| L-03 | AuthService.refresh_token | app/services/auth.py | F-03#2 |
| L-04 | AuthService._generate_access_token | app/services/auth.py | F-03#5 |
| L-05 | AuthService.logout | app/services/auth.py | F-04#2 |

### 6.1 L-01 register_user

呼ばれる手順: F-01#2

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def register_user(email: str, password: str) -> dict |
| 引数 | email: 登録するユーザーのメールアドレス / password: 登録するユーザーのパスワード |
| 戻り値 | 作成されたユーザーの情報 |
| 例外 | ConflictError: すでに登録済みのメールアドレスの場合、409 Conflict を返す |
| 事前条件 | メールアドレスとパスワードが有効な形式であること |
| 事後条件 | ユーザーが正常に登録され、ユーザー情報が返されること |

擬似フロー:

1. リクエストされたメールアドレスがすでに users テーブルに存在するか確認する
    - app/repositories/user.py を使用してメールアドレスを検索する
2. メールアドレスの重複チェックの結果を評価する
    - すでに登録済みの場合は ConflictError を送出する
3. パスワードのハッシュ化など、ユーザー登録に必要なデータを準備する
    - 平文のパスワードを安全な形式に変換する
4. users テーブルに新しいユーザー情報を保存する
    - app/repositories/user.py を使用して新規レコードを作成する
5. 作成されたユーザーの情報を戻り値として構築し、呼び出し元に返す
    - 機密情報を除外したユーザーデータを返却形式に整える

### 6.2 L-02 AuthService.login

呼ばれる手順: F-02#2

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def login(credentials: AuthCredentials) -> TokenPair |
| 引数 | credentials: 認証情報 |
| 戻り値 | アクセストークンおよびリフレッシュトークン |
| 例外 | ValueError: 認証失敗時は401エラー相当の例外を送出する |
| 事前条件 | 認証情報の形式が正しく、users テーブルにアクセス可能なこと |
| 事後条件 | 有効なアクセストークンとリフレッシュトークンが発行されること |

擬似フロー:

1. 受け取った認証情報をもとに app/repositories/user.py を介してユーザー情報を取得する
    - ユーザーが存在しない場合は例外を送出する
2. 取得したユーザー情報のパスワードハッシュと入力されたパスワードを検証する
    - パスワードが一致しない場合は例外を送出する
3. アクセストークンおよびリフレッシュトークンを生成する
    - 有効期限を設定してトークンを発行する
4. 必要に応じて app/clients/redis.py を介してリフレッシュトークンをキャッシュまたは保存する
    - 保存に失敗した場合は例外を送出する
5. 生成したアクセストークンとリフレッシュトークンを返す

### 6.3 L-03 AuthService.refresh_token

呼ばれる手順: F-03#2

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def refresh_token(self, refresh_token: str) -> dict |
| 引数 | refresh_token: リフレッシュトークン |
| 戻り値 | 新規アクセストークン |
| 例外 | ValueError: リフレッシュトークンが無効または期限切れの場合 |
| 事前条件 | 有効なリフレッシュトークンが提供されていること |
| 事後条件 | 新規アクセストークンが発行されること |

擬似フロー:

1. リフレッシュトークンの検証を行う
    - リフレッシュトークンが有効か確認する
    - 無効な場合はValueErrorを送出する
2. ユーザー情報の特定を行う
    - リフレッシュトークンからユーザー情報を取得する
3. 新規アクセストークンを生成する
    - 新しいアクセストークンを発行して戻り値として準備する

### 6.4 L-04 AuthService._generate_access_token

呼ばれる手順: F-03#5

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def _generate_access_token(self, user_info: dict) -> str: |
| 引数 | user_info: 新規アクセストークンを再発給する対象のユーザー情報 |
| 戻り値 | 再発給された新規アクセストークン |
| 例外 | なし |
| 事前条件 | 呼び出し元で対象のユーザー情報が正しく取得されていること |
| 事後条件 | 新規アクセストークンが生成されて返却されること |

擬似フロー:

1. アクセストークン生成のための設定情報を読み込む
    - 秘密鍵や有効期限の環境変数を取得する
2. ユーザー情報からペイロードを作成する
    - ユーザーIDや関連する識別子を含める
    - トークンの有効期限を設定する
3. アクセストークンを暗号化および署名して生成する
    - 設定されたアルゴリズムで署名を作成する

### 6.5 L-05 AuthService.logout

呼ばれる手順: F-04#2

モジュール: app/services/auth.py

| 項目 | 内容 |
|---|---|
| シグネチャ | def logout(self, refreshToken: str) -> None |
| 引数 | refreshToken: ログアウト対象のリフレッシュトークン |
| 戻り値 | なし |
| 例外 | リフレッシュトークンが無効または期限切れの場合にエラーを送出する |
| 事前条件 | 有効な認証コンテキストが存在すること |
| 事後条件 | 指定されたリフレッシュトークンが無効化されていること |

擬似フロー:

1. 受け取ったリフレッシュトークンの検証を行う
    - リフレッシュトークンの形式や署名を検証する
2. リフレッシュトークンの有効性を確認する
    - データベースまたは Redis から該当するトークン情報を取得する
    - トークンが存在しない、または期限切れの場合は例外を送出する
3. リフレッシュトークンを無効化する
    - 該当するトークンを破棄またはブラックリストに追加する

## 07 横断事項

| 項目 | 方針 | 関わるファイル(例) |
|---|---|---|
| 例外と HTTP | APIの処理で例外が発生した場合は、対応するHTTPステータスコードに変換して返却する。入力値の検証エラーは400 Bad Request、認証失敗やトークン無効は401 Unauthorized、アクセス権限がない場合は403 Forbidden、対象が存在しない場合は404 NotFound、一意制約違反などは409 Conflict、AI応答失敗等のサーバー内部エラーは500 Internal Server Errorを返却する。 | app/api/routes/auth.py, app/api/routes/projects.py |
| 認証 | JWTを用いた認証を実装し、アクセストークンの有効期限は30分、リフレッシュトークンは14日間としHttpOnly Cookieに設定する。ログアウト時やトークン失効時にはRedisを用いてリフレッシュトークンを無効化し、不正利用や総当たり攻撃を防ぐ。 | app/services/auth.py, app/clients/redis.py, app/repositories/user.py |
| トランザクション | データベースへの書き込みを伴う処理（ユーザー登録、ログインでのトークン保存、プロジェクト作成、チャットメッセージ保存、非同期ジョブ開始など）は、リポジトリ層との連携において1つのトランザクションとして扱い、エラー時はロールバックを行う。読み取り専用の処理では明示的なトランザクションブロックを設定しない。 | app/services/auth.py, app/services/project.py, app/repositories/user.py, app/repositories/project.py |
| ログ | セキュリティおよびプライバシーの観点から、ユーザーから入力された内容や機密情報はログに残さず、処理のエラーの有無や発生時刻、ステータスのみをログとして記録する。 | app/core/config.py, app/services/auth.py, app/services/project.py |
