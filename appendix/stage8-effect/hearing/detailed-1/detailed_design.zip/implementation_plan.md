# 実装計画書: Devex(ステージ8効果測定 詳細)

## 1 マイルストーン

| M-ID | 名前 | 優先度 | ゴール | 処理 |
|---|---|---|---|---|
| M-01 | M-01: 環境構築と認証機能 | Must | 開発環境が整備され、横断事項およびユーザー認証(登録・ログイン・トークンリフレッシュ・ログアウト)が動作する。 | F-01, F-02, F-03, F-04 |
| M-02 | M-02: プロジェクト管理とチャット対話機能 | Must | プロジェクトの作成・一覧取得およびGeminiを利用したチャットメッセージ送信と履歴取得ができる。 | F-06, F-05, F-07, F-08 |
| M-03 | M-03: 設計書一括生成と自己診断機能 | Must | ヒアリング結果に基づく4種設計書の一括生成、自己診断の非同期実行と進捗確認、結果の取得ができる。 | F-09, F-10, F-11 |

### M-01 M-01: 環境構築と認証機能(Must)

ゴール: 開発環境が整備され、横断事項およびユーザー認証(登録・ログイン・トークンリフレッシュ・ログアウト)が動作する。

| ID | 種別 | タスク | 処理 | 依存 | モジュール | 環境・設定のファイル(例) |
|---|---|---|---|---|---|---|
| M-01-T01 | 基盤 | 開発環境および共通設定・横断事項の土台構築 | — | — | app/core/config.py | Dockerfile, docker-compose.yml |
| M-01-T02 | 機能 | ユーザー登録機能の実装 | F-01 | M-01-T01 | app/api/routes/auth.py, app/services/auth.py, app/repositories/user.py | — |
| M-01-T03 | 機能 | ログイン機能の実装 | F-02 | M-01-T02 | app/api/routes/auth.py, app/services/auth.py, app/repositories/user.py | — |
| M-01-T04 | 機能 | トークンリフレッシュ機能の実装 | F-03 | M-01-T03 | app/api/routes/auth.py, app/services/auth.py, app/repositories/user.py, app/clients/redis.py | — |
| M-01-T05 | 機能 | ログアウト機能の実装 | F-04 | M-01-T04 | app/api/routes/auth.py, app/services/auth.py, app/repositories/user.py, app/clients/redis.py | — |

### M-02 M-02: プロジェクト管理とチャット対話機能(Must)

ゴール: プロジェクトの作成・一覧取得およびGeminiを利用したチャットメッセージ送信と履歴取得ができる。

| ID | 種別 | タスク | 処理 | 依存 | モジュール | 環境・設定のファイル(例) |
|---|---|---|---|---|---|---|
| M-02-T01 | 機能 | プロジェクト作成機能の実装 | F-06 | M-01-T05 | app/api/routes/projects.py, app/services/project.py, app/repositories/project.py | — |
| M-02-T02 | 機能 | プロジェクト一覧取得機能の実装 | F-05 | M-02-T01 | app/api/routes/projects.py, app/services/project.py, app/repositories/project.py | — |
| M-02-T03 | 機能 | チャット履歴取得機能の実装 | F-07 | M-02-T02 | app/api/routes/projects.py, app/services/project.py, app/repositories/project.py | — |
| M-02-T04 | 機能 | チャットメッセージ送信およびAI応答機能の実装 | F-08 | M-02-T03 | app/api/routes/projects.py, app/services/project.py, app/repositories/project.py, app/agents/chat.py, app/clients/gemini.py | — |

### M-03 M-03: 設計書一括生成と自己診断機能(Must)

ゴール: ヒアリング結果に基づく4種設計書の一括生成、自己診断の非同期実行と進捗確認、結果の取得ができる。

| ID | 種別 | タスク | 処理 | 依存 | モジュール | 環境・設定のファイル(例) |
|---|---|---|---|---|---|---|
| M-03-T01 | 機能 | 設計書一括生成およびAI自己診断の非同期ジョブ開始機能の実装 | F-09 | M-02-T04 | app/api/routes/projects.py, app/services/project.py, app/repositories/project.py, app/agents/generator.py | — |
| M-03-T02 | 機能 | 設計書生成ジョブの進捗確認機能の実装 | F-10 | M-03-T01 | app/api/routes/projects.py, app/services/project.py, app/repositories/project.py | — |
| M-03-T03 | 機能 | 生成文書および自己診断結果の取得機能の実装 | F-11 | M-03-T02 | app/api/routes/projects.py, app/services/project.py, app/repositories/project.py | — |

## 2 処理の割り当て

| 処理ID | 名称 | 単位 |
|---|---|---|
| F-01 | ユーザー登録する | M-01-T02 |
| F-02 | ログインする | M-01-T03 |
| F-03 | トークンをリフレッシュする | M-01-T04 |
| F-04 | ログアウトする | M-01-T05 |
| F-05 | プロジェクト一覧を取得する | M-02-T02 |
| F-06 | プロジェクトを作成する | M-02-T01 |
| F-07 | チャット履歴を取得する | M-02-T03 |
| F-08 | チャットメッセージを送信する | M-02-T04 |
| F-09 | 設計書一括生成およびAI自己診断の非同期ジョブを開始する | M-03-T01 |
| F-10 | 設計書生成ジョブの進捗を確認する | M-03-T02 |
| F-11 | 生成文書および自己診断結果を取得する | M-03-T03 |

## 3 開発環境・事前準備

開発環境はPython 3.13、FastAPI、Next.js(App Router)およびTamaguiを使用する。データベースにはPostgreSQL、トークン失効管理にRedisを用いる。インフラはVPS上にDocker Composeとnginxで構築し、GitHub Actionsを用いたmainブランチへのpushによる自動デプロイを行う。自動テストは単体テスト・結合テストを順次導入する方針とする。

## 4 想定リスクと対策

| リスク | 対策 |
|---|---|
| Gemini Flash-LiteのAPI応答遅延やレートリミットによるチャット・文書生成の失敗 | FR-010に基づき、AI応答失敗時の理由表示と再送メッセージの仕組み、および生成失敗時の再生成機能を確実に実装する。スケジュールが厳しい場合は、自己診断の段階数を簡略化して対応する。 |
| LangGraphを利用したマルチステップのチャットおよび文書生成・自己診断の複雑化によるスケジュール遅延 | MVPの段階ではワークフローを最小限の構成に絞り、複雑な条件分岐は後回しにする。必要に応じて文書生成の対象範囲を縮小する。 |
| VPS上でのDocker Compose環境構築およびGitHub Actionsによる自動デプロイのトラブル | 開発初期段階（M-01-T01）で早期にコンテナ起動とCI/CDパイプラインの疎通確認を行い、リスクを早期に解消する。 |
| JWTおよびHttpOnly Cookieによる認証・セキュリティ要件の実装不備 | 標準的な認証ライブラリを活用し、トークンの有効期限管理やRedisによるリフレッシュトークン無効化のテストを徹底する。 |
